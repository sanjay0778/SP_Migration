﻿using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class NotesDocument
    {
        //public DocumentGroups Name { get; set; }
        public Dictionary<string, string> Attributes { get; set; }
        public List<string> Attachments { get; set; }

        public bool HasAttachments { get; set; }
        public string Uid { get; set; }
        public bool Keep { get; set; }

        //Constructor with 2 properties (attributes & attachments)
        public NotesDocument()
        {
            Attributes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Attachments = new List<string>();
        }
        public string GetAttribute(string attribute)
        {
            string result = null;
            result = Attributes.Where(a => a.Key.ToUpper().Equals(attribute.ToUpper())).First().Value;
            return result;
        }

    }
}
