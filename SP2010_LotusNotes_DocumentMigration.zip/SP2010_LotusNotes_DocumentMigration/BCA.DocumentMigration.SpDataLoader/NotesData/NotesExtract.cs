﻿using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using BCA.DocumentMigration.SpDataLoader.Rules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Threading;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class NotesExtract
    {
        protected int _numerOfThreadsNotYetCompleted;
        protected volatile bool _filledSharePointToNotesFieldMap = false;
        public int LogsId { get; set; }
        public string DbName { get; set; }
        public string FileName { get; set; }
        public List<string> Header { get; set; }
        public ConcurrentQueue<NotesDocument> Documents { get; set; }
        public NotesDatabases DbType { get; set; }
        public Logs ReportLog { get; set; }

        public NotesExtract(string dbName, string fileName, List<string> header, ConcurrentQueue<NotesDocument> documents, NotesDatabases dbType, int logsId)
        {
            this.DbName = dbName;
            this.FileName = fileName;
            this.Header = header;
            this.Documents = documents;
            this.DbType = dbType;
            this.LogsId = logsId;
        }
        public NotesExtract()
        {

        }
        
        /// <summary>
        /// Creates collection of DocSet objects from lotus notes extract in excel file
        /// </summary>
        /// <param name="skipAttachments"></param>
        /// <returns></returns>
        public virtual ConcurrentQueue<DocSet> ProcessExtract(bool skipAttachments = false)
        {
            ReportLog = HelperClass.ReportLogs[LogsId];
            TraceFile.WriteLine("Filtering {0}\n", this.FileName);
            //New collection of DocSet object
            ConcurrentQueue<SharepointData.DocSet> documentSets = new ConcurrentQueue<SharepointData.DocSet>();
            // Get filtering rules from JSON files
            RulesEngine rulesEngine = GetRulesEngine();
            List<NotesSharepointMapping> mappings = GetSharepointMapping();

            HelperClass.FillDataStructuresForFields(rulesEngine.Rules, mappings, DbType);

            AutoResetEvent threadEvent = new AutoResetEvent(false);
            _numerOfThreadsNotYetCompleted = Documents.Count;
            int i = 0;

            while (Documents.Count > 0)
            {
                NotesDocument document = null;
                bool deQueue = Documents.TryDequeue(out document);
                ThreadPool.QueueUserWorkItem(delegate (object o)
                {
                    TraceFile.WriteLine(true, "Starting thread number: {0}", (int)o);

                    if (deQueue)
                    {
                        Log log = ReportLog.GetLog(document.Uid);
                        if (FilterDocument(document, rulesEngine, log, skipAttachments))
                        {
                            DocSet ds = GetDocumentSet(document, mappings, log);
                            documentSets.Enqueue(ds);
                        }
                    }

                    TraceFile.WriteLine(true, "Finished thread number: {0}", (int)o);

                    if (Interlocked.Decrement(ref _numerOfThreadsNotYetCompleted) == 0)
                    {
                        threadEvent.Set();
                    }
                }, i);
                i++;
            }
            threadEvent.WaitOne();
            TraceFile.WriteLine("DocumentSets Length: {0}", documentSets.Count);
            return documentSets;
        }
        protected virtual SharepointData.DocSet GetDocumentSet(NotesDocument doc, List<NotesSharepointMapping> mappings, Log log)
        {            
            //string categories = doc.GetAttribute(Constants.Categories);
            DocSet ds = new DocSet(DbType);
            ds.Uid = doc.GetAttribute(DataLoader.Default.Uid);
            foreach (var mapping in mappings)
            {
                string mappedValue;
                if (!_filledSharePointToNotesFieldMap)
                {
                    foreach (var notesField in mapping.GetNotesFields())
                    {
                        HelperClass.SharePointToNotesFieldMap.GetOrAdd(mapping.Sharepoint, notesField);
                    }
                }
                if (mapping.FindExactMapping(doc, out mappedValue) ||
                    mapping.FindRuleMapping(doc, out mappedValue) ||
                    mapping.FindCustomMapping(doc, out mappedValue) ||
                    mapping.ApplyCustomMethod(doc, ds.Attributes, out mappedValue) ||
                    mapping.FindSharepointToSharepointMapping(ds.Attributes, out mappedValue) ||
                    mapping.UseNotesValueIfNoMatch(doc.Attributes, out mappedValue) ||
                    mapping.UseDefault(out mappedValue))
                {
                    ds.Attributes.Add(mapping.Sharepoint, mappedValue);
                }
                else
                {
                    ds.Attributes.Add(mapping.Sharepoint, string.Empty);
                    TraceFile.WriteLine("No action taken for the following mapping:\n{0}", mapping.ToString());
                    string[] notesFields = mapping.GetNotesFields();
                    ReportLog.AddTransformationRule(log, false, string.Empty,
                             notesFields != null && notesFields.Length > 0 ? notesFields : new string[] { mapping.Sharepoint + "(SP)" });
                }
            }

            if (!_filledSharePointToNotesFieldMap)
            {
                _filledSharePointToNotesFieldMap = true;
            }

            ds.Attachments = (doc.Attachments.ToDictionary(a => a, a => string.Empty));

            ExtraStepsAfterTransformationRules(log, ds);
            
            if (ds.Attributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField))
            {
                ds.DocumentType = ds.Attributes[DataLoader.Default.SharePointDocumentTypeField]; //HelperClass.CategoriesToDocTypeMap[categories];
            }

            if (ds.Attributes.ContainsKey(DataLoader.Default.SharePointDocumentGroupField))
            {
                ds.DocumentGroup = ds.Attributes[DataLoader.Default.SharePointDocumentGroupField];//HelperClass.DocTypeToGroupMap[ds.DocumentType];
            }

            //if (ds.Attributes.ContainsKey(DataLoader.Default.SharePointNameField))
            //{
            //    ds.Name = ds.Attributes[DataLoader.Default.SharePointNameField];
            //}

            ds.Name = HelperClass.UnidToGuid(ds.Uid);

            if (ds.Attributes.ContainsKey(DataLoader.Default.SharePointAircrafFamilyField) &&
                !string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharePointAircrafFamilyField]))
            {                
                ds.SubFolder = HelperClass.GetClosestMatch(ds.Attributes[DataLoader.Default.SharePointAircrafFamilyField], Constants.SharePointSubFolders);
            }
            else
            {
                TraceFile.WriteLine("{0} - Sharepoint Aircraft Family field '{1}' Not Found", ds.Uid, DataLoader.Default.SharePointAircrafFamilyField);
            }

            ds.ValidateAttachments(ReportLog, log);
            ReportLog.AddSharePointAttributes(log, ds.Attributes);
            ReportLog.AddTypes(log, ds.DocumentGroup, ds.DocumentType);
            ds.CheckMandatoryAndSize(ReportLog, log);
            if (log.Success && LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA)
            {
                ds.PrepareAttributesForSharepoint(log);
            }
            return ds;
        }
        protected virtual void ExtraStepsAfterTransformationRules(Log log, DocSet ds)
        {            
        }
        protected virtual bool FilterDocument(NotesDocument document, RulesEngine rulesEngine, Log log, bool skipAttachments = false)
        {
            //TraceFile.WriteLine("Current item: {0}", document.Attributes.ToDebugString());
            ReportLog.AddNotesAttributes(log, document.Attributes);
            document.HasAttachments = document.Attachments != null && document.Attachments.Count > 0;

            if (!skipAttachments && !document.HasAttachments)
            {
                ReportLog.AddFilesAttached(log, false);
            }
            if (rulesEngine.MatchesAllRulesNotesDocument(document, ReportLog, log))
            {
                document.Keep = true;
            }
            else
            {
                document.Keep = false;
            }
            return document.Keep;
        }
        
        /// <summary>
        /// Reads SharePoint attribute mapping from JSON file and returns list of NotesSharepointMapping object
        /// </summary>
        /// <returns>list of NotesSharepointMapping objects</returns>
        protected List<NotesSharepointMapping> GetSharepointMapping() 
        {
            List<NotesSharepointMapping> mappings = new List<NotesSharepointMapping>();          
            switch (DbType)
            {
                case NotesDatabases.THDTorontoLibrary:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.THDTorontoLibrarySharepointMappingPath));
                    break;
                case NotesDatabases.THDLibrary:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.THDLibrarySharepointMappingPath));
                    break;                    
                case NotesDatabases.WorkingGroups:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.WorkingGroupsSharepointMappingPath));
                    break;
                case NotesDatabases.SBCRJCoverLetter:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.SB_CRJ_CoverLetterSharepointMappingPath));
                    break;
                case NotesDatabases.SBCRJPDFDocument:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.SB_CRJ_PDF_DocumentSharepointMappingPath));
                    break;
                case NotesDatabases.SBCRJServiceBulletin:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.SB_CRJ_ServiceBulletinSharepointMappingPath));
                    break;
                case NotesDatabases.TISBDASH:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.SB_DashSharepointMappingPath));
                    break;
                case NotesDatabases.TITechManualStatus:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.TiTechManualStatusSharepointMappingPath));
                    break;
                case NotesDatabases.CSeriesSharePoint2010:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.SP2010SharepointMappingPath));
                    break;
                case NotesDatabases.WorkingGroupsPresentationsMeetingMinutes:
                    mappings.AddRange((List<NotesSharepointMapping>)JsonHelper.ParseJson<NotesSharepointMapping>(DataLoader.Default.WorkingGroupsPresentationsMeetingMinutesSharepointMappingPath));
                    break;
                default:
                    break;
            }
            foreach (var mapping in mappings)
            {
                mapping.NormalizeSharepointAttributesNames();
            }
            return mappings;
        }

        /// <summary>
        /// Read filtering rules from JSON files and assign it to RulesEngine object's Rules property
        /// </summary>
        /// <returns>RulesEngine object</returns>
        protected RulesEngine GetRulesEngine()
        {
            RulesEngine rulesEngine = null;
            switch (DbType)
            {
                case NotesDatabases.THDTorontoLibrary:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.THDTorontoLibraryFilteringRulesPath);
                    break;
                case NotesDatabases.THDLibrary:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.THDLibraryFilteringRulesPath);
                    break;
                case NotesDatabases.WorkingGroups:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.WorkingGroupsFilteringRulesPath);
                    break;
                case NotesDatabases.SBCRJCoverLetter:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.SB_CRJ_CoverLetterFilterRulesPath);
                    break;
                case NotesDatabases.SBCRJPDFDocument:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.SB_CRJ_PDF_DocumentFilteringRulesPath);
                    break;
                case NotesDatabases.SBCRJServiceBulletin:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.SB_CRJ_ServiceBulletinFilterRulesPath);
                    break;
                case NotesDatabases.TISBDASH:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.SB_DashFilterRulesPath);
                    break;
                case NotesDatabases.TITechManualStatus:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.TiTechManualStatusFilterRulesPath);
                    break;
                case NotesDatabases.CSeriesSharePoint2010:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.SP2010FilteringRulesPath);
                    break;
                case NotesDatabases.WorkingGroupsPresentationsMeetingMinutes:
                    rulesEngine = new RulesEngine();
                    rulesEngine.Rules = (List<Rule>)JsonHelper.ParseJson<Rule>(DataLoader.Default.WorkingGroupsPresentationsMeetingMinutesFilteringRulesPath);
                    break;
                default:
                    break;
            }
            return rulesEngine;
        }
    }
}
