﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class NotesRow
    {
        public List<string> Data { get; set; }
        public List<string> ErrorFields { get; set; }

        public NotesRow()
        {

        }
        public NotesRow(List<string> data, List<string> errorFields)
        {
            this.Data = data;
            this.ErrorFields = errorFields;
        }
    }
}
