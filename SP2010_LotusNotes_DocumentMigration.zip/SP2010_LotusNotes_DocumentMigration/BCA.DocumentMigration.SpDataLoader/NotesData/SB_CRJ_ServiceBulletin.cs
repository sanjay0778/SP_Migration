﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    class SB_CRJ_ServiceBulletin : NotesExtract
    {
        public SB_CRJ_ServiceBulletin(string dbName, string fileName, List<string> header, ConcurrentQueue<NotesDocument> documents, NotesDatabases dbType, int logsId)
            : base(dbName, fileName, header, documents, dbType, logsId)
        {

        }
        public SB_CRJ_ServiceBulletin() : base()
        {

        }
        protected override bool FilterDocument(NotesDocument document, RulesEngine rulesEngine, Log log, bool skipAttachments = false)
        {
            //TraceFile.WriteLine("Current item: {0}", document.Attributes.ToDebugString());
            ReportLog.AddNotesAttributes(log, document.Attributes);
            document.HasAttachments = document.Attachments != null && document.Attachments.Count > 0;

            if (!skipAttachments && !document.HasAttachments)
            {
                ReportLog.AddFilesAttached(log, false);
            }
            if (HelperClass.ServiceBulletinWhitelist.Contains(log.Uid, StringComparer.OrdinalIgnoreCase))
            {
                if (HelperClass.AtaBlacklist.Contains(log.Uid, StringComparer.OrdinalIgnoreCase))
                {
                    ReportLog.AddFilteringRule(log, false, DataLoader.Default.ReportError_AtaExclusion, null);
                    document.Keep = false;
                }
                else
                {
                    document.Keep = true;
                }                
            }
            else
            {
                ReportLog.AddFilteringRule(log, false, DataLoader.Default.ReportError_ServiceBulletinExclusion, null);
                document.Keep = false;
            }
            return document.Keep;
        }
        protected override void ExtraStepsAfterTransformationRules(Log log, DocSet ds)
        {
            if (!string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()]) &&
                !string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointModelNumberField.Trim()]))
            {
                string emptyModels;
                string effectivity;
                if (HelperClass.BuildEffectivity(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()], out effectivity, ds.Attributes, out emptyModels))
                {
                    if (!string.IsNullOrWhiteSpace(emptyModels))
                    {
                        log.EmptyEffectivityModels = emptyModels.Trim();
                        HelperClass.AdjustEffectivityEmptyModelsGlobal(effectivity, log.EmptyEffectivityModels, ds.Attributes);
                    }
                    else
                    {
                        ds.Attributes[DataLoader.Default.SharepointEffectivityField] = effectivity;
                    }
                }
                else
                {
                    ReportLog.AddTransformationRule(log, false, DataLoader.Default.ReportError_Transformation_Effectivity,
                      HelperClass.SharePointToNotesFieldMap.ContainsKey(DataLoader.Default.SharepointEffectivityField) ?
                      new string[] { HelperClass.SharePointToNotesFieldMap[DataLoader.Default.SharepointEffectivityField] } :
                      new string[] { DataLoader.Default.SharepointEffectivityField + "(SP)" });
                }
            }
        }
    }
}
