﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class SB_Dash : NotesExtract
    {
        public SB_Dash(string dbName, string fileName, List<string> header, ConcurrentQueue<NotesDocument> documents, NotesDatabases dbType, int logsId)
            : base(dbName, fileName, header, documents, dbType, logsId)
        {

        }
        public SB_Dash() : base()
        {

        }
        protected override bool FilterDocument(NotesDocument document, RulesEngine rulesEngine, Log log, bool skipAttachments = false)
        {
            //TraceFile.WriteLine("Current item: {0}", document.Attributes.ToDebugString());
            ReportLog.AddNotesAttributes(log, document.Attributes);
            document.HasAttachments = document.Attachments != null && document.Attachments.Count > 0;

            if (!skipAttachments && !document.HasAttachments)
            {
                ReportLog.AddFilesAttached(log, false);
            }
            if (rulesEngine.MatchesAllRulesNotesDocument(document, ReportLog, log))
            {
                if (HelperClass.AtaBlacklist.Contains(log.Uid, StringComparer.OrdinalIgnoreCase))
                {
                    ReportLog.AddFilteringRule(log, false, DataLoader.Default.ReportError_AtaExclusion, null);
                    document.Keep = false;
                }
                else
                {
                    document.Keep = true;
                }                
            }
            else
            {
                document.Keep = false;
            }
            return document.Keep;
        }
        protected override void ExtraStepsAfterTransformationRules(Log log, DocSet ds)
        {
            if (!string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()]) &&
                !string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointModelNumberField.Trim()]))
            {
                string emptyModels;
                string effectivity;
                if (HelperClass.BuildEffectivity(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()], out effectivity, ds.Attributes, out emptyModels))
                {
                    if (!string.IsNullOrWhiteSpace(emptyModels))
                    {
                        log.EmptyEffectivityModels = emptyModels.Trim();
                        HelperClass.AdjustEffectivityEmptyModelsGlobal(effectivity, log.EmptyEffectivityModels, ds.Attributes);
                    }
                    else
                    {
                        ds.Attributes[DataLoader.Default.SharepointEffectivityField] = effectivity;
                    }
                }
                else
                {
                    effectivity = null;
                    emptyModels = null;

                    if (HelperClass.BuildEffectivity(RulesConfiguration.Default.SB_DASH_EFFECTIVITY_DEFAULT.Trim(), out effectivity, ds.Attributes, out emptyModels))
                    {
                        ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()] = effectivity;
                        TraceFile.WriteLine("{0} SB DASH - ExtraStepsAfterTransformationRules - ASSIGNED ALL EFFECTIVITY '{1}' TO INVALID CASE", log.Uid, effectivity);
                    }
                    else
                    {
                        TraceFile.WriteLine("SB DASH - ExtraStepsAfterTransformationRules - ERROR ASSIGNING ALL EFFECTIVITY TO INVALID CASE");
                    }

                    //ReportLog.AddTransformationRule(log, false, DataLoader.Default.ReportError_Transformation_Effectivity,
                    //  HelperClass.SharePointToNotesFieldMap.ContainsKey(DataLoader.Default.SharepointEffectivityField) ?
                    //  new string[] { HelperClass.SharePointToNotesFieldMap[DataLoader.Default.SharepointEffectivityField] } :
                    //  new string[] { DataLoader.Default.SharepointEffectivityField + "(SP)" });
                }
            }
        }
    }
}
