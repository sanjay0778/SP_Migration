﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class SP2010 : NotesExtract
    {
        public SP2010(string dbName, string fileName, List<string> header, ConcurrentQueue<NotesDocument> documents, NotesDatabases dbType, int logsId)
            : base(dbName, fileName, header, documents, dbType, logsId)
        {

        }
        public SP2010() : base()
        {

        }
    }
}
