﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class THDLibrary : NotesExtract
    {
        public THDLibrary(string dbName, string fileName, List<string> header, ConcurrentQueue<NotesDocument> documents, NotesDatabases dbType, int logsId)
            : base(dbName, fileName, header, documents, dbType, logsId)
        {

        }
        public THDLibrary() : base()
        {

        }
        protected override bool FilterDocument(NotesDocument document, RulesEngine rulesEngine, Log log, bool skipAttachments = false)
        {
            //TraceFile.WriteLine("Current item: {0}", document.Attributes.ToDebugString());
            ReportLog.AddNotesAttributes(log, document.Attributes);
            document.HasAttachments = document.Attachments != null && document.Attachments.Count > 0;

            //if (!skipAttachments && !document.HasAttachments)
            //{
            //    ReportLog.AddFilesAttached(log, false);
            //}
            if (rulesEngine.MatchesAllRulesNotesDocument(document, ReportLog, log))
            {
                document.Keep = true;
            }
            else
            {
                document.Keep = false;
            }
            return document.Keep;
        }
        protected override void ExtraStepsAfterTransformationRules(Log log, DocSet ds)
        {
            bool availableOnPortalSet = false;
            if (ds.Attachments == null || ds.Attachments.Count == 0)
            {
                // is it same object being updated twice? Test
                ds.Attributes[DataLoader.Default.SharepointAvailableOnPortal] = "No";
                availableOnPortalSet = true;
                //log.SharePointAttributes[DataLoader.Default.SharepointAvailableOnPortal] = "No";
            }

            if (!string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()]) &&
                !string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointModelNumberField.Trim()]))
            {
                string emptyModels;
                string effectivity;
                if (HelperClass.BuildEffectivity(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()], out effectivity, ds.Attributes, out emptyModels))
                {
                    if (!string.IsNullOrWhiteSpace(emptyModels))
                    {
                        log.EmptyEffectivityModels = emptyModels.Trim();
                        HelperClass.AdjustEffectivityEmptyModelsTHD(effectivity, log.EmptyEffectivityModels, ds.Attributes);
                    }
                    else
                    {
                        ds.Attributes[DataLoader.Default.SharepointEffectivityField] = effectivity;
                    }
                    if (!availableOnPortalSet)
                    {
                        ds.Attributes[DataLoader.Default.SharepointAvailableOnPortal] = "Yes";
                    }                    
                }
                else
                {
                    if (!availableOnPortalSet)
                    {
                        ds.Attributes[DataLoader.Default.SharepointAvailableOnPortal] = "No";
                    }

                    ds.Attributes[DataLoader.Default.SharepointPartSerialNumberField] = log.NotesAttributes[RulesConfiguration.Default.THD_LIBRARY_NOTES_EFFECTIVITY_FIELD];

                    effectivity = null;
                    emptyModels = null;

                    if (HelperClass.BuildEffectivity(RulesConfiguration.Default.THD_LIBRARY_EFFECTIVITY_DEFAULT.Trim(), out effectivity, ds.Attributes, out emptyModels))
                    {
                        ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()] = effectivity;
                        ds.Attributes[DataLoader.Default.SharepointAvailableOnPortal]       = "No";
                        ds.Attributes[DataLoader.Default.SharepointPartSerialNumberField]   = log.NotesAttributes[RulesConfiguration.Default.THD_LIBRARY_NOTES_EFFECTIVITY_FIELD] == null ? string.Empty :
                            log.NotesAttributes[RulesConfiguration.Default.THD_LIBRARY_NOTES_EFFECTIVITY_FIELD].Trim();
                        TraceFile.WriteLine("{0} THD Library - ExtraStepsAfterTransformationRules - ASSIGNED ALL EFFECTIVITY '{1}' TO INVALID CASE", log.Uid, effectivity);
                    }
                    else
                    {
                        TraceFile.WriteLine("THD Library - ExtraStepsAfterTransformationRules - ERROR ASSIGNING ALL EFFECTIVITY TO INVALID CASE");
                    }
                    
                    //ReportLog.AddTransformationRule(log, false, DataLoader.Default.ReportError_Transformation_Effectivity,
                    //  HelperClass.SharePointToNotesFieldMap.ContainsKey(DataLoader.Default.SharepointEffectivityField) ?
                    //  new string[] { HelperClass.SharePointToNotesFieldMap[DataLoader.Default.SharepointEffectivityField] } :
                    //  new string[] { DataLoader.Default.SharepointEffectivityField + "(SP)" });
                }
            }
        }
    }
}
