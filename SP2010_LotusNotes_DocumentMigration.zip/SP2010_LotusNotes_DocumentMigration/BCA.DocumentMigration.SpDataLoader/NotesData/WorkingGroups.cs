﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class WorkingGroups : NotesExtract
    {
        public WorkingGroups(string dbName, string fileName, List<string> header, ConcurrentQueue<NotesDocument> documents, NotesDatabases dbType, int logsId)
            : base(dbName, fileName, header, documents, dbType, logsId)
        {
            
        }
        public WorkingGroups() : base()
        {

        }
        //public List<SharepointData.DocSet> MapToSharepoint()
        //{ 
        //    List<NotesSharepointMapping> mappings = GetSharepointMapping();
        //    HelperClass.AddUsedNotesFields(mappings);
        //    List<SharepointData.DocSet> documentSets = new List<SharepointData.DocSet>();
        //    bool filledSharePointToNotesFieldMap = false;
        //    foreach (var doc in Documents.Where(d => d.Keep))
        //    {
        //        string categories = doc.GetAttribute(Constants.Categories);
        //        DocSet ds = new DocSet(DbType);
        //        ds.Uid = doc.GetAttribute(DataLoader.Default.Uid);
        //        foreach (var mapping in mappings)
        //        {
        //            if (!filledSharePointToNotesFieldMap && !string.IsNullOrWhiteSpace(mapping.Notes) && !string.IsNullOrWhiteSpace(mapping.Sharepoint))
        //            {
        //                HelperClass.SharePointToNotesFieldMap.GetOrAdd(mapping.Sharepoint, mapping.Notes);
        //            }
        //            if (!string.IsNullOrWhiteSpace(mapping.Notes) && doc.Attributes.ContainsKey(mapping.Notes))
        //            {
        //                if (mapping.AllOptionalFieldsNotSet())
        //                {
        //                    ds.Attributes.Add(mapping.Sharepoint, doc.Attributes[mapping.Notes]);
        //                    Logs.Instance.AddTransformationRule(ds.Uid, true, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //                }
        //                else if (mapping.ValuesMapping != null && mapping.ValuesMapping.Length >= 1 && !mapping.UseLnValueIfNoMatch)
        //                {
        //                    string spValue = mapping.FindValueMapping(doc.Attributes[mapping.Notes]);
        //                    if (!string.IsNullOrWhiteSpace(spValue))
        //                    {
        //                        ds.Attributes.Add(mapping.Sharepoint, spValue);
        //                        Logs.Instance.AddTransformationRule(ds.Uid, true, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //                    }
        //                    else
        //                    {
        //                        TraceFile.WriteLine("Failed to find a matching List Value for SharePoint field \"{0}\" with LN value \"{1}\"", mapping.Sharepoint, doc.Attributes[mapping.Notes]);
        //                        Logs.Instance.AddTransformationRule(ds.Uid, false, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //                    }
        //                }
        //                else if (mapping.ValuesMapping != null && mapping.ValuesMapping.Length >= 1 && mapping.UseLnValueIfNoMatch)
        //                {
        //                    string spValue = mapping.FindValueMapping(doc.Attributes[mapping.Notes]);
        //                    if (!string.IsNullOrWhiteSpace(spValue))
        //                    {
        //                        ds.Attributes.Add(mapping.Sharepoint, spValue);
        //                        Logs.Instance.AddTransformationRule(ds.Uid, true, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //                    }
        //                    else
        //                    {
        //                        ds.Attributes.Add(mapping.Sharepoint, doc.Attributes[mapping.Notes]);
        //                        TraceFile.WriteLine("No mapping found, instead using direct LN value \"{0}\" as List Value for SharePoint field \"{1}\"", doc.Attributes[mapping.Notes], mapping.Sharepoint);
        //                        Logs.Instance.AddTransformationRule(ds.Uid, true, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //                    }
        //                }
        //            }
        //            else if (string.IsNullOrWhiteSpace(mapping.Notes) && !string.IsNullOrWhiteSpace(mapping.Default))
        //            {
        //                ds.Attributes.Add(mapping.Sharepoint, mapping.Default);
        //                Logs.Instance.AddTransformationRule(ds.Uid, true, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //            }
        //            else if (string.IsNullOrWhiteSpace(mapping.Notes) && string.IsNullOrWhiteSpace(mapping.Default) && !string.IsNullOrWhiteSpace(mapping.DependsOnLnField) &&
        //                     mapping.ValuesMapping != null && mapping.ValuesMapping.Length >= 1 && doc.Attributes.ContainsKey(mapping.DependsOnLnField))
        //            {
        //                string spValue = mapping.FindValueMapping(doc.Attributes[mapping.DependsOnLnField]);
        //                if (!string.IsNullOrWhiteSpace(spValue))
        //                {
        //                    ds.Attributes.Add(mapping.Sharepoint, spValue);
        //                    Logs.Instance.AddTransformationRule(ds.Uid, true, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //                }
        //                else
        //                {
        //                    TraceFile.WriteLine("Failed to find a matching List Value for SharePoint field \"{0}\" with LN value \"{1}\"", mapping.Sharepoint, doc.Attributes[mapping.Notes]);
        //                    Logs.Instance.AddTransformationRule(ds.Uid, false, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //                }
        //            }
        //            else
        //            {
        //                TraceFile.WriteLine("No action taken for the following mapping:\n{0}", mapping.ToString());
        //                Logs.Instance.AddTransformationRule(ds.Uid, false, mapping.ToString(),
        //                        !string.IsNullOrWhiteSpace(mapping.Notes) ? mapping.Notes : mapping.Sharepoint + "(SP)");
        //            }
        //        }
        //        if (!filledSharePointToNotesFieldMap)
        //        {
        //            filledSharePointToNotesFieldMap = true;
        //        }
        //        ds.Attachments.AddRange(doc.Attachments);
        //        ds.DocumentType  = HelperClass.CategoriesToDocTypeMap[categories];
        //        ds.DocumentGroup = HelperClass.DocTypeToGroupMap[ds.DocumentType];

        //        ds.Name      = ds.Attributes[DataLoader.Default.SharePointNameField];
        //        ds.SubFolder = HelperClass.GetClosestMatch(ds.Attributes[DataLoader.Default.SharePointAircrafFamilyField], Constants.SharePointSubFolders);
        //        ds.ValidateAttachments(ReportLog, null);
        //        documentSets.Add(ds);
        //        Logs.Instance.AddSharePointAttributes(ds.Uid, ds.Attributes);
        //        Logs.Instance.AddTypes(ds.Uid, ds.DocumentGroup, ds.DocumentType);
        //    }
        //    return documentSets;
        //}
    }
}
