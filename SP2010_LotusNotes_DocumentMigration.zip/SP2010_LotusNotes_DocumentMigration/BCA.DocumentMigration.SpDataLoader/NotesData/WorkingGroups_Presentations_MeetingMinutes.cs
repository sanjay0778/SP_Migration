﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.NotesData
{
    public class WorkingGroups_Presentations_MeetingMinutes : NotesExtract
    {
        public WorkingGroups_Presentations_MeetingMinutes(string dbName, string fileName, List<string> header, ConcurrentQueue<NotesDocument> documents, NotesDatabases dbType, int logsId)
            : base(dbName, fileName, header, documents, dbType, logsId)
        {

        }
        public WorkingGroups_Presentations_MeetingMinutes() : base()
        {

        }

        protected override bool FilterDocument(NotesDocument document, RulesEngine rulesEngine, Log log, bool skipAttachments = false)
        {
            //TraceFile.WriteLine("Current item: {0}", document.Attributes.ToDebugString());
            ReportLog.AddNotesAttributes(log, document.Attributes);
            document.HasAttachments = document.Attachments != null && document.Attachments.Count > 0;

            if (!skipAttachments && !document.HasAttachments)
            {
                document.Keep = false;
                ReportLog.AddFilteringRule(log, false, DataLoader.Default.ReportError_Attachments, null);
                //ReportLog.AddFilesAttached(log, false);
            }
            if (rulesEngine.MatchesAllRulesNotesDocument(document, ReportLog, log) && (skipAttachments || document.HasAttachments))
            {
                document.Keep = true;
            }
            else
            {
                document.Keep = false;
            }
            return document.Keep;
        }
        protected override void ExtraStepsAfterTransformationRules(Log log, DocSet ds)
        {
            if (!string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()]) &&
                !string.IsNullOrWhiteSpace(ds.Attributes[DataLoader.Default.SharepointModelNumberField.Trim()]))
            {
                string emptyModels;
                string effectivity;
                if (HelperClass.BuildEffectivity(ds.Attributes[DataLoader.Default.SharepointEffectivityField.Trim()], out effectivity, ds.Attributes, out emptyModels))
                {
                    if (!string.IsNullOrWhiteSpace(emptyModels))
                    {
                        log.EmptyEffectivityModels = emptyModels.Trim();
                        HelperClass.AdjustEffectivityEmptyModelsGlobal(effectivity, log.EmptyEffectivityModels, ds.Attributes);
                    }
                    else
                    {
                        ds.Attributes[DataLoader.Default.SharepointEffectivityField] = effectivity;
                    }
                    if (Constants.WorkingGroupsPresentationsMeetingMinutesEffectivityTranslationMap.ContainsKey(ds.Attributes[DataLoader.Default.SharepointEffectivityField]))
                    {
                        ds.Attributes[DataLoader.Default.SharepointEffectivityField] = Constants.WorkingGroupsPresentationsMeetingMinutesEffectivityTranslationMap[ds.Attributes[DataLoader.Default.SharepointEffectivityField]];
                    }
                }
                else
                {
                    ReportLog.AddTransformationRule(log, false, DataLoader.Default.ReportError_Transformation_Effectivity,
                      HelperClass.SharePointToNotesFieldMap.ContainsKey(DataLoader.Default.SharepointEffectivityField) ?
                      new string[] { HelperClass.SharePointToNotesFieldMap[DataLoader.Default.SharepointEffectivityField] } :
                      new string[] { DataLoader.Default.SharepointEffectivityField + "(SP)" });
                }
            }
        }
    }
}
