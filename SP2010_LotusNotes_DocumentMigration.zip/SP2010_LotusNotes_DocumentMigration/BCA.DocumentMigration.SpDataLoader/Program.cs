﻿using BCA.DocumentMigration.SpDataLoader.NotesData;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BCA.DocumentMigration.SpDataLoader
{
    public static class Program
    {
        /// <summary>
        /// Entry point of the program
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                //Create log file
                SetOutput(ref fileStream, ref streamWriter);
                //Print launch parameters to log file
                HelperClass.PrintLaunchParameters();
                //Read data from excel, csv and txt files and add it to object, array and list
                HelperClass.PrepareData();

                if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA)
                {
                    //Load all SharePoint web content types in object
                    InitializeSharepointData();
                }

                if (LaunchConfiguration.Default.WORKING_GROUPS || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting Working Groups\n***********************************************\n\n", true);
                    ProcessWorkingGroups(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }
                if (LaunchConfiguration.Default.WORKING_GROUPS_PRESENTATIONS_MEETINGMINUTES || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting Working Groups Presentations_MeetingMinutes\n***********************************************\n\n", true);
                    ProcessWorkingGroups_Presentations_MeetingMinutes(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }
                // Process THD_TORONTO_LIBRARY  documents
                if (LaunchConfiguration.Default.THD_TORONTO_LIBRARY || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting THD Toronto Library\n***********************************************\n\n", true);
                    ProcessTHDTorontoLibrary(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }

                if (LaunchConfiguration.Default.THD_LIBRARY || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting THD Library\n***********************************************\n\n", true);
                    ProcessTHDLibrary(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }

                if (LaunchConfiguration.Default.SB_CRJ_PDF_DOCUMENT || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting SB CRJ PDF Document\n***********************************************\n\n", true);
                    Process_SB_CRJ_PDF_DOCUMENT(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }

                if (LaunchConfiguration.Default.SB_CRJ_SERVICE_BULLETIN || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting SB CRJ Service Bulletin\n***********************************************\n\n", true);
                    Process_SB_CRJ_SERVICE_BULLETIN(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }
                if (LaunchConfiguration.Default.SB_CRJ_COVER_LETTER || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting SB CRJ Cover Letter\n***********************************************\n\n", true);
                    Process_SB_CRJ_COVER_LETTER(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }
                if (LaunchConfiguration.Default.SB_DASH || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting SB Dash\n***********************************************\n\n", true);
                    Process_SB_DASH(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }
                if (LaunchConfiguration.Default.TI_TECH_MANUAL_STATUS || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting TI Tech Manual Status\n***********************************************\n\n", true);
                    ProcessTiTechManualStatus(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }
                if (LaunchConfiguration.Default.SP_2010 || LaunchConfiguration.Default.RUN_ALL_DBS)
                {
                    TraceFile.WriteLine("\n\n***********************************************\nStarting SP 2010\n***********************************************\n\n", true);
                    ProcessSP2010(LaunchConfiguration.Default.SKIP_ATTACHMENTS);
                }
                if (HelperClass.UnidToGuidMapping != null && HelperClass.UnidToGuidMapping.Count > 0)
                {
                    Serializer.Serialize(HelperClass.UnidToGuidMapping.ToDictionary(d => d.Key, d => d.Value), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                        DataLoader.Default.SerializedUnidToGuid));
                }

                if (LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
                {
                    HelperClass.PrintSharepointMigrationExceptions();
                }
            }
            catch (Exception e)
            {
                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
            }
            finally
            {
                streamWriter.Close();
                fileStream.Close();
            }

        }

        /// <summary>
        /// Loads all the web content types in object
        /// </summary>
        private static void InitializeSharepointData()
        {
            if (LaunchConfiguration.Default.DELETE_DOCUMENTS_FROM_SHAREPOINT)
            {
                //Delete document sets uploaded by tool
                using (ClientContext context = new ClientContext(DataLoader.Default.SharepointUrl))
                {
                    context.RequestTimeout = LaunchConfiguration.Default.CSOM_REQUEST_TIMEOUT;
                    Web web = context.Web;
                    context.Load(web);
                    //Delete document sets uploaded by tool
                    SharePointHelper.DeleteDocumentSetsUploadedByScript(context, web);
                }

            }
            //check if .data (cached) file exist
            if (HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.SharepointSerializedContentTypes)))
            {
                HelperClass.ContentTypes = Serializer.Deserialize<List<SharePointContentType>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.SharepointSerializedContentTypes));
            }
            else
            {
                using (ClientContext context = new ClientContext(DataLoader.Default.SharepointUrl))
                {
                    Web web = context.Web;
                    context.Load(web);
                    string[] contentTypesList = HelperClass.DocTypeAttributes.Select(dta => dta.DocumentType.Trim()).Union(
                        HelperClass.DocTypeAttributes.Select(dta => HelperClass.GetDocumentSetContentType(dta.DocumentType.Trim()))).ToArray<string>();
                    TraceFile.WriteLine("contentTypesList - {0}", string.Join(", ", contentTypesList));
                    // Loads all web content types in object of SharePointContentType
                    SharePointHelper.SetContentTypesDetails(context, web, contentTypesList);
                    //SharePointHelper.SetContentTypesDetails(context, web, "Action Register", "Action Register" + " " + DataLoader.Default.ContentTypeDocumentSet);
                }
                //create directory for .data files
                Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                //create DocTypeAttribute.data data file
                Serializer.Serialize(HelperClass.ContentTypes, string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                       DataLoader.Default.SharepointSerializedContentTypes));
            }
        }
        private static void ProcessWorkingGroups(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_Working_Groups)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_Working_Groups));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;
                NotesExtract workingGroups = ExcelHelper.LoadNotesExtract(DataLoader.Default.WorkingGroupsExtractPath, NotesDatabases.WorkingGroups);
                logsId = workingGroups.LogsId;

                docSets = workingGroups.ProcessExtract(skipAttachments);

                workingGroups = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_Working_Groups));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.WorkingGroups, logsId);
            }
            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "Working Groups", DataLoader.Default.WorkingGroupsAttachmentsPath);
            }

            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                TraceFile.WriteLine("******** Entering Working Groups Export To Sharepoint", true);
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.WorkingGroupsAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }
        private static void ProcessWorkingGroups_Presentations_MeetingMinutes(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_Working_Groups_Presentations_Meeting_Minutes)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_Working_Groups_Presentations_Meeting_Minutes));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;
                NotesExtract workingGroups = ExcelHelper.LoadNotesExtract(DataLoader.Default.WorkingGroupsExtractPath, NotesDatabases.WorkingGroupsPresentationsMeetingMinutes);
                logsId = workingGroups.LogsId;

                docSets = workingGroups.ProcessExtract(skipAttachments);

                workingGroups = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_Working_Groups_Presentations_Meeting_Minutes));
                }
            }


            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.WorkingGroupsPresentationsMeetingMinutes, logsId);
            }
            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "Working Groups Presentations_MeetingMinutes", DataLoader.Default.WorkingGroupsAttachmentsPath);
            }

            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                TraceFile.WriteLine("******** Entering Working Groups Export To Sharepoint", true);
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.WorkingGroupsAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }
        private static void ProcessSP2010(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SP_2010)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SP_2010));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;
                NotesExtract sp2010 = ExcelHelper.LoadNotesExtract(DataLoader.Default.SP2010ExtractPath, NotesDatabases.CSeriesSharePoint2010);
                logsId = sp2010.LogsId;

                docSets = sp2010.ProcessExtract(skipAttachments);

                sp2010 = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_SP_2010));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.CSeriesSharePoint2010, logsId);
            }
            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "SP 2010", DataLoader.Default.SP2010AttachmentsPath);
            }

            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                TraceFile.WriteLine("******** Entering SP 2010 Export To Sharepoint", true);
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.SP2010AttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }

        /// <summary>
        /// Get Document Sets from lotus notes extract file
        /// </summary>
        /// <param name="skipAttachments"></param>
        private static void ProcessTHDTorontoLibrary(bool skipAttachments = false)
        {
            // clear all cached objects data
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            //Get Data for library from saved .data file
            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                    HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_THD_Toronto_Library)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_THD_Toronto_Library));
                //Get docsets from .data file
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }

            else
            {
                //if data file is not created, it will be created here
                firstRun = true;
                // Get lotus notes extract from excel file
                NotesExtract thdTorontoLibrary = ExcelHelper.LoadNotesExtract(DataLoader.Default.THDTorontoLibraryExtractPath, NotesDatabases.THDTorontoLibrary);

                logsId = thdTorontoLibrary.LogsId;
                //get all DocSets for this library
                docSets = thdTorontoLibrary.ProcessExtract(skipAttachments);

                thdTorontoLibrary = null;
                HelperClass.FreeMemory();

                //If serialize libraries then created saved object/ .data file
                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_THD_Toronto_Library));
                }
            }

            //If not serialized library or first run and generate report true then create report
            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.THDTorontoLibrary, logsId);
            }

            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "THD Toronto Library", DataLoader.Default.THDTorontoLibraryAttachmentsPath);
            }

            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.THDTorontoLibraryAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }
        private static void ProcessTHDLibrary(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            Dictionary<string, ConcurrentQueue<DocSet>> docSetCollections = null;
            List<int> logsIds = null;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_THD_Library)))
            {
                var deserializedLibrary = Serializer.Deserialize<Dictionary<string, List<DocSet>>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_THD_Library));
                docSetCollections = HelperClass.ToConcurrentCollection(deserializedLibrary);
            }
            else
            {
                firstRun = true;

                ConcurrentBag<NotesExtract> thdLibraries = ExcelHelper.LoadNotesExtracts(DataLoader.Default.THDLibraryExtractPath, NotesDatabases.THDLibrary);

                HelperClass.FreeMemory();

                docSetCollections = new Dictionary<string, ConcurrentQueue<DocSet>>();
                logsIds = new List<int>();

                //HelperClass.RemoveDuplicatesFromTHDLibrary(thdLibraries, "1999");

                foreach (var thdLibrary in thdLibraries)
                {
                    TraceFile.WriteLine(true, "Starting new extract");
                    logsIds.Add(thdLibrary.LogsId);
                    Logs logs = HelperClass.ReportLogs[thdLibrary.LogsId];
                    docSetCollections.Add(logs.Folder.Trim(), thdLibrary.ProcessExtract(skipAttachments));
                }

                thdLibraries = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Dictionary<string, List<DocSet>> docSetCollectionsForSerialization = HelperClass.ToSerializableCollection(docSetCollections);
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSetCollectionsForSerialization, string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_THD_Library));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                foreach (var logsId in logsIds)
                {
                    ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.THDLibrary, logsId);
                }
            }

            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSetCollections, "THD Library", HelperClass.ThdLibraryAttachmentPaths);
            }

            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                string[] yearsArray = HelperClass.StringCollectionToArray(LaunchConfiguration.Default.THD_LIBRARY_YEARS_TO_LOAD);

                foreach (var docSets in docSetCollections.Where(dsc => yearsArray.Contains(dsc.Key, StringComparer.OrdinalIgnoreCase)))
                {
                    TraceFile.WriteLine(true, "################# Starting Sharepoint Upload for THD Library {0} #################", docSets.Key);
                    SharePointHelper.ExportToSharepoint(docSets.Value, HelperClass.ThdLibraryAttachmentPaths[docSets.Key]);
                }
            }

            docSetCollections = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");

            //if (HelperClass.FilesExist("./THDLibrary.data", "./LOGS.data"))
            //{
            //    thdLibrary = Serializer.Deserialize<THDLibrary>(@"./THDLibrary.data");
            //    Logs.Instance = Serializer.Deserialize<Logs>(@"./LOGS.data");
            //}
            //else
            //{
            //    Logs.Instance.DataBase = NotesDatabases.THDLibrary;
            //    thdLibrary = ExcelHelper.LoadNotesExtracts(DataLoader.Default.THDLibraryExtractPath, NotesDatabases.THDLibrary);
            //    HelperClass.FreeMemory();
            //    Serializer.Serialize(thdLibrary, "./THDLibrary.data");
            //    Serializer.Serialize(Logs.Instance, "./LOGS.data");
            //}

        }
        private static void Process_SB_CRJ_PDF_DOCUMENT(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_CRJ_PDF_Document)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_CRJ_PDF_Document));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;

                NotesExtract notesExtract = ExcelHelper.LoadNotesExtract(DataLoader.Default.SB_CRJ_PDF_DocumentExtractPath, NotesDatabases.SBCRJPDFDocument);
                logsId = notesExtract.LogsId;

                docSets = notesExtract.ProcessExtract(skipAttachments);

                notesExtract = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_SB_CRJ_PDF_Document));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.SBCRJPDFDocument, logsId);
            }

            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "SB CRJ PDF Document", DataLoader.Default.SB_CRJ_PDF_DocumentAttachmentsPath);
            }

            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.SB_CRJ_PDF_DocumentAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }
        private static void Process_SB_CRJ_SERVICE_BULLETIN(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_CRJ_Service_Bulletin)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_CRJ_Service_Bulletin));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;

                NotesExtract notesExtract = ExcelHelper.LoadNotesExtract(DataLoader.Default.SB_CRJ_ServiceBulletinExtractPath, NotesDatabases.SBCRJServiceBulletin);
                logsId = notesExtract.LogsId;

                docSets = notesExtract.ProcessExtract(skipAttachments);

                notesExtract = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_SB_CRJ_Service_Bulletin));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.SBCRJServiceBulletin, logsId);
            }

            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "SB CRJ PDF Service Bulletin", DataLoader.Default.SB_CRJ_ServiceBulletinAttachmentsPath);
            }


            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.SB_CRJ_ServiceBulletinAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }
        private static void Process_SB_CRJ_COVER_LETTER(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_CRJ_Cover_Letter)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_CRJ_Cover_Letter));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;

                NotesExtract notesExtract = ExcelHelper.LoadNotesExtract(DataLoader.Default.SB_CRJ_CoverLetterExtractPath, NotesDatabases.SBCRJCoverLetter);
                logsId = notesExtract.LogsId;

                docSets = notesExtract.ProcessExtract(skipAttachments);

                notesExtract = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_SB_CRJ_Cover_Letter));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.SBCRJCoverLetter, logsId);
            }

            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "SB CRJ Cover Letter", DataLoader.Default.SB_CRJ_CoverLetterAttachmentsPath);
            }


            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.SB_CRJ_CoverLetterAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }
        private static void Process_SB_DASH(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_Dash)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_SB_Dash));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;

                NotesExtract notesExtract = ExcelHelper.LoadNotesExtract(DataLoader.Default.SB_DashExtractPath, NotesDatabases.TISBDASH);
                logsId = notesExtract.LogsId;

                docSets = notesExtract.ProcessExtract(skipAttachments);

                notesExtract = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_SB_Dash));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.TISBDASH, logsId);
            }

            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "SB Dash", DataLoader.Default.SB_DashAttachmentsPath);
            }


            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.SB_DashAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }
        private static void ProcessTiTechManualStatus(bool skipAttachments = false)
        {
            HelperClass.ResetReusableFields();

            ConcurrentQueue<DocSet> docSets;
            int logsId = -1;
            bool firstRun = false;

            if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES &&
                HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_TI_Tech_Manual)))
            {
                var deserializedLibrary = Serializer.Deserialize<List<DocSet>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.Serialized_TI_Tech_Manual));
                docSets = new ConcurrentQueue<DocSet>(deserializedLibrary);
            }
            else
            {
                firstRun = true;

                NotesExtract notesExtract = ExcelHelper.LoadNotesExtract(DataLoader.Default.TiTechManualStatusExtractPath, NotesDatabases.TITechManualStatus);
                logsId = notesExtract.LogsId;

                docSets = notesExtract.ProcessExtract(skipAttachments);

                notesExtract = null;
                HelperClass.FreeMemory();

                if (LaunchConfiguration.Default.SERIALIZE_LIBRARIES)
                {
                    Directory.CreateDirectory(DataLoader.Default.SavedObjectsPath);
                    Serializer.Serialize(docSets.ToList(), string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath,
                           DataLoader.Default.Serialized_TI_Tech_Manual));
                }
            }

            if ((!LaunchConfiguration.Default.SERIALIZE_LIBRARIES || firstRun) && LaunchConfiguration.Default.GENERATE_REPORT)
            {
                ExcelHelper.CreateExtractReportFromTemplate(NotesDatabases.TITechManualStatus, logsId);
            }

            HelperClass.FreeMemory();

            if (LaunchConfiguration.Default.PRINT_ATTACHMENTS_STATS)
            {
                HelperClass.PrintAttachmentStats(docSets, "TI Tech Manual Status", DataLoader.Default.TiTechManualStatusAttachmentsPath);
            }


            if (LaunchConfiguration.Default.LOAD_SHAREPOINT_DATA &&
                LaunchConfiguration.Default.EXPORT_TO_SHAREPOINT)
            {
                SharePointHelper.ExportToSharepoint(docSets, DataLoader.Default.TiTechManualStatusAttachmentsPath);
            }
            docSets = null;
            HelperClass.FreeMemory();

            TraceFile.WriteLine("DONE");
        }

        /// <summary>
        /// Creates log file
        /// </summary>
        /// <param name="fileStream"></param>
        /// <param name="streamWriter"></param>
        private static void SetOutput(ref FileStream fileStream, ref StreamWriter streamWriter)
        {
            //Creates log directory
            Directory.CreateDirectory(DataLoader.Default.LogsPath);
            //Creates log file
            fileStream = new FileStream(string.Format("{0}out_{1}.txt", DataLoader.Default.LogsPath, HelperClass.UnixTime()), FileMode.Append);
            streamWriter = new StreamWriter(fileStream);
            streamWriter.AutoFlush = true;
            Console.SetOut(streamWriter);
            Console.SetError(streamWriter);
        }
    }
}


// Execute the query to the server.
// context.ExecuteQuery();
//TraceFile.WriteLine(web.Title);

//var results = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.File>>();
//var resultsFolder = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.Folder>>();
//var fileProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
//var folderProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
//var lists = context.LoadQuery(web.Lists.Where(l => l.BaseType == BaseType.DocumentLibrary));
//context.ExecuteQuery();

//SharePointHelper.SetContentTypesDetails(context, web, "Action Register", "Action Register" + " " + DataLoader.Default.ContentTypeDocumentSet);

//foreach (var list in lists.Where(l => l.Title == "Engineering Document"))
//foreach (var list in lists.Where(l => l.Title.Contains("Document")))
//foreach (var list in lists)
//{
//    TraceFile.WriteLine("DocumentLibrary: " + list.Title + " --- Count: " + list.ItemCount);
//    //CreateDocumentSet(context, list);

//    //list.GetItems

//    //ContentType ct = context.Web.ContentTypes.GetById("0x0120D520");

//    //context.Load(ct);
//    //context.ExecuteQuery();

//    //TraceFile.WriteLine("Content Type BEFORE: " + ct.Name);

//    var items = list.GetItems(SharePointHelper.CreateAllFoldersQuery());

//    context.Load(items);
//    context.ExecuteQuery();

//    //TraceFile.WriteLine("Items Count: " + items.Count);

//    foreach (var listItem in items)
//    {
//        if (listItem == null || listItem.ContentType == null)
//        {
//            //TraceFile.WriteLine("Line 74");
//            // TraceFile.WriteLine(listItem == null ? "Null item " : "Null content type");
//            continue;
//        }
//        ContentType ctTemp = listItem.ContentType;
//        if (listItem.Folder != null)
//        {
//            Folder folder = listItem.Folder;
//            //SharePointHelper.LoadContext(context, ctTemp, folder);
//            context.Load(ctTemp, c => c.Name);
//            context.Load(folder, f => f.Name);
//            context.Load(folder, f => f.Properties);
//            context.ExecuteQuery();
//            //SharePointHelper.LoadContext(context, folder);


//            if (folder.IsObjectPropertyInstantiated("Name") && ctTemp.IsObjectPropertyInstantiated("Name"))
//            {
//                //TraceFile.WriteLine("Line 86");
//                // TraceFile.WriteLine("Content Type: " + ctTemp.Name + " --- Folder Name: " + folder.Name); //+ " --- Item Name: " + listItem.DisplayName);
//            }
//            else if (folder.IsObjectPropertyInstantiated("Properties"))
//            {
//                foreach (var item in folder.Properties.FieldValues)
//                {
//                    //TraceFile.WriteLine("Property: {0} - Name: {1}", item.Key, item.Value.ToString());
//                }
//            }
//            else
//            {
//                //TraceFile.WriteLine(!folder.IsObjectPropertyInstantiated("Name") ? "Folder issue" : "Content type issue");
//            }


//            //if (ctTemp.Name == null || folder.Name == null)
//            // {
//            //    TraceFile.WriteLine(ctTemp.Name == null ? "Null content type name" : "Null Folder Name");
//            //  }
//            //context.Load(folder.Name);
//            // context.ExecuteQuery();


//            //TraceFile.WriteLine("Content Type: " + ctTemp.Name);
//        }
//        else if (listItem.File != null)
//        {
//            Microsoft.SharePoint.Client.File file = listItem.File;
//            SharePointHelper.LoadContext(context, ctTemp, file);

//            //TraceFile.WriteLine("Content Type: " + ctTemp.Name + " --- File Name: " + file.Name); //+ " --- Item Name: " + listItem.DisplayName);
//        }
//        else
//        {
//            // TraceFile.WriteLine("Not a file, not a folder");
//        }
//        //var dnTemp = listItem.DisplayName;
//        //context.Load(ctTemp);
//        //context.Load(folder);
//        //context.ExecuteQuery();
//        //SharePointHelper.LoadContext(context, ctTemp, folder);


//        //TraceFile.WriteLine("Content Type: " + ctTemp.Name + " --- Name: " + folder.Name); //+ " --- Item Name: " + listItem.DisplayName);

//        //if (folder.Name.Contains("Francis"))
//        //{
//        //    //UploadFile(context, folder, @"\\Client\C$\Users\Public\Documents\Bombardier Citrix Share\Documents\BCA Document Migration\IBM BOX\Doc Migration SRS\Document Migration Process_One Portal.pdf");

//        //    //UploadFile(context, folder, @"\\Client\C$\Users\Public\Documents\Bombardier Citrix Share\Documents\BCA Document Migration\IBM BOX\Doc Migration SRS\Test File2.txt");

//        //    folderProperties.Clear();

//        //    folderProperties.Add("AircraftFamily", 4);
//        //    folderProperties.Add("AircraftModel", 4);
//        //    folderProperties.Add("Effectivity", "Challenger::853::All");
//        //    folderProperties.Add("Keywords", "TEST DOCUMENT SET BCA");

//        //    //UpdateFolderProperties(context, folder, folderProperties);

//        //    SharePointHelper.LoadContext(context, folder.Files);

//        //    //foreach (var file in folder.Files)
//        //    //{
//        //    //    fileProperties.Clear();
//        //    //    TraceFile.WriteLine("File: {0} --- {1} --- {2}", file.Name, file.Title, file.ServerRelativeUrl);

//        //    //    TraceFile.WriteLine("Adding AircraftFamly");
//        //    //    fileProperties.Add("AircraftFamily", 3);
//        //    //    TraceFile.WriteLine("Adding AircraftModel");
//        //    //    fileProperties.Add("AircraftModel", 3);
//        //    //    TraceFile.WriteLine("Adding Effectivity");
//        //    //    fileProperties.Add("Effectivity", "Challenger::852::All");
//        //    //    //CRJ Series::All CRJ Series::All

//        //    //    //UpdateFileProperties(context, file.ServerRelativeUrl, fileProperties);
//        //    //}

//        //}

//        //folder.Files.Add(
//    }

//    // context.Load(items, icol => icol.Include(i => i.File));
//    //results[list.Title] = items.Select(i => i.File);
//    //context.Load(items, icol => icol.Include(i => i.Folder));
//    //resultsFolder[list.Title] = items.Select(i => i.Folder);

//}
//context.ExecuteQuery();

//foreach (var result in resultsFolder)
//{
//    TraceFile.WriteLine("List: {0}", result.Key);
//    foreach (var folder in result.Value)
//    {
//        TraceFile.WriteLine("File: {0}", folder.Name);
//    }
//}  

//Print results
//foreach (var result in results)
//{
//    TraceFile.WriteLine("List: {0}", result.Key);
//    foreach (var file in result.Value)
//    {
//        TraceFile.WriteLine("File: {0}", file.Name);
//    }
//}    

//List list = web.Lists.GetByTitle("Documents");
//context.Load(list);
//context.Load(list.RootFolder);
//context.Load(list.RootFolder.Folders);
//context.Load(list.RootFolder.Files);
//context.ExecuteQuery();
//FolderCollection fcol = list.RootFolder.Folders;
//List<string> lstFile = new List<string>();
//foreach (Folder f in fcol)
//{
//    TraceFile.WriteLine(f.Name);
//    //if (f.Name == "EngineeringDocument")
//    if (f.Name != "fdsfdsfsdfsfsdfdsfdsfdsfsd44")
//    {
//        context.Load(f.Files);
//        context.ExecuteQuery();
//        FileCollection fileCol = f.Files;
//        FolderCollection folderCol = f.Folders;
//        foreach (Microsoft.SharePoint.Client.File file in fileCol)
//        {
//            lstFile.Add(file.Name);
//            TraceFile.WriteLine("-- " + file.Name);
//        }
//        foreach (Folder folder in folderCol)
//        {
//            lstFile.Add(folder.Name);
//            TraceFile.WriteLine("-- " + folder.Name);
//        }
//    }
//}                
