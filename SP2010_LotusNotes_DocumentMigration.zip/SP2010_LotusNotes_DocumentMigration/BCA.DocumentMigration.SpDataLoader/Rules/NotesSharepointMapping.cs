﻿using BCA.DocumentMigration.SpDataLoader.NotesData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Rules
{
    public class NotesSharepointMapping
    {
        public string Notes { get; set; }
        public string NotesFieldToAppend { get; set; }
        public string AppendFormat { get; set; }
        public string NotesFallback { get; set; }

        public string NotesFallback2 { get; set; }
        public string Sharepoint { get; set; }
        public string Default { get; set; }
        public string ValueIfNoAttachment { get; set; }
        public string DependsOnLnField { get; set; }

        public string DependsOnSpField { get; set; }

        public string[][] ValuesMapping { get; set; }

        public string[][] ValuesMapping_Sharepoint { get; set; }
        public Dictionary<string, Rule> RulesMapping { get; set; }
        //public List<KeyValuePair<string, Rule>> RulesMapping { get; set; }
        public string[][] CustomMapping { get; set; }

        public bool ForceDirectMapping { get; set; }
        public bool UseLnValueIfNoMatch { get; set; }
        public bool RulesMappingFirst { get; set; }
        public bool UseCustomMappingIfNoMatch { get; set; }
        public bool CustomMappingIgnoreCase { get; set; }
        public bool UseNotesIfRuleMappingTrue { get; set; }
        public bool UseNotesIfRuleMappingTrueAndRuleValueEmpty { get; set; }
        public bool UseCustomMethodLastIfNoMatch { get; set; }
        public bool DateValidation { get; set; }

        public string FieldIfRuleMappingTrue { get; set; }
        public string CustomMappingMode { get; set; }
        public string CustomMethod { get; set; }

        public bool AllOptionalFieldsNotSet()
        {
            return !UseLnValueIfNoMatch && (ValuesMapping == null || ValuesMapping.Length == 0) && string.IsNullOrWhiteSpace(Default) &&
                    string.IsNullOrWhiteSpace(DependsOnLnField) && string.IsNullOrWhiteSpace(DependsOnSpField);
        }
        //public bool AllOptionalFieldsNotSetRevised()
        //{
        //    return (ValuesMapping == null || ValuesMapping.Length <= 0) && (CustomMapping == null || CustomMapping.Length <= 0) && 
        //            (RulesMapping == null || RulesMapping.Count <= 0) && string.IsNullOrWhiteSpace(Default) && string.IsNullOrWhiteSpace(CustomMethod);
        //}
        public bool AllOptionalFieldsNotSetRevised()
        {
            return (ValuesMapping == null || ValuesMapping.Length <= 0) && (CustomMapping == null || CustomMapping.Length <= 0) &&
                    (RulesMapping == null || RulesMapping.Count <= 0) && string.IsNullOrWhiteSpace(CustomMethod);
        }
        public string FindValueMapping(string inputValue)
        {
            string match = null;
            if (ValuesMapping != null && ValuesMapping.Length > 0)
            {
                foreach (var valueMapping in ValuesMapping)
                {
                    if (valueMapping != null && valueMapping.Length > 1 && inputValue.Trim().Equals(valueMapping[0].Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        match = valueMapping[1].Trim();
                        break;
                    }
                }
            }
            return match;
        }

        internal bool UseDefault(out string mappedValue)
        {
            mappedValue = null;
            bool result = false;

            //if (!string.IsNullOrWhiteSpace(Default))
            if (Default != null)
            {
                mappedValue = Default;
                result = true;
            }
            return result;
        }
        internal bool UseNotesValueIfNoMatch(Dictionary<string, string> attributes, out string mappedValue)
        {
            mappedValue = null;
            bool result = false;

            // LNValueifNoMatch
            if (UseLnValueIfNoMatch && !string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes) &&
                !string.IsNullOrWhiteSpace(attributes[Notes]))
            {
                mappedValue = attributes[Notes];
                result = true;
            }
            return result;
        }

        private bool FindValueMapping(string inputValue, out string mappedValue, bool sharepointToSharepoint = false)
        {
            mappedValue = null;
            bool result = false;
            var mappings = sharepointToSharepoint ? ValuesMapping_Sharepoint : ValuesMapping;
            if (mappings != null && mappings.Length > 0)
            {
                foreach (var valueMapping in mappings)
                {
                    if (valueMapping != null && valueMapping.Length > 1 && inputValue.Trim().Equals(valueMapping[0].Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        mappedValue = valueMapping[1].Trim();
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }

        internal bool FindExactMapping(NotesDocument document, out string mappedValue)
        {
            mappedValue = null;
            bool result = false;
            var attributes = document.Attributes;
            //string Uid = attributes["UNID"].Trim();

            if (RulesMappingFirst && FindRuleMapping(document, out mappedValue))
            {
                result = true;
            }
            // special case if no attachment
            else if (!document.HasAttachments && !string.IsNullOrWhiteSpace(ValueIfNoAttachment))
            {
                mappedValue = ValueIfNoAttachment;
                result = true;
            }
            // direct mapping
            else if (!string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes) && !string.IsNullOrWhiteSpace(attributes[Notes]) &&
                CheckDateValidation(attributes[Notes]) && (ForceDirectMapping || AllOptionalFieldsNotSetRevised()))
            {
                if (string.IsNullOrWhiteSpace(NotesFieldToAppend) || string.IsNullOrWhiteSpace(AppendFormat) ||
                    !attributes.ContainsKey(NotesFieldToAppend) || string.IsNullOrWhiteSpace(attributes[NotesFieldToAppend]))
                {
                    mappedValue = attributes[Notes];
                }
                else
                {
                    mappedValue = string.Format(AppendFormat, attributes[Notes], attributes[NotesFieldToAppend]);
                }
                result = true;
            }
            // direct mapping, NotesFallback field
            else if (!string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes) && (string.IsNullOrWhiteSpace(attributes[Notes]) ||
                !CheckDateValidation(attributes[Notes])) && AllOptionalFieldsNotSetRevised() && !string.IsNullOrWhiteSpace(NotesFallback) &&
                attributes.ContainsKey(NotesFallback) && !string.IsNullOrWhiteSpace(attributes[NotesFallback]) && CheckDateValidation(attributes[NotesFallback]))
            {
                mappedValue = attributes[NotesFallback];
                result = true;
            }
            // direct mapping, NotesFallback2 field
            else if (!string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes) && (string.IsNullOrWhiteSpace(attributes[Notes]) ||
                !CheckDateValidation(attributes[Notes])) && AllOptionalFieldsNotSetRevised() && !string.IsNullOrWhiteSpace(NotesFallback2) &&
                attributes.ContainsKey(NotesFallback2) && !string.IsNullOrWhiteSpace(attributes[NotesFallback2]) && CheckDateValidation(attributes[NotesFallback2]))
            {
                mappedValue = attributes[NotesFallback2];
                result = true;
            }
            // value mapping
            else if (!string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes) &&
                FindValueMapping(attributes[Notes], out mappedValue))
            {
                result = true;
            }
            //// LNValueifNoMatch
            //else if (!string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes) &&
            //         UseLnValueIfNoMatch && OnlyValuesMappingSet()) 
            //{
            //    mappedValue = attributes[Notes];
            //    result = true;
            //}
            return result;
        }

        private bool CheckDateValidation(string input)
        {
            DateTime testDate;
            bool convertedToDate;
            if (!DateValidation)
            {
                return true;
            }
            convertedToDate = DateTime.TryParse(input.Trim(), out testDate) && testDate.Year > RulesConfiguration.Default.DATE_MIN_YEAR;
            return convertedToDate;
        }

        private bool OnlyValuesMappingSet()
        {
            return (ValuesMapping != null && ValuesMapping.Length > 0) &&
                   (CustomMapping == null || CustomMapping.Length == 0) &&
                   (RulesMapping == null || RulesMapping.Count == 0) &&
                   string.IsNullOrWhiteSpace(CustomMethod);
        }

        internal bool FindSharepointToSharepointMapping(Dictionary<string, string> spAttributes, out string mappedValue)
        {
            mappedValue = null;
            bool result = false;
            // value mapping
            if (!string.IsNullOrWhiteSpace(DependsOnSpField) && spAttributes.ContainsKey(DependsOnSpField) &&
                FindValueMapping(spAttributes[DependsOnSpField], out mappedValue, true))
            {
                result = true;
            }
            return result;
        }

        internal bool FindCustomMapping(NotesDocument document, out string mappedValue)
        {
            mappedValue = null;
            bool result = false;
            var attributes = document.Attributes;
            if (CustomMapping != null && CustomMapping.Length > 0 && !string.IsNullOrWhiteSpace(CustomMappingMode) &&
                !string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes))
            {
                string notesValue = attributes[Notes];
                ApplyCustomMapping(ref mappedValue, ref result, notesValue);
            }
            return result;
        }

        private void ApplyCustomMapping(ref string mappedValue, ref bool result, string notesValue)
        {
            if (CustomMappingMode.Trim().Equals(DataLoader.Default.CustomMappingMode_AssignValueIfContains, StringComparison.OrdinalIgnoreCase))
            {
                foreach (var mapping in CustomMapping)
                {
                    string match = mapping[0];
                    string value = mapping[1];
                    if (notesValue.Trim().ToUpper().Contains(match.Trim().ToUpper()))
                    {
                        mappedValue = value.Trim();
                        result = true;
                        TraceFile.WriteLine("AssignValueIfContains - converted '{0}' to '{1}' for attribute '{2}'", notesValue, mappedValue, Sharepoint);
                        break;
                    }
                }
            }
            else if (CustomMappingMode.Trim().Equals(DataLoader.Default.CustomMappingMode_RegExFullMatchValueBeginsWith, StringComparison.OrdinalIgnoreCase) ||
                     CustomMappingMode.Trim().Equals(DataLoader.Default.CustomMappingMode_RegExFullMatch, StringComparison.OrdinalIgnoreCase))
            {
                foreach (var mapping in CustomMapping)
                {
                    string regExPattern = mapping[0];
                    string replacePattern = mapping[1];

                    Regex regex = new Regex(regExPattern);

                    if (regex.IsMatch(notesValue.Trim()))
                    {
                        mappedValue = regex.Replace(notesValue.Trim(), replacePattern);
                        result = true;
                        TraceFile.WriteLine("{0} - converted '{1}' to '{2}' for attribute '{3}'", CustomMappingMode.Trim(), notesValue, mappedValue, Sharepoint);
                        break;
                    }
                }

            }
            else if (CustomMappingMode.Trim().Equals(DataLoader.Default.CustomMappingMode_FindAndReplace, StringComparison.OrdinalIgnoreCase))
            {
                mappedValue = notesValue.Trim();
                foreach (var mapping in CustomMapping)
                {
                    string match = mapping[0];
                    string replace = mapping[1];
                    mappedValue = mappedValue.ReplaceIgnoreCase(match, replace);
                }
                mappedValue = mappedValue.Trim();
                result = true;
                TraceFile.WriteLine("FindAndReplace - converted '{0}' to '{1}' for attribute '{2}'", notesValue, mappedValue, Sharepoint);
            }
            else if (CustomMappingMode.Trim().Equals(DataLoader.Default.CustomMappingMode_StartsWithReplaceOnce, StringComparison.OrdinalIgnoreCase))
            {
                result = true;
                string tempValue = notesValue.Trim();
                foreach (var mapping in CustomMapping)
                {
                    string match = mapping[0];
                    string replace = mapping[1];
                    if (tempValue.StartsWith(match, StringComparison.OrdinalIgnoreCase))
                    {
                        if (tempValue.Length > match.Length)
                        {
                            mappedValue = replace + tempValue.Substring(match.Length).Trim();
                        }
                        else
                        {
                            mappedValue = replace;
                        }
                        TraceFile.WriteLine("StartsWithReplaceOnce - converted '{0}' to '{1}' for attribute '{2}'", notesValue, mappedValue, Sharepoint);
                        break;
                    }
                }
                //mappedValue = mappedValue.Trim();
                //result = true;
                //TraceFile.WriteLine("FindAndReplace - converted '{0}' to '{1}' for attribute '{2}'", notesValue, mappedValue, Sharepoint);
            }
        }

        internal void NormalizeSharepointAttributesNames()
        {
            if (!string.IsNullOrWhiteSpace(Sharepoint))
            {
                Sharepoint = HelperClass.GetNormalizedSharePointAttributeName(Sharepoint);
            }
            if (!string.IsNullOrWhiteSpace(DependsOnSpField))
            {
                DependsOnSpField = HelperClass.GetNormalizedSharePointAttributeName(DependsOnSpField);
            }
        }

        private bool FindCustomMapping(string notesValue, out string mappedValue)
        {
            mappedValue = null;
            bool result = false;
            if (CustomMapping != null && CustomMapping.Length > 0 && !string.IsNullOrWhiteSpace(CustomMappingMode))
            {
                ApplyCustomMapping(ref mappedValue, ref result, notesValue);
            }
            return result;
        }
        internal bool ApplyCustomMethod(NotesDocument document, Dictionary<string, string> spAttributes, out string mappedValue)
        {
            mappedValue = null;
            bool result = false;
            var attributes = document.Attributes;

            if (!string.IsNullOrWhiteSpace(CustomMethod) && !string.IsNullOrWhiteSpace(Notes) && attributes.ContainsKey(Notes))
            {
                if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_ConvertToEffectivity, StringComparison.OrdinalIgnoreCase))
                {
                    ConvertToEffectivity(attributes, out mappedValue, out result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_ConvertToEffectivity_THD_TORONTO_LIBRARY, StringComparison.OrdinalIgnoreCase))
                {
                    ConvertToEffectivity_THD_TORONTO_LIBRARY(attributes, out mappedValue, out result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_ConvertToEffectivity_SERVICE_BULLETIN, StringComparison.OrdinalIgnoreCase))
                {
                    ConvertToEffectivity_SERVICE_BULLETIN(attributes, out mappedValue, out result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_ConvertToEffectivity_COVER_LETTER, StringComparison.OrdinalIgnoreCase))
                {
                    ConvertToEffectivity_COVER_LETTER(attributes, spAttributes, out mappedValue, out result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_ConvertToEffectivity_SB_DASH, StringComparison.OrdinalIgnoreCase))
                {
                    ConvertToEffectivity_SB_DASH(attributes, out mappedValue, out result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_ConvertToEffectivity_THD__LIBRARY, StringComparison.OrdinalIgnoreCase))
                {
                    ConvertToEffectivity_THD_LIBRARY(attributes, out mappedValue, out result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_SplitATA, StringComparison.OrdinalIgnoreCase))
                {
                    SplitATA(attributes, ref mappedValue, ref result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_SplitATA_THD, StringComparison.OrdinalIgnoreCase))
                {
                    SplitATA_THD(attributes, ref mappedValue, ref result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_SplitATA_ACR, StringComparison.OrdinalIgnoreCase))
                {
                    SplitATA_ACR(attributes, ref mappedValue, ref result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_Revision_THD, StringComparison.OrdinalIgnoreCase))
                {
                    Revision_THD(attributes, ref mappedValue, ref result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_SplitModels, StringComparison.OrdinalIgnoreCase))
                {
                    SplitModels(attributes, ref mappedValue, ref result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_ServiceBulletinNumber, StringComparison.OrdinalIgnoreCase))
                {
                    CoverLetterNumber(attributes, ref mappedValue, ref result, true);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_TransmittalLetterNumber, StringComparison.OrdinalIgnoreCase))
                {
                    CoverLetterNumber(attributes, ref mappedValue, ref result, false);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_TRNumber, StringComparison.OrdinalIgnoreCase))
                {
                    TRNumber(attributes, spAttributes, ref mappedValue, ref result);
                }
                else if (CustomMethod.Trim().Equals(DataLoader.Default.CustomMethod_Incorporated, StringComparison.OrdinalIgnoreCase))
                {
                    Incorporated(attributes, spAttributes, ref mappedValue, ref result);
                }
            }
            return result;
        }

        private void Revision_THD(Dictionary<string, string> attributes, ref string mappedValue, ref bool result)
        {
            mappedValue = null;
            bool valueSet = false;
            //string Uid = attributes["UNID"].Trim();
            //if (attributes[Notes] == null)
            //{
            //    return;
            //}

            string testString = attributes[Notes].Trim();


            if (attributes.ContainsKey(DataLoader.Default.Categories) &&
                Constants.THDRevisionCategoriesCheck.Contains(attributes[DataLoader.Default.Categories].Trim(), StringComparer.OrdinalIgnoreCase))
            {
                if (Regex.IsMatch(testString, "^-[ ]*-$|^-$|^~[ ]*-$|^~-[ ]*-$|^~-[ ]*-$|^~---$|^~----$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled) ||
                    Regex.IsMatch(testString, "^N/C$|^NC-$|^NCC$", RegexOptions.IgnoreCase | RegexOptions.Compiled) ||
                    Regex.IsMatch(testString.ReplaceIgnoreCase("NC", "").Trim(), "^-[ ]*-$|^-$|^~[ ]*-$|^~-[ ]*-$|^~-[ ]*-$|^~-[ ]*--$|^~----$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    mappedValue = "--";
                    result = true;
                    TraceFile.WriteLine("Revision_THD Success, before / after: {0} / {1}", attributes[Notes], mappedValue);
                    return;
                }
            }
            else if (attributes.ContainsKey(DataLoader.Default.Categories) &&
                !Constants.THDRevisionCategoriesCheck.Contains(attributes[DataLoader.Default.Categories].Trim(), StringComparer.OrdinalIgnoreCase))
            {
                if (Regex.IsMatch(testString, "^-[ ]*-$|^-$|^~[ ]*-$|^~-[ ]*-$|^~-[ ]*-$|^~---$|^~----$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled) ||
                    Regex.IsMatch(testString, "^N/C$|^NC-$|^NCC$", RegexOptions.IgnoreCase | RegexOptions.Compiled) ||
                    Regex.IsMatch(testString.ReplaceIgnoreCase("NC", "").Trim(), "^-[ ]*-$|^-$|^~[ ]*-$|^~-[ ]*-$|^~-[ ]*-$|^~---$|^~----$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    mappedValue = "NC";
                    result = true;
                    TraceFile.WriteLine("Revision_THD Success, before / after: {0} / {1}", attributes[Notes], mappedValue);
                    return;
                }
            }

            if (Regex.IsMatch(testString, @"^\s*$|^1\.8$|^AA \+ Am. 4$|^DRAFT$|^N/A$|^NC-1$|^N/A$|^~--#$|^\d{1,4}\s*[-/]\s*\d{1,4}\s*[-/]\s*\d{1,4}$|^$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled))
            {
                mappedValue = "--";
                result = true;
                TraceFile.WriteLine("Revision_THD Success, before / after: {0} / {1}", attributes[Notes], mappedValue);
                return;
            }
            //["^(?<first>\\d{2})$", "${first}"]
            Regex regex;

            regex = new Regex(@"^([A-Za-z]+)[ ]*-+[ ]*(\d+|Cancelled)$",
                RegexOptions.IgnoreCase | RegexOptions.Compiled);
            if (regex.IsMatch(testString))
            {
                mappedValue = regex.Replace(testString, "$1");
                result = true;
                TraceFile.WriteLine("Revision_THD Success, before / after: {0} / {1}", attributes[Notes], mappedValue);
                return;
            }
            regex = new Regex(@"^.*?(P\d+)[^\d]*$",
                RegexOptions.IgnoreCase | RegexOptions.Compiled);
            if (regex.IsMatch(testString))
            {
                mappedValue = regex.Replace(testString, "$1");
                result = true;
                TraceFile.WriteLine("Revision_THD Success, before / after: {0} / {1}", attributes[Notes], mappedValue);
                return;
            }
            if (!testString.Trim().Equals("R", StringComparison.OrdinalIgnoreCase))
            {
                string[] replaceChars = { "-can", "Rev.", "Rev", "R", "-Addendum ", "-Addendum" };
                foreach (var replaceChar in replaceChars)
                {
                    if (testString.Contains(replaceChar, StringComparison.OrdinalIgnoreCase))
                    {
                        mappedValue = testString.ReplaceIgnoreCase(replaceChar, "").Trim();
                        valueSet = true;
                        break;
                    }
                }
            }

            if (!valueSet)
            {
                mappedValue = String.Concat(testString.Where(ch => Char.IsLetterOrDigit(ch)));
            }

            //if (Regex.IsMatch(mappedValue, @"^\d+$|^[a-zA-Z]+$|^[a-rt-zA-RT-Z][a-zA-Z]*\d+$|^S\d{1,4}$|^NC$|^03A$|^$",
            if (Regex.IsMatch(mappedValue, @"^\d+$|^[a-zA-Z]+$|^[a-rt-zA-RT-Z][a-zA-Z]*\d+$|^S\d{1,4}$|^NC$|^03A$",
                               RegexOptions.IgnoreCase | RegexOptions.Compiled))
            {
                result = true;
                TraceFile.WriteLine("Revision_THD Success, before / after: {0} / {1}", attributes[Notes], mappedValue);
            }
            else
            {
                result = false;
                TraceFile.WriteLine("Revision_THD Failure, before / after: {0} / {1}", attributes[Notes], mappedValue);
            }
        }

        private void SplitATA_THD(Dictionary<string, string> attributes, ref string mappedValue, ref bool result)
        {
            StringBuilder atas = new StringBuilder();
            bool errorFound = false;
            //if (attributes[Notes].Contains("&") && !attributes[Notes].Contains("/"))
            //{
            //    result = false;
            //    return;
            //}
            string[] separators = attributes[Notes].Trim().TrimStart(',').TrimEnd(',').Split(DataLoader.Default.AtaSeparators_THD.Cast<string>().ToArray<string>(),
                StringSplitOptions.None);
            foreach (var ata in separators)
            {
                string match;
                if (FindValueMapping(ata.Trim(), out match) || FindCustomMapping(ata.Trim(), out match))
                {
                    if (atas.Length > 0)
                    {
                        atas.Append(DataLoader.Default.MultiLookupSeparator);
                    }
                    atas.Append(match);
                }
                else
                {
                    if (!errorFound)
                    {
                        errorFound = true;
                    }
                    TraceFile.WriteLine("SplitATA_THD, unable to match value {0} for SP Attribute {1}", ata, Sharepoint);
                }
            }
            if (atas.Length > 0 && !errorFound)
            {
                mappedValue = atas.ToString();
                result = true;
                TraceFile.WriteLine("SplitATA_THD, before / after: {0} / {1}", attributes[Notes], mappedValue);
            }
        }
        private void CoverLetterNumber(Dictionary<string, string> attributes, ref string mappedValue, ref bool result, bool serviceBulletinNumber)
        {
            mappedValue = null;

            if (attributes.ContainsKey(RulesConfiguration.Default.SB_CRJ_COVER_LETTER_VENDOR_NAME) &&
                !attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_VENDOR_NAME].StartsWith(
                    RulesConfiguration.Default.SB_CRJ_COVER_LETTER_TRANSMITTAL_LETTERS, StringComparison.OrdinalIgnoreCase))
            {
                string label = serviceBulletinNumber ? DataLoader.Default.CustomMethod_ServiceBulletinNumber : DataLoader.Default.CustomMethod_TransmittalLetterNumber;
                if (attributes.ContainsKey(RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER) &&
                    !string.IsNullOrWhiteSpace(attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER]) &&
                    attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER].Contains(Constants.CoverLetterFormat1, StringComparison.OrdinalIgnoreCase) ||
                    attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER].Contains(Constants.CoverLetterFormat2, StringComparison.OrdinalIgnoreCase))
                {
                    Regex regex = new Regex(serviceBulletinNumber ? Constants.ServiceBulletinNumberRegEx : Constants.TransmittalLetterNumberRegEx);
                    if (regex.IsMatch(attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER]))
                    {
                        StringBuilder sb = new StringBuilder();
                        foreach (Match match in regex.Matches(attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER]))
                        {
                            if (sb.Length > 0)
                            {
                                sb.Append(", ");
                            }
                            sb.Append(match.Value);
                        }
                        mappedValue = sb.ToString();
                        result = true;
                        TraceFile.WriteLine("{0}, before / after: {1} / {2}", label, attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER], mappedValue);
                    }
                    else
                    {
                        mappedValue = string.Empty;
                        result = true;
                    }
                }
                else
                {
                    if (attributes.ContainsKey(RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER) &&
                        string.IsNullOrWhiteSpace(attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER]))
                    {
                        mappedValue = string.Empty;
                        result = true;
                    }
                    else
                    {
                        result = false;
                        TraceFile.WriteLine("{0}, failure with CL NUMBER: '{1}'", label, attributes[RulesConfiguration.Default.SB_CRJ_COVER_LETTER_CL_NUMBER]);
                    }
                }
            }
            else
            {
                //optional
                mappedValue = string.Empty;
                result = true;
            }
        }
        private void TRNumber(Dictionary<string, string> attributes, Dictionary<string, string> spAttributes, ref string mappedValue, ref bool result)
        {
            mappedValue = null;

            if (spAttributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField) && spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Publication or Manual",
                            StringComparison.OrdinalIgnoreCase))
            {
                mappedValue = string.Empty;
                result = true;
                return;
            }
            else if (spAttributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField) && (spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Temporary Amendment",
                StringComparison.OrdinalIgnoreCase) || spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Temporary Revision", StringComparison.OrdinalIgnoreCase) ||
                spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Amendment", StringComparison.OrdinalIgnoreCase)) && !Regex.IsMatch(attributes[Notes].Trim(),
                Constants.numericDateRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled))
            {
                mappedValue = attributes[Notes];
                result = true;
            }
            else if (spAttributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField) && (spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Temporary Amendment",
                StringComparison.OrdinalIgnoreCase) || spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Temporary Revision", StringComparison.OrdinalIgnoreCase) ||
                spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Amendment", StringComparison.OrdinalIgnoreCase)) && Regex.IsMatch(attributes[Notes].Trim(),
                Constants.numericDateRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled))
            {
                Match m = Regex.Match(attributes[Notes].Trim(), Constants.numericDateRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled);
                if (m.Success)
                {
                    if (m.Groups[2].ToString().TrimStart('0').Equals("1"))
                    {
                        mappedValue = string.Format("{0}-{1}", m.Groups[2].ToString().TrimStart('0'), m.Groups[1].ToString().TrimStart('0'));
                    }
                    else if (m.Groups[2].ToString().TrimStart('0').Equals("9"))
                    {
                        mappedValue = string.Format("{0}-{1}", m.Groups[2].ToString().TrimStart('0'), m.Groups[3].ToString().TrimStart('0'));
                    }
                    else
                    {
                        mappedValue = string.Format("{0}-{1}-{2}", m.Groups[2].ToString().TrimStart('0'), m.Groups[3].ToString().TrimStart('0'),
                            m.Groups[1].ToString().TrimStart('0'));

                    }

                    result = true;
                    TraceFile.WriteLine("TRNumber, converted date '{0}' to '{1}'", attributes[Notes], mappedValue);
                }
            }
        }
        private void Incorporated(Dictionary<string, string> attributes, Dictionary<string, string> spAttributes, ref string mappedValue, ref bool result)
        {
            mappedValue = null;

            if (spAttributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField) && (spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Temporary Amendment",
             StringComparison.OrdinalIgnoreCase) || spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Temporary Revision", StringComparison.OrdinalIgnoreCase) ||
              spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Amendment", StringComparison.OrdinalIgnoreCase)))
            {
                if (!string.IsNullOrWhiteSpace(attributes[Notes]))
                {
                    mappedValue = attributes[Notes];
                    result = true;
                }
                else
                {
                    if (attributes.ContainsKey(DataLoader.Default.TRNumber) && attributes[DataLoader.Default.TRNumber].Contains(DataLoader.Default.Incorporated,
                        StringComparison.OrdinalIgnoreCase) && spAttributes.ContainsKey(DataLoader.Default.SharepointRevisionField) &&
                        !string.IsNullOrWhiteSpace(spAttributes[DataLoader.Default.SharepointRevisionField]))
                    {
                        int revision;
                        if (int.TryParse(spAttributes[DataLoader.Default.SharepointRevisionField].Trim(), out revision))
                        {
                            mappedValue = revision + 1 + string.Empty;
                            result = true;
                        }
                        else
                        {
                            TraceFile.WriteLine("Incorporated, failed to parse Revision '{0}' to Int", spAttributes[DataLoader.Default.SharepointRevisionField].Trim());
                            if (spAttributes[DataLoader.Default.SharepointRevisionField].Trim().Equals("NC", StringComparison.OrdinalIgnoreCase))
                            {
                                mappedValue = "1";
                                result = true;
                            }
                        }
                    }
                    else if (attributes.ContainsKey(DataLoader.Default.TRNumber) && !attributes[DataLoader.Default.TRNumber].Contains(DataLoader.Default.Incorporated,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        mappedValue = "NA";
                        //mappedValue = "-1";
                        result = true;
                    }
                }
            }
            else if (spAttributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField) && spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Publication or Manual",
                StringComparison.OrdinalIgnoreCase))
            {
                mappedValue = string.Empty;
                result = true;
            }

            if (!result)
            {
                TraceFile.WriteLine("Strange");
            }
        }
        private void ConvertToEffectivity(Dictionary<string, string> attributes, out string mappedValue, out bool result)
        {
            mappedValue = null;

            if (!string.IsNullOrWhiteSpace(attributes[Notes]))
            {
                //string Uid = attributes["UNID"];
                if (Regex.IsMatch(attributes[Notes].Trim(), Constants.whiteSpaceRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    TraceFile.WriteLine("linebreak, tab or _x000D_ found!");
                }
                mappedValue = Regex.Replace(attributes[Notes].Trim(), Constants.whiteSpaceRegex, " ", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivitySubsIndicators,
                    Constants.effectivitySubsIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityValuesSeparators,
                         Constants.effectivityValuesSeparatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityRangesIndicators,
                         Constants.effectivityRangesIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                TraceFile.WriteLine("ConvertToEffectivity, before / after: {0} / {1}", attributes[Notes], mappedValue);
                mappedValue = mappedValue.TrimEnd(',', '.', 'O', 'o');
                if (Regex.IsMatch(mappedValue, @"^\d+( - \d+)?(,\d+( - \d+)?)*( - ral)?$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            else
            {
                result = false;
            }
        }
        private void ConvertToEffectivity_THD_LIBRARY(Dictionary<string, string> attributes, out string mappedValue, out bool result)
        {
            mappedValue = null;

            if (!string.IsNullOrWhiteSpace(attributes[Notes]))
            {
                if (Regex.IsMatch(attributes[Notes].Trim(), @"^(([78]\d{3})|(1\d{4})){2,}",
                        RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    Regex regex = new Regex(@"^(([78]\d{3})|(1\d{4})){2,}", RegexOptions.IgnoreCase | RegexOptions.Compiled);

                    Match match = regex.Match(attributes[Notes].Trim());
                    List<string> numbers = new List<string>();
                    foreach (Capture capture in match.Groups[1].Captures)
                    {
                        numbers.Add(capture.Value);
                    }

                    mappedValue = string.Join(",", numbers);
                    result = true;
                    TraceFile.WriteLine("ConvertToEffectivity_THD_LIBRARY - Numbers glued together, converted '{0}' to '{1}'", attributes[Notes].Trim(), mappedValue);
                }
                else
                {
                    //string Uid = attributes["UNID"];
                    if (Regex.IsMatch(attributes[Notes].Trim(), Constants.whiteSpaceRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled))
                    {
                        TraceFile.WriteLine("linebreak, tab or _x000D_ found!");
                    }
                    mappedValue = Regex.Replace(attributes[Notes].Trim(), Constants.whiteSpaceRegex, " ", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    mappedValue = Regex.Replace(mappedValue, Constants.effectivitySubsIndicators,
                        Constants.effectivitySubsIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    mappedValue = Regex.Replace(mappedValue, Constants.effectivityValuesSeparators,
                             Constants.effectivityValuesSeparatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    mappedValue = Regex.Replace(mappedValue, Constants.effectivityRangesIndicators,
                             Constants.effectivityRangesIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    TraceFile.WriteLine("ConvertToEffectivity, before / after: {0} / {1}", attributes[Notes], mappedValue);
                    mappedValue = mappedValue.TrimEnd(',', '.', 'O', 'o');
                    if (Regex.IsMatch(mappedValue, @"^\d+( - \d+)?(,\d+( - \d+)?)*( - ral)?$",
                        RegexOptions.IgnoreCase | RegexOptions.Compiled))
                    {
                        result = true;
                    }
                    else
                    {
                        result = false;
                    }
                }
            }
            else
            {
                result = false;
            }
        }
        private void ConvertToEffectivity_THD_TORONTO_LIBRARY(Dictionary<string, string> attributes, out string mappedValue, out bool result)
        {
            mappedValue = null;

            if (!string.IsNullOrWhiteSpace(attributes[Notes]))
            {
                //string Uid = attributes["UNID"];
                if (Regex.IsMatch(attributes[Notes].Trim(), Constants.whiteSpaceRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    TraceFile.WriteLine("linebreak, tab or _x000D_ found!");
                }
                mappedValue = Regex.Replace(attributes[Notes].Trim(), Constants.whiteSpaceRegex, " ", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivitySubsIndicators,
                    Constants.effectivitySubsIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityValuesSeparators,
                         Constants.effectivityValuesSeparatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityRangesIndicators,
                         Constants.effectivityRangesIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = mappedValue.TrimEnd(',', '.', 'O', 'o');
                mappedValue = Regex.Replace(mappedValue, @"(?<= |,|^)(?<main>\d{1,2})(?= |,|$)", new MatchEvaluator(PadMatch),
                    RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, @"(?<=\D+|^)999(?=\D+|$)", "672",
                                        RegexOptions.Compiled | RegexOptions.IgnoreCase);
                //mappedValue = mappedValue.Replace("999", "672");
                mappedValue = mappedValue.Replace("000,", "");
                mappedValue = mappedValue.Replace(",000", "");
                mappedValue = mappedValue.Replace("000", "");
                TraceFile.WriteLine("ConvertToEffectivity_THD_TORONTO_LIBRARY, before / after: {0} / {1}", attributes[Notes], mappedValue);
                if (Regex.IsMatch(mappedValue, @"^\d+( - \d+)?(,\d+( - \d+)?)*( - ral)?$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {

                    string mappedvalueCopy = mappedValue;
                    if (Constants.ThdTorontoLibraryFullEffectivityRanges.Contains(mappedValue.Trim()))
                    {
                        TraceFile.WriteLine("ConvertToEffectivity_THD_TORONTO_LIBRARY, full Effectivity found: '{0}' / {1}", attributes[Notes], mappedValue);
                        mappedValue = "All";
                    }
                    else if (Constants.ThdTorontoLibraryFullEffectivityRanges.Any(r => mappedvalueCopy.IndexOf(r, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        TraceFile.WriteLine("ConvertToEffectivity_THD_TORONTO_LIBRARY, Mixed full Effectivity found: '{0}'", attributes[Notes]);
                    }
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            else
            {
                result = false;
            }
        }
        private void ConvertToEffectivity_SB_DASH(Dictionary<string, string> attributes, out string mappedValue, out bool result)
        {
            mappedValue = null;

            if (!string.IsNullOrWhiteSpace(attributes[Notes]))
            {
                string Uid = attributes["UNID"];
                if (Regex.IsMatch(attributes[Notes].Trim(), Constants.whiteSpaceRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    TraceFile.WriteLine("linebreak, tab or _x000D_ found!");
                }
                mappedValue = Regex.Replace(attributes[Notes].Trim(), Constants.whiteSpaceRegex, " ", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = mappedValue.Replace("2017-01-29", "1-29");
                mappedValue = mappedValue.Replace("1979-01-01", "1-79");
                mappedValue = mappedValue.Replace("1969-01-01", "1-69");
                mappedValue = Regex.Replace(mappedValue, Constants.effectivitySubsIndicators,
                    Constants.effectivitySubsIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityValuesSeparators,
                         Constants.effectivityValuesSeparatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityRangesIndicators,
                         Constants.effectivityRangesIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = mappedValue.TrimEnd(',', '.', 'O', 'o');
                mappedValue = Regex.Replace(mappedValue, @"(?<= |,|^)(?<main>\d{1,2})(?= |,|$)", new MatchEvaluator(PadMatch),
                    RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, @"(?<=\D+|^)9999(?=\D+|$)", "4999",
                        RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, @"(?<=\D+|^)999(?=\D+|$)", "672",
                        RegexOptions.Compiled | RegexOptions.IgnoreCase);
                //mappedValue = mappedValue.Replace("999", "672");
                //mappedValue = mappedValue.Replace("9999", "4999");
                mappedValue = Regex.Replace(mappedValue, @"(?<= |,|^)(001|002)(?= |,|$)", "003",
                    RegexOptions.Compiled | RegexOptions.IgnoreCase);

                TraceFile.WriteLine("ConvertToEffectivity_SB_DASH, before / after: {0} / {1}", attributes[Notes], mappedValue);
                if (Regex.IsMatch(mappedValue, @"^\d+( - \d+)?(,\d+( - \d+)?)*( - ral)?$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    string mappedvalueCopy = mappedValue;
                    if (Constants.SbDashFullEffectivityRanges.Contains(mappedValue.Trim()))
                    {
                        TraceFile.WriteLine("ConvertToEffectivity_SB_DASH, full Effectivity found: '{0}' / {1}", attributes[Notes], mappedValue);
                        mappedValue = "All";
                    }
                    else if (Constants.SbDashFullEffectivityRanges.Any(r => mappedvalueCopy.IndexOf(r, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        TraceFile.WriteLine("ConvertToEffectivity_SB_DASH, Mixed full Effectivity found: '{0}'", attributes[Notes]);
                    }
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            else
            {
                result = false;
            }
        }

        private void ConvertToEffectivity_COVER_LETTER(Dictionary<string, string> attributes, Dictionary<string, string> spAttributes, out string mappedValue, out bool result)
        {
            mappedValue = null;
            string Uid = attributes["UNID"];
            if (spAttributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField) && spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Vendor Service Bulletin", StringComparison.OrdinalIgnoreCase) &&
                ((attributes.ContainsKey("CLACEffectivity") && !string.IsNullOrWhiteSpace(attributes["CLACEffectivity"])) ||
                (attributes.ContainsKey("CLNumber") && (string.IsNullOrWhiteSpace(attributes["CLNumber"]) ||
                attributes["CLNumber"] == "`" ||
                attributes["CLNumber"].Contains(Constants.CoverLetterFormat1, StringComparison.OrdinalIgnoreCase) ||
                attributes["CLNumber"].Contains(Constants.CoverLetterFormat2, StringComparison.OrdinalIgnoreCase) ||
                attributes["CLNumber"].Contains(Constants.CoverLetterFormat1v2, StringComparison.OrdinalIgnoreCase) ||
                attributes["CLNumber"].Contains(Constants.CoverLetterFormat2v2, StringComparison.OrdinalIgnoreCase)))))
            {
                mappedValue = "All";
                result = true;
            }
            else if (spAttributes.ContainsKey(DataLoader.Default.SharePointDocumentTypeField) && spAttributes[DataLoader.Default.SharePointDocumentTypeField].Equals("Vendor Transmittal Letter",
                StringComparison.OrdinalIgnoreCase))
            {
                mappedValue = "All";
                result = true;
            }

            else
            {
                result = false;
            }

        }

        private void ConvertToEffectivity_SERVICE_BULLETIN(Dictionary<string, string> attributes, out string mappedValue, out bool result)
        {
            mappedValue = null;

            if (!string.IsNullOrWhiteSpace(attributes[Notes]))
            {
                //string Uid = attributes["UNID"];
                if (Regex.IsMatch(attributes[Notes].Trim(), Constants.whiteSpaceRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    TraceFile.WriteLine("linebreak, tab or _x000D_ found!");
                }
                mappedValue = Regex.Replace(attributes[Notes].Trim(), Constants.whiteSpaceRegex, " ", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivitySubsIndicators,
                    Constants.effectivitySubsIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityValuesSeparators,
                         Constants.effectivityValuesSeparatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                mappedValue = Regex.Replace(mappedValue, Constants.effectivityRangesIndicators,
                         Constants.effectivityRangesIndicatorsReplacement, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                TraceFile.WriteLine("ConvertToEffectivity, before / after: {0} / {1}", attributes[Notes], mappedValue);
                mappedValue = mappedValue.TrimEnd(',', '.', 'O', 'o');
                if (Regex.IsMatch(mappedValue, @"^\d+( - \d+)?(,\d+( - \d+)?)*( - ral)?$",
                    RegexOptions.IgnoreCase | RegexOptions.Compiled))
                {
                    string mappedvalueCopy = mappedValue;
                    if (Constants.ServiceBulletinFullEffectivityRanges.Contains(mappedValue.Trim()))
                    {
                        TraceFile.WriteLine("ConvertToEffectivity_SERVICE_BULLETIN, full Effectivity found: '{0}' / {1}", attributes[Notes], mappedValue);
                        mappedValue = "All";
                    }
                    else if (Constants.ServiceBulletinFullEffectivityRanges.Any(r => mappedvalueCopy.IndexOf(r, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        TraceFile.WriteLine("ConvertToEffectivity_SERVICE_BULLETIN, Mixed full Effectivity found: '{0}'", attributes[Notes]);
                    }

                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            else
            {
                result = false;
            }
        }
        private static string PadMatch(Match m)
        {
            string result = m.Groups["main"].ToString().PadLeft(3, '0');

            TraceFile.WriteLine("PadMatch - replaced match '{0}' with '{1}'", m.ToString(), result);

            return result;
        }

        private void SplitATA(Dictionary<string, string> attributes, ref string mappedValue, ref bool result)
        {
            string Uid = attributes["UNID"];
            StringBuilder atas = new StringBuilder();
            bool errorFound = false;
            foreach (var ata in attributes[Notes].Trim().Split(DataLoader.Default.AtaSeparators.Cast<string>().ToArray<string>(),
                StringSplitOptions.None))
            {
                string match;
                if (FindValueMapping(ata.Trim(), out match) || FindCustomMapping(ata.Trim(), out match))
                {
                    if (atas.Length > 0)
                    {
                        atas.Append(DataLoader.Default.MultiLookupSeparator);
                    }
                    atas.Append(match);
                }
                else
                {
                    if (!errorFound)
                    {
                        errorFound = true;
                    }
                    TraceFile.WriteLine("SplitATA, unable to match value {0} for SP Attribute {1}", ata, Sharepoint);
                }
            }
            if (atas.Length > 0 && !errorFound)
            {
                mappedValue = atas.ToString();
                result = true;
                TraceFile.WriteLine("SplitATA, before / after: {0} / {1}", attributes[Notes], mappedValue);
            }
        }
        private void SplitATA_ACR(Dictionary<string, string> attributes, ref string mappedValue, ref bool result)
        {
            string Uid = attributes["UNID"];
            StringBuilder atas = new StringBuilder();
            bool errorFound = false;
            foreach (var ata_tmp in attributes[Notes].Trim().Split(DataLoader.Default.AtaSeparators.Cast<string>().ToArray<string>(),
                StringSplitOptions.None))
            {
                // internal loop to bypass issue with splitting " " separated item with normal way
                foreach (var ata in ata_tmp.Trim().Split(' '))
                {
                    string match;
                    if (FindValueMapping(ata.Trim(), out match) || FindCustomMapping(ata.Trim(), out match))
                    {
                        if (atas.Length > 0)
                        {
                            atas.Append(DataLoader.Default.MultiLookupSeparator);
                        }
                        atas.Append(match);
                    }
                    else
                    {
                        if (!errorFound)
                        {
                            errorFound = true;
                        }
                        TraceFile.WriteLine("SplitATA_ACR, unable to match value {0} for SP Attribute {1}", ata, Sharepoint);
                    }
                }

            }
            if (atas.Length > 0 && !errorFound)
            {
                mappedValue = atas.ToString();
                result = true;
                TraceFile.WriteLine("SplitATA_ACR, before / after: {0} / {1}", attributes[Notes], mappedValue);
            }
        }

        private void SplitModels(Dictionary<string, string> attributes, ref string mappedValue, ref bool result)
        {
            StringBuilder models = new StringBuilder();
            var mappedModels = new HashSet<string>();
            bool errorFound = false;
            foreach (var model in (attributes[Notes].Trim().Split(new string[] { DataLoader.Default.ModelsSeparator }, StringSplitOptions.RemoveEmptyEntries)))
            {
                string match;
                if (FindValueMapping(model.Trim(), out match))
                {
                    if (mappedModels.Contains(match))
                    {
                        continue;
                    }
                    if (models.Length > 0)
                    {
                        models.Append(DataLoader.Default.MultiLookupSeparator);
                    }
                    models.Append(match);
                    mappedModels.Add(match);
                }
                else
                {
                    if (!errorFound)
                    {
                        errorFound = true;
                    }
                    TraceFile.WriteLine("SplitModels, unable to match value {0} for SP Attribute {1}", model, Sharepoint);
                }
            }
            if (models.Length > 0 && !errorFound)
            {
                mappedValue = models.ToString();
                result = true;
                TraceFile.WriteLine("SplitModels, before / after: {0} / {1}", attributes[Notes], mappedValue);
            }
            else
            {
                result = false;
            }
        }

        internal bool FindRuleMapping(NotesDocument document, out string mappedValue)
        {
            mappedValue = null;
            bool result = false;

            if (RulesMapping != null && RulesMapping.Count > 0)
            {
                foreach (var ruleMapping in RulesMapping)
                {
                    if (RulesEngine.MatchSingleRuleNotesDocument(document, ruleMapping.Value))
                    {
                        if (UseNotesIfRuleMappingTrue || (UseNotesIfRuleMappingTrueAndRuleValueEmpty && string.IsNullOrWhiteSpace(ruleMapping.Key)))
                        {
                            if (string.IsNullOrWhiteSpace(Notes) || !document.Attributes.ContainsKey(Notes))
                            {
                                throw new Exception("Mapping Error - UseNotesIfRuleMappingTrue but no valid Notes field provided.");
                            }
                            mappedValue = document.Attributes[Notes];
                        }
                        else if (!string.IsNullOrWhiteSpace(FieldIfRuleMappingTrue))
                        {
                            if (!document.Attributes.ContainsKey(FieldIfRuleMappingTrue))
                            {
                                throw new Exception("Mapping Error - FieldIfRuleMappingTrue contains an invalid Notes field.");
                            }
                            mappedValue = document.Attributes[FieldIfRuleMappingTrue];
                        }
                        else
                        {
                            mappedValue = ruleMapping.Key.Substring(DataLoader.Default.RuleMappingNumberOfAddedCharacters);
                        }
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }

        //public string GetRulesResult(NotesDocument document)
        //{
        //    if (RulesMapping != null && RulesMapping.Count > 0)
        //    {
        //        foreach (var ruleMapping in RulesMapping)
        //        {
        //            if (RulesEngine.MatchSingleRuleNotesDocument(document, ruleMapping.Value))
        //            {
        //                return ruleMapping.Key;
        //            }
        //        }
        //    }
        //    return null;
        //}
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(Notes))
            {
                sb.AppendFormat("[ Notes: {0} ]", Notes);
            }
            if (!string.IsNullOrWhiteSpace(Sharepoint))
            {
                if (sb.Length > 0)
                {
                    sb.AppendFormat("\n[ Sharepoint: {0} ]", Sharepoint);
                }
                else
                {
                    sb.AppendFormat("[ Sharepoint: {0} ]", Sharepoint);
                }
            }
            if (!string.IsNullOrWhiteSpace(Default))
            {
                if (sb.Length > 0)
                {
                    sb.AppendFormat("\n[ Default: {0} ]", Default);
                }
                else
                {
                    sb.AppendFormat("[ Default: {0} ]", Default);
                }
            }
            if (!string.IsNullOrWhiteSpace(DependsOnLnField))
            {
                if (sb.Length > 0)
                {
                    sb.AppendFormat("\n[ DependsOnLnField: {0} ]", DependsOnLnField);
                }
                else
                {
                    sb.AppendFormat("[ DependsOnLnField: {0} ]", DependsOnLnField);
                }
            }
            if (!string.IsNullOrWhiteSpace(DependsOnSpField))
            {
                if (sb.Length > 0)
                {
                    sb.AppendFormat("\n[ DependsOnSpField: {0} ]", DependsOnSpField);
                }
                else
                {
                    sb.AppendFormat("[ DependsOnSpField: {0} ]", DependsOnSpField);
                }
            }
            if (UseLnValueIfNoMatch)
            {
                if (sb.Length > 0)
                {
                    sb.AppendFormat("\n[ UseLnValueIfNoMatch: {0} ]", UseLnValueIfNoMatch);
                }
                else
                {
                    sb.AppendFormat("[ UseLnValueIfNoMatch: {0} ]", UseLnValueIfNoMatch);
                }
            }
            if (ValuesMapping != null && ValuesMapping.Length > 0)
            {
                if (sb.Length > 0)
                {
                    sb.AppendFormat("\n[ ValuesMapping: {0} ]", ValuesMapping.Print());
                }
                else
                {
                    sb.AppendFormat("[ ValuesMapping: {0} ]", ValuesMapping.Print());
                }
            }

            return sb.ToString();
        }
        public string[] GetNotesFields()
        {
            List<string> notesFields = new List<string>();
            if (!string.IsNullOrWhiteSpace(Notes))
            {
                notesFields.Add(Notes);
            }
            if (!string.IsNullOrWhiteSpace(NotesFallback))
            {
                notesFields.Add(NotesFallback);
            }
            if (!string.IsNullOrWhiteSpace(NotesFallback2))
            {
                notesFields.Add(NotesFallback2);
            }
            if (!string.IsNullOrWhiteSpace(FieldIfRuleMappingTrue))
            {
                notesFields.Add(FieldIfRuleMappingTrue);
            }
            if (!string.IsNullOrWhiteSpace(NotesFieldToAppend))
            {
                notesFields.Add(NotesFieldToAppend);
            }
            if (RulesMapping != null)
            {
                foreach (var ruleMapping in RulesMapping)
                {
                    notesFields.AddRange(ruleMapping.Value.GetFields());
                }
            }
            return notesFields.Distinct().ToArray();
        }
    }
}
