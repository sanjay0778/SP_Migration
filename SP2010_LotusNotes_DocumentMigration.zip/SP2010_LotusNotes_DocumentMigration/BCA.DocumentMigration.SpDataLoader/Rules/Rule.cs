﻿using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Rules
{
    public class Rule
    {
        public string Field { get; set; }
        public string Operator { get; set; }
        public string Value { get; set; }
        public bool Enabled { get; set; }
        public string LinkedOperator { get; set; }
        public Rule LinkedRule { get; set; }
        public string[] Values { get; set; }
        public string ValuesOperator { get; set; }

        /// <summary>
        /// Constructor to set field operator and value
        /// </summary>
        /// <param name="MemberName">Field</param>
        /// <param name="Operator">operator</param>
        /// <param name="TargetValue">field value</param>
        public Rule(string MemberName, string Operator, string TargetValue)
        {
            this.Field = MemberName;
            this.Operator = Operator;
            this.Value = TargetValue;
        }

        public override string ToString() 
        {
            if (LinkedRule != null && LinkedOperator != null)
            {
                return String.Format("({0} {1} \"{2}{3}\") {4} ({5})", this.Field, HelperClass.FilteringRulesReverseMapping[this.Operator],
                    (this.Value != null && !string.IsNullOrWhiteSpace(this.Value)) ? this.Value : string.Empty, (this.Values != null && this.Values.Length > 0) ?
                    string.Format("Values[{0}]", string.Join(", ", this.Values)) : string.Empty, HelperClass.FilteringRulesReverseMapping[this.LinkedOperator], this.LinkedRule.ToString());
            }
            else
            {
                return String.Format("{0} {1} \"{2}{3}\"", this.Field, HelperClass.FilteringRulesReverseMapping[this.Operator], (this.Value != null && !string.IsNullOrWhiteSpace(this.Value)) ?
                    this.Value : string.Empty, (this.Values != null && this.Values.Length > 0) ? string.Format("Values[{0}]", string.Join(", ", this.Values)) : string.Empty);
            }            
        }
        public string ToString(bool reverseLogic = true)
        {
            if (LinkedRule != null && LinkedOperator != null)
            {
                return String.Format("({0} {1} \"{2}{3}\") {4} ({5})", this.Field, reverseLogic ? HelperClass.FilteringRulesReverseMapping[this.Operator] : this.Operator,
                    (this.Value != null && !string.IsNullOrWhiteSpace(this.Value)) ? this.Value : string.Empty, (this.Values != null && this.Values.Length > 0) ?
                    string.Format("Values[{0}]", string.Join(", ", this.Values)) : string.Empty, reverseLogic ? HelperClass.FilteringRulesReverseMapping[this.LinkedOperator] : this.LinkedOperator,
                    this.LinkedRule.ToString());
            }
            else
            {
                return String.Format("{0} {1} \"{2}{3}\"", this.Field, reverseLogic ? HelperClass.FilteringRulesReverseMapping[this.Operator] : this.Operator,
                    (this.Value != null && !string.IsNullOrWhiteSpace(this.Value)) ? this.Value : string.Empty,
                    (this.Values != null && this.Values.Length > 0) ? string.Format("Values[{0}]", string.Join(", ", this.Values)) : string.Empty);
            }
        }

        internal List<string> GetFields()
        {
            List<string> fields = new List<string>();
            fields.Add(this.Field);
            if (LinkedRule != null && LinkedOperator != null)
            {
                fields.AddRange(this.LinkedRule.GetFields());
                return fields;
            }
            else
            {
                return fields;
            }
        }
    }
}
