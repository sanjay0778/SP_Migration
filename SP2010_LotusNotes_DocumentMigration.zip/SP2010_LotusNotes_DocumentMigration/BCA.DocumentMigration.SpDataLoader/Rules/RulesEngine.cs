﻿using BCA.DocumentMigration.SpDataLoader.NotesData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Rules
{
    public class RulesEngine
    {
        public List<Rule> Rules;
        //private List<Func<T, bool>> compiledRules = null;
        //private IEnumerable<Func<T, bool>> compiledRules = null;

        //public Expression BuildExpression<T>(Rule rule, ParameterExpression param)
        //{
        //    var left = MemberExpression.Property(param, rule.Field);
        //    var tProp = typeof(T).GetProperty(rule.Field).PropertyType;
        //    ExpressionType tBinary;
        //    // is the operator a known .NET operator?
        //    if (ExpressionType.TryParse(rule.Operator, out tBinary))
        //    {
        //        var right = Expression.Constant(Convert.ChangeType(rule.Value, tProp));
        //        // use a binary operation, e.g. 'Equal' -> 'u.Age == 15'
        //        return Expression.MakeBinary(tBinary, left, right);
        //    }
        //    else
        //    {
        //        var method = tProp.GetMethod(rule.Operator);
        //        var tParam = method.GetParameters()[0].ParameterType;
        //        var right = Expression.Constant(Convert.ChangeType(rule.Value, tParam));
        //        // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
        //        return Expression.Call(left, method, right);
        //    }
        //}

        public static Expression BuildExpression<T>(Rule rule, ParameterExpression param)
        {
            var left = MemberExpression.Property(param, rule.Field);
            var tProp = typeof(T).GetProperty(rule.Field).PropertyType;
            ExpressionType tBinary;
            // is the operator a known .NET operator?
            if (ExpressionType.TryParse(rule.Operator, out tBinary))
            {
                var right = Expression.Constant(Convert.ChangeType(rule.Value, tProp));
                // use a binary operation, e.g. 'Equal' -> 'u.Age == 15'
                return Expression.MakeBinary(tBinary, left, right);
            }
            else
            {
                var method = tProp.GetMethod(rule.Operator);
                var tParam = method.GetParameters()[0].ParameterType;
                var right = Expression.Constant(Convert.ChangeType(rule.Value, tParam));
                // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                return Expression.Call(left, method, right);
            }
        }

        public static Func<T, bool> CompileRule<T>(Rule rule)
        {
            var paramT = Expression.Parameter(typeof(T));
            Expression expression = BuildExpression<T>(rule, paramT);
            return Expression.Lambda<Func<T, bool>>(expression, paramT).Compile();
        }

        //public Expression BuildExpressionNotesDocument(Rule rule, ParameterExpression param)
        //{
        //    //var left    = MemberExpression.Property(param, rule.MemberName);
        //    var mExpr = MemberExpression.Property(param, "Attributes");

        //    Type dictionaryType = typeof(NotesDocument).GetProperty("Attributes").PropertyType;
        //    PropertyInfo indexerProp = dictionaryType.GetProperty("Item");
        //    var dictKeyConstant = Expression.Constant(rule.Field);
        //    //var dictAccess
        //    var left = Expression.MakeIndex(mExpr, indexerProp, new[] { dictKeyConstant });

        //    var tProp = indexerProp.PropertyType;
        //    ExpressionType tBinary;
        //    // is the operator a known .NET operator?
        //    if (ExpressionType.TryParse(rule.Operator, out tBinary))
        //    {
        //        var right = Expression.Constant(Convert.ChangeType(rule.Value, tProp));
        //        // use a binary operation, e.g. 'Equal' -> 'u.Age == 15'
        //        return Expression.MakeBinary(tBinary, left, right);
        //    }
        //    else
        //    {
        //        var method = tProp.GetMethod(rule.Operator);
        //        var tParam = method.GetParameters()[0].ParameterType;
        //        var right = Expression.Constant(Convert.ChangeType(rule.Value, tParam));
        //        // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
        //        return Expression.Call(left, method, right);
        //    }
        //}

        public static Expression BuildExpressionNotesDocument(Rule rule, ParameterExpression param)
        {
            //var left    = MemberExpression.Property(param, rule.MemberName);
            var mExpr = MemberExpression.Property(param, "Attributes");

            Type dictionaryType = typeof(NotesDocument).GetProperty("Attributes").PropertyType;
            PropertyInfo indexerProp = dictionaryType.GetProperty("Item");
            var dictKeyConstant = Expression.Constant(rule.Field);
            //var dictAccess
            var left = Expression.MakeIndex(mExpr, indexerProp, new[] { dictKeyConstant });

            var tProp = indexerProp.PropertyType;
            ExpressionType tBinary;
            ExpressionType tBinaryLinked;
            ExpressionType tBinaryValuesOperator;
            // is the operator a known .NET operator?
            if (rule.LinkedRule != null && rule.LinkedOperator != null && ExpressionType.TryParse(rule.LinkedOperator, out tBinaryLinked))
            {
                if (ExpressionType.TryParse(rule.Operator, out tBinary))
                {
                    if (rule.Values != null && rule.Values.Length > 0 && ExpressionType.TryParse(rule.ValuesOperator, out tBinaryValuesOperator))
                    {
                        Expression valuesExpression = null;
                        bool isFirst = true;
                        foreach (var value in rule.Values)
                        {
                            var right = Expression.Constant(Convert.ChangeType(value, tProp));
                            if (isFirst)
                            {
                                valuesExpression = Expression.MakeBinary(tBinary, left, right);
                                isFirst = false;
                            }
                            else
                            {
                                valuesExpression = Expression.MakeBinary(tBinaryValuesOperator, valuesExpression,
                                    Expression.MakeBinary(tBinary, left, right));
                            }
                        }
                        return Expression.MakeBinary(tBinaryLinked, valuesExpression, BuildExpressionNotesDocument(rule.LinkedRule, param));
                    }
                    else
                    {
                        var right = Expression.Constant(Convert.ChangeType(rule.Value, tProp));
                        // use a binary operation, e.g. 'Equal' -> 'u.Age == 15'
                        return Expression.MakeBinary(tBinaryLinked, Expression.MakeBinary(tBinary, left, right), BuildExpressionNotesDocument(rule.LinkedRule, param));
                    }
                }
                else
                {
                    var method = tProp.GetMethods().FirstOrDefault(m => m.Name == rule.Operator && m.GetParameters().Count() == 1);
                    if (method == null)
                    {
                        method = typeof(ExtensionMethods).GetMethod(rule.Operator, BindingFlags.Static | BindingFlags.Public);
                        var tParamEx = method.GetParameters()[0].ParameterType;
                        var rightEx = Expression.Constant(Convert.ChangeType(rule.Value, tParamEx));
                        // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                        //return Expression.Call(method, left, rightEx);
                        return Expression.MakeBinary(tBinaryLinked, Expression.Call(method, left, rightEx), BuildExpressionNotesDocument(rule.LinkedRule, param));

                    }
                    else
                    {
                        var tParam = method.GetParameters()[0].ParameterType;
                        var right = Expression.Constant(Convert.ChangeType(rule.Value, tParam));
                        // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                        //return Expression.Call(left, method, right);
                        return Expression.MakeBinary(tBinaryLinked, Expression.Call(left, method, right), BuildExpressionNotesDocument(rule.LinkedRule, param));
                    }
                    //var method = tProp.GetMethod(rule.Operator);
                    //var tParam = method.GetParameters()[0].ParameterType;
                    //var right = Expression.Constant(Convert.ChangeType(rule.Value, tParam));
                    //// use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                    //return Expression.MakeBinary(tBinaryLinked, Expression.Call(left, method, right), BuildExpressionNotesDocument(rule.LinkedRule, param));
                }
            }
            else
            {
                if (ExpressionType.TryParse(rule.Operator, out tBinary))
                {

                    if (rule.Values != null && rule.Values.Length > 0 &&
                        ExpressionType.TryParse(rule.ValuesOperator, out tBinaryValuesOperator))
                    {
                        Expression valuesExpression = null;
                        bool isFirst = true;
                        foreach (var value in rule.Values)
                        {
                            var right = Expression.Constant(Convert.ChangeType(value, tProp));
                            if (isFirst)
                            {
                                valuesExpression = Expression.MakeBinary(tBinary, left, right);
                                isFirst = false;
                            }
                            else
                            {
                                valuesExpression = Expression.MakeBinary(tBinaryValuesOperator, valuesExpression,
                                    Expression.MakeBinary(tBinary, left, right));
                            }
                        }
                        return valuesExpression;
                    }
                    else
                    {
                        var right = Expression.Constant(Convert.ChangeType(rule.Value, tProp));
                        // use a binary operation, e.g. 'Equal' -> 'u.Age == 15'
                        return Expression.MakeBinary(tBinary, left, right);
                    }          

                }
                else
                {
                    //var method = tProp.GetMethod(rule.Operator);
                    //var methods = tProp.GetMethods();
                    var method = tProp.GetMethods().FirstOrDefault(m => m.Name == rule.Operator && m.GetParameters().Count() == 1);
                    if (method == null)
                    {
                        method = typeof(ExtensionMethods).GetMethod(rule.Operator, BindingFlags.Static | BindingFlags.Public);
                        var tParamEx = method.GetParameters()[0].ParameterType;
                        var rightEx = Expression.Constant(Convert.ChangeType(rule.Value, tParamEx));
                        // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                        return Expression.Call(method, left, rightEx);
                    }
                    else
                    {
                        var tParam = method.GetParameters()[0].ParameterType;
                        var right = Expression.Constant(Convert.ChangeType(rule.Value, tParam));
                        // use a method call, e.g. 'Contains' -> 'u.Tags.Contains(some_tag)'
                        return Expression.Call(left, method, right);
                    }                

                }
            }
        }

        public static Func<NotesDocument, bool> CompileRuleNotesDocument(Rule rule)
        {
            var paramT = Expression.Parameter(typeof(NotesDocument));
            Expression expression = BuildExpressionNotesDocument(rule, paramT);
            return Expression.Lambda<Func<NotesDocument, bool>>(expression, paramT).Compile();
        }

        public bool MatchesAllRulesNotesDocument(NotesDocument document, Logs logs, Log log = null)
        {
            bool perfectMatch = true;
            var compiledRules = Rules.Select(r => CompileRuleNotesDocument(r)).ToList();
            int i = 0;
            foreach (var rule in compiledRules)
            {
                if (Rules[i].Enabled)
                {
                    if (rule(document))
                    {
                        TraceFile.WriteLine("Rule [{0}] was successfully applied", Rules[i].ToString());
                        if (log != null)
                        {
                            //logs.AddFilteringRule(log, true, Rules[i].ToString(), Rules[i].GetFields());
                        }
                        else
                        {
                            //logs.AddFilteringRule(document.Uid, true, Rules[i].ToString(), Rules[i].GetFields());
                        }
                        
                    }
                    else
                    {
                        perfectMatch = false;
                        TraceFile.WriteLine("Rule [{0}] has failed", Rules[i].ToString());
                        if (log != null)
                        {
                            logs.AddFilteringRule(log, false, Rules[i].ToString(), Rules[i].GetFields());
                        }
                        else
                        {
                            //logs.AddFilteringRule(document.Uid, false, Rules[i].ToString(), Rules[i].GetFields());
                        }
                    }
                }  
                i++;
            }
            return perfectMatch;
            //return compiledRules.All(rule => rule(thisObj));
        }
        public static bool MatchSingleRuleNotesDocument(NotesDocument document, Rule rule)
        {
            bool isMatch = false;
            var compiledRule = CompileRuleNotesDocument(rule);

            if (rule.Enabled)
            {
                if (compiledRule(document))
                {
                    isMatch = true;
                    TraceFile.WriteLine("Single Rule [{0}] was successfully applied", rule.ToString(false));
                    //Logs.Instance.AddFilteringRule(document.Uid, true, rule.ToString(), rule.GetFields());
                }
                else
                {
                    isMatch = false;
                    TraceFile.WriteLine("Single Rule [{0}] has failed", rule.ToString(false));
                    //Logs.Instance.AddFilteringRule(document.Uid, false, rule.ToString(), rule.GetFields());
                }
            }
            return isMatch;
        }

        public bool MatchesAllRules<T>(T thisObj)
        {
           bool perfectMatch = true; 
           var compiledRules = Rules.Select(r => CompileRule<T>(r)).ToList();

           foreach (var rule in compiledRules)
           {
               if (rule(thisObj))
               {
                   TraceFile.WriteLine("Rule {0} was successfully applied", rule.ToString());
               }
               else
               {
                   perfectMatch = false;
                   TraceFile.WriteLine("Rule {0} has failed", rule.ToString());
               }
           }
           return perfectMatch;            
            //return compiledRules.All(rule => rule(thisObj));
        }
    }
}
