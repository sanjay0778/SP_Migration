﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Rules
{
    public class ColorsArray1
    {
        public string colorName { get; set; }
        public string hexValue { get; set; }
    }

    public class Color
    {
        public IList<ColorsArray1> colorsArray1 { get; set; }
    }
}
