﻿using BCA.DocumentMigration.SpDataLoader.Utils;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.SharepointData
{
    public class DocSet
    {
        private string _documentGroup;
        //private string _name;
        //private string _duplicateName;
        public NotesDatabases DbType;

        public Dictionary<string, string> Attributes { get; set; }
        public Dictionary<string, string> Attachments { get; set; }
        public string Uid { get; set; }
        public string SubFolder { get; set; }
        public string Name { get; set; }
        public DocumentGroups DocumentGroupType { get; set; }
        public string DocumentType { get; set; }
        public bool AllMandatorySet { get; set; }
        public bool AllValidLengths { get; set; }
        public bool ReadyForSharePoint { get; set; }
        public Dictionary<string, int> LookupFields { get; set; }
        public Dictionary<string, int[]> MultiLookupFields { get; set; }
        public Dictionary<string, string> TextFields { get; set; }
        public Dictionary<string, double> NumberFields { get; set; }
        public Dictionary<string, string> ChoiceFields { get; set; }
        public Dictionary<string, DateTime> DateTimeFields { get; set; }
        public Dictionary<string, bool> BooleanFields { get; set; }
        

        //public string Name
        //{
        //    get
        //    {
        //        return string.IsNullOrWhiteSpace(this._duplicateName) ? this._name : this._duplicateName;
        //    }
        //    set
        //    {
        //        this._name = value.GetValidSharePointFolderName().Trim();
        //        this.Attributes[DataLoader.Default.SharePointNameField] = this._name;
        //        // maybe use ReaderWriterLockSlim  later?
        //        if (string.IsNullOrWhiteSpace(this._name))
        //        {
        //            return;
        //        }
        //        lock (HelperClass.thisLock)
        //        {
        //            if (HelperClass.CurrentLibraryDuplicateNames.ContainsKey(this._name))
        //            {
        //                int duplicateCount = HelperClass.CurrentLibraryDuplicateNames[this._name] + 1;
        //                HelperClass.CurrentLibraryDuplicateNames[this._name] = duplicateCount;
        //                this._duplicateName = string.Format("{0} ({1})", this._name, HelperClass.GetAlphabetIncrement(duplicateCount));
        //                TraceFile.WriteLine("{0} - Duplicate Name found\n\tRenamed \n\t'{1}'\n\tTo\n\t'{2}'", this.Uid, this._name, this._duplicateName);
        //                this.Attributes[DataLoader.Default.SharePointNameField] = this._duplicateName;
        //            }
        //            else
        //            {
        //                this._duplicateName = null;
        //                HelperClass.CurrentLibraryDuplicateNames.GetOrAdd(this._name, 0);

        //            }
        //            // if duplicate, assign _duplicateName
        //        }
        //    }
        //}
        public string DocumentGroup
        {
            get
            {
                return this._documentGroup;
            }
            set
            {
                this._documentGroup = value;
                if (value.ToUpper().Contains("ENGINEERING"))
                {
                    this.DocumentGroupType = DocumentGroups.EngineeringDocument;
                }
                else if (value.ToUpper().Contains("GENERIC"))
                {
                    this.DocumentGroupType = DocumentGroups.GenericDocument;
                }
                else if (value.ToUpper().Contains("SERVICE"))
                {
                    this.DocumentGroupType = DocumentGroups.ServiceDocument;
                }
                else if (value.ToUpper().Contains("SUPPLIER"))
                {
                    this.DocumentGroupType = DocumentGroups.SuppliersDocuments;
                }
                else if (value.ToUpper().Contains("NEWSLETTER"))
                {
                    this.DocumentGroupType = DocumentGroups.TechnicalNewsletter;
                }
                else if (value.ToUpper().Contains("PUBLICATION"))
                {
                    this.DocumentGroupType = DocumentGroups.TechnicalPublications;
                }
            }
        }

        public DocSet() 
        {            
            Attributes        = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Attachments       = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            LookupFields      = new Dictionary<string, int>();
            MultiLookupFields = new Dictionary<string, int[]>();
            ChoiceFields = new Dictionary<string, string>();
            TextFields = new Dictionary<string, string>();
            NumberFields = new Dictionary<string, double>();
            DateTimeFields = new Dictionary<string, DateTime>();
            BooleanFields = new Dictionary<string, bool>();
            AllMandatorySet = true;
            AllValidLengths = true;
            ReadyForSharePoint = false;
        }

        public DocSet(NotesDatabases dbType)
        {
            this.DbType = dbType;
            Attributes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Attachments = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            LookupFields = new Dictionary<string, int>();
            MultiLookupFields = new Dictionary<string, int[]>();
            ChoiceFields = new Dictionary<string, string>();
            TextFields = new Dictionary<string, string>();
            NumberFields = new Dictionary<string, double>();
            DateTimeFields = new Dictionary<string, DateTime>();
            BooleanFields = new Dictionary<string, bool>();
            AllMandatorySet = true;
            AllValidLengths = true;
            ReadyForSharePoint = false;
        }

        //public void CheckMandatory()
        //{
        //    DocTypeAttribute dta = HelperClass.GetDocTypeAttribute(DocumentType);
        //    if (dta == null || dta.Mandatory == null || dta.Mandatory.Length <= 0)
        //    {
        //        TraceFile.WriteLine("No valid mandatory fields found for DocType \"{0}\"", DocumentType);
        //        return;
        //    }
        //    foreach (var mandatoryField in dta.Mandatory.Where(m=> !Constants.MandatoryFieldCheckExclusionList.Contains(m)))
        //    {
        //        if (Attributes.ContainsKey(mandatoryField) && !string.IsNullOrWhiteSpace(Attributes[mandatoryField]))
        //        {
        //            TraceFile.WriteLine("Mandatory field \"{0}\" is set", mandatoryField);
        //            Logs.Instance.AddMandatoryFieldsRule(this.Uid, true, mandatoryField, HelperClass.SharePointToNotesFieldMap.ContainsKey(mandatoryField) ?
        //                     HelperClass.SharePointToNotesFieldMap[mandatoryField] : mandatoryField + "(SP)");
        //        }
        //        else
        //        {
        //            TraceFile.WriteLine("Failure - Mandatory field \"{0}\" is not set", mandatoryField);                    
        //            AllMandatorySet = false;
        //            Logs.Instance.AddMandatoryFieldsRule(this.Uid, false, mandatoryField, HelperClass.SharePointToNotesFieldMap.ContainsKey(mandatoryField) ?
        //                     HelperClass.SharePointToNotesFieldMap[mandatoryField] : mandatoryField + "(SP)");
        //        }
        //    }
        //}

        //public void CheckSize()
        //{
        //    foreach (var attribute in Attributes)
        //    {
        //        SharePointAttribute spa = HelperClass.GetSharePointAttribute(attribute.Key);
        //        string attributeValue = (string.IsNullOrWhiteSpace(attribute.Value)) ? string.Empty : attribute.Value;
        //        int maxLength;
        //        if (int.TryParse(spa.MaxLength, out maxLength))
        //        {
        //            if (attributeValue.Length > maxLength)
        //            {
        //                TraceFile.WriteLine("Failure - FreeText field {0} exceeds the length limit", attribute.Key);
        //                AllValidLengths = false;
        //                Logs.Instance.AddFieldsLengthsRule(this.Uid, false, attribute.Key,
        //                    HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
        //                    HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
        //            }
        //        }
        //        else
        //        {
        //            //TraceFile.WriteLine("Field {0} is not Free Text", attribute.Key);
        //        }
        //    }            
        //}
        public void CheckMandatoryAndSize(Logs reportLogs, Log log = null)
        {
            DocTypeAttribute dta = HelperClass.GetDocTypeAttribute(DocumentType);       
            if (dta == null || dta.Mandatory == null || dta.Mandatory.Length <= 0)
            {
                TraceFile.WriteLine("No valid mandatory fields found for DocType \"{0}\"", DocumentType);
                return;
            }

            var mandatoryFields = dta.Mandatory.Where(m => !Constants.MandatoryFieldCheckExclusionList.Contains(m));

            CheckMandatoryFieldsMissingFromRules(reportLogs, log, mandatoryFields);

            foreach (var attribute in Attributes.ToDictionary(a => a.Key, a => a.Value))
            {
                checkAttributeLength(attribute, reportLogs, log);
                CheckAttributeMandatoryField(mandatoryFields, attribute, reportLogs, log);
            }

        }

        private void CheckMandatoryFieldsMissingFromRules(Logs reportLogs, Log log, IEnumerable<string> mandatoryFields)
        {
            if (!HelperClass.checkedMandatoryFieldForCurrentExtract)
            {
                TraceFile.WriteLine("CheckMandatoryFieldsMissingFromRules for {0}", this.DbType.ToString());
                HelperClass.checkedMandatoryFieldForCurrentExtract = true;

                if (mandatoryFields.Any(m => !Attributes.ContainsKey(m)))
                {
                    foreach (var mandatoryField in mandatoryFields.Where(m => !Attributes.ContainsKey(m)))
                    {
                        reportLogs.AddMandatoryFieldsRule(log, false, mandatoryField, mandatoryField + "(SP)");
                    }
                }
            }
        }

        private void CheckAttributeMandatoryField(IEnumerable<string> mandatoryFields, KeyValuePair<string, string> attribute, Logs reportLogs, Log log = null)
        {
            if (string.IsNullOrWhiteSpace(attribute.Value) &&
                mandatoryFields.Contains(attribute.Key, StringComparer.OrdinalIgnoreCase))
            {
                TraceFile.WriteLine("Failure - Mandatory field \"{0}\" is not set - Content Type '{1}'", attribute.Key, this.DocumentType);
                AllMandatorySet = false;
                reportLogs.AddMandatoryFieldsRule(log, false, attribute.Key, HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
                    HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
                //if (log != null)
                //{
                //    reportLogs.AddMandatoryFieldsRule(log, false, attribute.Key, HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
                //    HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
                //}
                //else
                //{
                //    reportLogs.AddMandatoryFieldsRule(this.Uid, false, attribute.Key, HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
                //    HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
            //}
            }
        }

        private void checkAttributeLength(KeyValuePair<string, string> attribute, Logs reportLogs, Log log)
        {
            SharePointAttribute spa = HelperClass.GetSharePointAttribute(attribute.Key);
            string attributeValue = (string.IsNullOrWhiteSpace(attribute.Value)) ? string.Empty : attribute.Value;
            int maxLength;
            if (spa == null)
            {
                TraceFile.WriteLine("checkAttributeLength - attribute '{0}' not found", attribute.Key);
            }
            else
            {
                if (int.TryParse(spa.MaxLength, out maxLength) && attributeValue.Length > maxLength)
                {
                    TraceFile.WriteLine("Failure - FreeText field {0} exceeds the length limit", attribute.Key);
                    AllValidLengths = false;
                    reportLogs.AddFieldsLengthsRule(log, false, attribute.Key,
                        HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
                        HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
                }
                if (spa.DataType.Contains(DataLoader.Default.SingleLineOfText, StringComparison.OrdinalIgnoreCase) &&
                    !string.IsNullOrEmpty(this.Attributes[attribute.Key]))
                {
                    this.Attributes[attribute.Key] = attribute.Value.AllWhiteSpacesToSpaces();
                }
            }
        }
        //private void checkAttributeLength(KeyValuePair<string, string> attribute, Logs reportLogs, Log log)
        //{
        //    if (attribute.Key.Equals(DataLoader.Default.SharePointNameField, StringComparison.OrdinalIgnoreCase))
        //    {
        //        string fullUrlPath = string.Format("{0}{1}/{2}/{3}", DataLoader.Default.SharepointUrl, this.SubFolder, this.DocumentType, attribute.Value);
        //        TraceFile.WriteLine("checkAttributeLength - Validating full path for Document Set: '{0}'", fullUrlPath);
        //        if (fullUrlPath.Length > DataLoader.Default.SharePointUrlLenghtLimit)
        //        {
        //            TraceFile.WriteLine("Invalid document set name Length '{0}' for {1}", attribute.Value, this.Uid);
        //            reportLogs.AddFieldsLengthsRule(log, false, attribute.Key,
        //              HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
        //              HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
        //        }
        //    }
        //    else
        //    {
        //        SharePointAttribute spa = HelperClass.GetSharePointAttribute(attribute.Key);
        //        string attributeValue = (string.IsNullOrWhiteSpace(attribute.Value)) ? string.Empty : attribute.Value;
        //        int maxLength;
        //        if (spa == null)
        //        {
        //            TraceFile.WriteLine("checkAttributeLength - attribute '{0}' not found", attribute.Key);
        //        }
        //        else if (int.TryParse(spa.MaxLength, out maxLength))
        //        {
        //            if (attributeValue.Length > maxLength)
        //            {
        //                TraceFile.WriteLine("Failure - FreeText field {0} exceeds the length limit", attribute.Key);
        //                AllValidLengths = false;
        //                reportLogs.AddFieldsLengthsRule(log, false, attribute.Key,
        //                    HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
        //                    HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
        //                //if (log != null)
        //                //{
        //                //    reportLogs.AddFieldsLengthsRule(log, false, attribute.Key,
        //                //    HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
        //                //    HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
        //                //}
        //                //else
        //                //{
        //                //    reportLogs.AddFieldsLengthsRule(this.Uid, false, attribute.Key,
        //                //    HelperClass.SharePointToNotesFieldMap.ContainsKey(attribute.Key) ?
        //                //    HelperClass.SharePointToNotesFieldMap[attribute.Key] : attribute.Key + "(SP)");
        //                //}
        //            }
        //        }
        //        else
        //        {
        //            //TraceFile.WriteLine("Field {0} is not Free Text", attribute.Key);
        //        }
        //    }
        //}
        public bool PrepareAttributesForSharepoint(Log log)
        {
            bool result = true;
            bool isBeginsWithField = false;
            StringBuilder sharepointValidation = null;

            SharePointContentType spCt = HelperClass.ContentTypes.SingleOrDefault(ct => ct.Name.Equals(
                HelperClass.GetDocumentSetContentType(this.DocumentType), StringComparison.OrdinalIgnoreCase));
            if (spCt == null)
            {
                TraceFile.WriteLine("Could not load content type \"{0}\"", this.DocumentType);
                ReadyForSharePoint = false;

                AddSharepointValidation(ref sharepointValidation, string.Format("Could not load content type \"{0}\"", this.DocumentType));

                log.Success = false;
                log.SharepointValidation = sharepointValidation;

                return false;
            }
            else
            {
                TraceFile.WriteLine("Successfully loaded content type \"{0}\"", this.DocumentType);
            }
            SharePointField spField;
            foreach (var attribute in Attributes.Where(a => !string.IsNullOrWhiteSpace(a.Value) &&
            !Constants.SharePointExclusionList.Contains(a.Key)).ToDictionary(a => a.Key, a => a.Value))
            {
                string[] models = null;
                spField = spCt.GetField(attribute.Key);
                string faultyAtas;
                if (spField == null)
                {
                    TraceFile.WriteLine("No match found for attribute \"{0}\"", attribute.Key);
                    //return false;
                    AddSharepointValidation(ref sharepointValidation, string.Format("No match found for attribute \"{0}\"", attribute.Key));
                    if (result)
                    {
                        result = false;
                    }
                }

                isBeginsWithField = HelperClass.BeginsWithSharePointFields.Contains(attribute.Key.Trim()) || 
                    (this.Attributes[DataLoader.Default.SharePointAircrafFamilyField].Equals(DataLoader.Default.CSeriesFolder.Replace(" ", ""),
                    StringComparison.OrdinalIgnoreCase) && (attribute.Key.Trim() == DataLoader.Default.SharepointMainAtaField
                    || attribute.Key.Trim() == DataLoader.Default.SharepointSubAtaField));
                if (isBeginsWithField)
                {
                    models = this.Attributes[DataLoader.Default.SharepointModelNumberField].Split(new string[] { DataLoader.Default.MultiLookupSeparator },
                        StringSplitOptions.None).Select(a => a.Trim()).ToArray();

                }
                switch (spField.SharePointDataType)
                {
                    case SharePointDataTypes.Other:
                        TraceFile.WriteLine("\"{0}\" did not match any currently supported Type", spField.InternalName);
                        AddSharepointValidation(ref sharepointValidation, string.Format("\"{0}\" did not match any currently supported Type", spField.InternalName));

                        if (result)
                        {
                            result = false;
                        }
                        break;
                    case SharePointDataTypes.Text:
                        TextFields.Add(spField.InternalName, attribute.Value);
                        break;
                    case SharePointDataTypes.Number:
                        double numValue;
                        if (double.TryParse(attribute.Value.Trim(), out numValue))
                        {
                            NumberFields.Add(spField.InternalName, numValue);
                        }
                        else
                        {
                            TraceFile.WriteLine("Field '{0}' - unable to convert '{1}' to a number", attribute.Key, attribute.Value);
                            AddSharepointValidation(ref sharepointValidation, string.Format("Field '{0}' - unable to convert '{1}' to a number",
                                attribute.Key, attribute.Value));
                            if (result)
                            {
                                result = false;
                            }
                        }
                        break;
                    case SharePointDataTypes.Lookup:
                        string lookupString;
                        int lookupMatch = spField.GetLookupValue(attribute.Value, this.GetAtaSubFolder(), out lookupString, models, out faultyAtas, isBeginsWithField);
                        if (!string.IsNullOrWhiteSpace(faultyAtas))
                        {
                            if (string.IsNullOrWhiteSpace(log.FaultyAtas))
                            {
                                log.FaultyAtas = faultyAtas;
                            }
                            else
                            {
                                log.FaultyAtas = string.Format("{0}\n{1}", log.FaultyAtas, faultyAtas);
                            }
                        }
                        if (lookupMatch == -1)
                        {
                            TraceFile.WriteLine("No lookup match found for lookup field '{0}', value '{1}'", spField.InternalName, attribute.Value);
                            AddSharepointValidation(ref sharepointValidation, string.Format("No lookup match found for lookup field '{0}', value '{1}'",
                                spField.InternalName, attribute.Value));
                            //return false;
                            if (result)
                            {
                                result = false;
                            }
                        }
                        else
                        {
                            LookupFields.Add(spField.InternalName, lookupMatch);
                            if (lookupString != null)
                            {
                                log.SharePointAttributes[attribute.Key] = lookupString;
                            }
                        }
                        break;
                    case SharePointDataTypes.MultiLookup:
                        List<int> lookupMatches = new List<int>();
                        StringBuilder sbMulti = new StringBuilder();
                        foreach (var attributeValue in attribute.Value.Trim().Split(new string[] { DataLoader.Default.MultiLookupSeparator }, StringSplitOptions.None))
                        {
                            string lookupStringMulti;
                            int multiLookupMatch = spField.GetLookupValue(attributeValue.Trim(), this.GetAtaSubFolder(), out lookupStringMulti, models, out faultyAtas, isBeginsWithField);
                            if (!string.IsNullOrWhiteSpace(faultyAtas))
                            {
                                if (string.IsNullOrWhiteSpace(log.FaultyAtas))
                                {
                                    log.FaultyAtas = faultyAtas;
                                }
                                else
                                {
                                    log.FaultyAtas = string.Format("{0}\n{1}", log.FaultyAtas, faultyAtas);
                                }
                            }
                            if (multiLookupMatch == -1 && attribute.Key.Equals(DataLoader.Default.SharepointSubAtaField) &&
                                DbType == NotesDatabases.THDTorontoLibrary)
                            {
                                string newAttributeValue = string.Format("{0}-00", attributeValue.Trim().Substring(0, 2));
                                TraceFile.WriteLine("THD Library Sub Ata - No lookup match found for multi-lookup field '{0}', value '{1}'. Will retry with '{2}'",
                                    spField.InternalName, attributeValue.Trim(), newAttributeValue);

                                multiLookupMatch = spField.GetLookupValue(newAttributeValue.Trim(), this.GetAtaSubFolder(), out lookupStringMulti, models, out faultyAtas, isBeginsWithField);

                                if (multiLookupMatch == -1)
                                {
                                    TraceFile.WriteLine("THD Library Sub Ata - Failed second attempt - No lookup match found for multi-lookup field '{0}', old value '{1}' new value '{2}'",
                                        spField.InternalName, attributeValue.Trim(), newAttributeValue.Trim());
                                    AddSharepointValidation(ref sharepointValidation, string.Format("No lookup match found for multi-lookup field '{0}', value '{1}'",
                                        spField.InternalName, attributeValue.Trim()));
                                    //return false;
                                    if (result)
                                    {
                                        result = false;
                                    }
                                }
                                else
                                {
                                    lookupMatches.Add(multiLookupMatch);
                                    if (lookupStringMulti != null)
                                    {
                                        if (sbMulti.Length > 0)
                                        {
                                            sbMulti.AppendFormat("{0}", DataLoader.Default.MultiLookupSeparator);
                                        }
                                        sbMulti.Append(lookupStringMulti);
                                        TraceFile.WriteLine("THD Library Sub Ata - Set new value '{0}'", lookupStringMulti);
                                    }
                                }


                            }
                            else if (multiLookupMatch == -1)
                            {
                                TraceFile.WriteLine("No lookup match found for multi-lookup field '{0}', value '{1}'", spField.InternalName, attributeValue.Trim());
                                AddSharepointValidation(ref sharepointValidation, string.Format("No lookup match found for multi-lookup field '{0}', value '{1}'",
                                    spField.InternalName, attributeValue.Trim()));
                                //return false;
                                if (result)
                                {
                                    result = false;
                                }
                            }
                            else
                            {
                                lookupMatches.Add(multiLookupMatch);
                                if (lookupStringMulti != null)
                                {
                                    if (sbMulti.Length > 0)
                                    {
                                        sbMulti.AppendFormat("{0}", DataLoader.Default.MultiLookupSeparator);
                                    }
                                    sbMulti.Append(lookupStringMulti);
                                }
                            }
                        }
                        MultiLookupFields.Add(spField.InternalName, lookupMatches.ToArray<int>());
                        if (sbMulti.Length > 0)
                        {
                            log.SharePointAttributes[attribute.Key] = sbMulti.ToString().Trim();
                        }
                        break;
                    case SharePointDataTypes.Choice:
                        //TextFields.Add(spField.InternalName, attribute.Value);
                        TraceFile.WriteLine("\"{0}\" is a Choice field", spField.InternalName);
                        string choiceMatch;
                        if (spField.GetChoiceValue(attribute.Value, out choiceMatch))
                        {
                            TraceFile.WriteLine("Adding choice value '{0}' for choice field '{1}'", choiceMatch, spField.InternalName);
                            ChoiceFields.Add(spField.InternalName, choiceMatch);
                        }
                        else
                        {
                            TraceFile.WriteLine("No lookup match found for choice field '{0}', value '{1}'", spField.InternalName, attribute.Value);
                            AddSharepointValidation(ref sharepointValidation, string.Format("No lookup match found for choice field '{0}', value '{1}'",
                                spField.InternalName, attribute.Value));
                            if (result)
                            {
                                result = false;
                            }
                        }
                        break;
                    case SharePointDataTypes.DateTime:
                        DateTime dt;
                        if (DateTime.TryParse(attribute.Value, out dt) && dt.Year > RulesConfiguration.Default.DATE_MIN_YEAR)
                        {
                            DateTimeFields.Add(spField.InternalName, dt);
                            TraceFile.WriteLine("Parsed '{0}' to '{1}'", attribute.Value, dt.ToShortDateString());
                        }
                        else
                        {
                            TraceFile.WriteLine("Unable to extract valid date from '{0}' value '{1}'", attribute.Key, attribute.Value);
                            AddSharepointValidation(ref sharepointValidation, string.Format("Unable to extract date from '{0}', value '{1}'",
                                attribute.Key, attribute.Value));
                            if (result)
                            {
                                result = false;
                            }
                        }
                        break;
                    case SharePointDataTypes.Computed:
                        TraceFile.WriteLine("\"{0}\" is a Computed field", spField.InternalName);
                        break;
                    case SharePointDataTypes.Boolean:
                        TraceFile.WriteLine("\"{0}\" is a Boolean field", spField.InternalName);
                        bool yesOrNo;
                        if (attribute.Value.Trim().Equals("yes", StringComparison.OrdinalIgnoreCase))
                        {
                            yesOrNo = true;
                        }
                        else
                        {
                            yesOrNo = false;
                        }
                        BooleanFields.Add(spField.InternalName, yesOrNo);

                        break;
                    default:
                        TraceFile.WriteLine("Attribute \"{0}\" has unsupported SharePoint DataType \"{1}\"", spField.InternalName,
                            spField.SharePointDataType.ToString());
                        AddSharepointValidation(ref sharepointValidation, string.Format("Attribute \"{0}\" has unsupported SharePoint DataType \"{1}\"",
                            spField.InternalName, spField.SharePointDataType.ToString()));
                        if (result)
                        {
                            result = false;
                        }
                        break;
                }
            }
            ReadyForSharePoint = result;
            if (!result)
            {
                log.Success = false;
                log.SharepointValidation = sharepointValidation;

            }
            return result;
        }

        private string GetAtaSubFolder()
        {
            if (this.SubFolder == DataLoader.Default.CSeriesFolder)
            {
                return this.SubFolder.Replace(" ", "");
            }
            else
            {
                return this.SubFolder;
            }
        }

        private static void AddSharepointValidation(ref StringBuilder sharepointValidation, string validationText)
        {
            if (sharepointValidation == null || sharepointValidation.Length == 0)
            {
                if (sharepointValidation == null)
                {
                    sharepointValidation = new StringBuilder();
                }
                sharepointValidation.Append(DataLoader.Default.ReportError_Sharepoint_Validation_Title);
            }
            sharepointValidation.AppendLine();
            sharepointValidation.AppendFormat(validationText);
        }

        internal void ValidateAttachments(Logs reportLogs, Log log)
        {
            var attachmentKeys = new List<string>(Attachments.Keys);
            foreach (var attachment in attachmentKeys)
            {
                string fullUrlPath = string.Format("{0}{1}/{2}/{3}/{4}", DataLoader.Default.SharepointUrl, this.SubFolder, this.DocumentType, this.Name, attachment);
                TraceFile.WriteLine("ValidateAttachments - Validating full path '{0}'", fullUrlPath);
                if (fullUrlPath.Length > DataLoader.Default.SharePointUrlLenghtLimit)
                {
                    TraceFile.WriteLine("Invalid filename Length '{0}' for {1}", attachment, this.Uid);
                    reportLogs.AddInvalidFileName(log, attachment);
                }
                else if (!attachment.IsValidSharePointFileName())
                {
                    Attachments[attachment] = attachment.GetValidSharePointFileName();
                }
            }
        }

        //internal void ValidateAttachments(Logs reportLogs, Log log)
        //{
        //    var attachmentKeys = new List<string>(Attachments.Keys);
        //    foreach (var attachment in attachmentKeys)
        //    {
        //        if (attachment.Length > DataLoader.Default.SharePointFileNameLenghtLimit)
        //        {
        //            TraceFile.WriteLine("Invalid filename Length '{0}' for {1}", attachment, this.Uid);
        //            reportLogs.AddInvalidFileName(log, attachment);
        //        }
        //        else if (!attachment.IsValidSharePointFileName())
        //        {
        //            Attachments[attachment] = attachment.GetValidSharePointFileName();
        //        }
        //    }
        //}
        public string GetDocumentGroupTitle()
        {
            string documentSetTitle = null;
            switch (DocumentGroupType)
            {
                case DocumentGroups.EngineeringDocument:
                    documentSetTitle = DataLoader.Default.EngineeringDocuments;
                    break;
                case DocumentGroups.GenericDocument:
                    documentSetTitle = DataLoader.Default.GenericDocuments;
                    break;
                case DocumentGroups.ServiceDocument:
                    documentSetTitle = DataLoader.Default.ServiceDocuments;
                    break;
                case DocumentGroups.SuppliersDocuments:
                    documentSetTitle = DataLoader.Default.SuppliersDocuments;
                    break;
                case DocumentGroups.TechnicalNewsletter:
                    documentSetTitle = DataLoader.Default.TechnicalNewsletters;
                    break;
                case DocumentGroups.TechnicalPublications:
                    documentSetTitle = DataLoader.Default.TechnicalPublications;
                    break;
                default:
                    break;
            }
            return documentSetTitle;
        }
        public string GetDocumentLibrary()
        {
            string documentLibrary = null;
            switch (DbType)
            {
                case NotesDatabases.THDTorontoLibrary:
                    documentLibrary = DataLoader.Default.QSeriesFolder;
                    //documentLibrary = DataLoader.Default.CRJSeriesFolder;
                    break;
                case NotesDatabases.THDLibrary:
                    documentLibrary = DataLoader.Default.CRJSeriesFolder;
                    break;
                case NotesDatabases.WorkingGroups:
                    documentLibrary = SubFolder;
                    break;
                case NotesDatabases.SBCRJCoverLetter:
                    documentLibrary = DataLoader.Default.CRJSeriesFolder;
                    break;
                case NotesDatabases.SBCRJPDFDocument:
                    documentLibrary = DataLoader.Default.CRJSeriesFolder;
                    break;
                case NotesDatabases.SBCRJServiceBulletin:
                    documentLibrary = DataLoader.Default.CRJSeriesFolder;
                    break;
                case NotesDatabases.TISBDASH:
                    documentLibrary = DataLoader.Default.QSeriesFolder;
                    break;
                case NotesDatabases.TITechManualStatus:
                    documentLibrary = SubFolder;
                    break;
                case NotesDatabases.CSeriesSharePoint2010:
                    documentLibrary = DataLoader.Default.CSeriesFolder;
                    break;
                case NotesDatabases.WorkingGroupsPresentationsMeetingMinutes:
                    documentLibrary = SubFolder;
                    break;
                default:
                    break;
            }
            return documentLibrary;
        }
        public string GetRelativeParentFolderUrl()
        {
            string relativeUrl = null;
            string iflyFolder = null;
            switch (DbType)
            {
                case NotesDatabases.THDTorontoLibrary:
                    relativeUrl = string.Format("{0}{1}", DataLoader.Default.SharepointQSeriesRelativeUrl, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.THDLibrary:
                    relativeUrl = string.Format("{0}{1}", DataLoader.Default.SharepointCRJSeriesRelativeUrl, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.WorkingGroups:
                    if (SubFolder.Equals(DataLoader.Default.CRJSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointCRJSeriesRelativeUrl;
                    }
                    else if (SubFolder.Equals(DataLoader.Default.QSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointQSeriesRelativeUrl;
                    }
                    else if (SubFolder.Equals(DataLoader.Default.CSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointCSeriesRelativeUrl;
                    }
                    relativeUrl = string.Format("{0}{1}", iflyFolder, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.SBCRJCoverLetter:
                    relativeUrl = string.Format("{0}{1}", DataLoader.Default.SharepointCRJSeriesRelativeUrl, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.SBCRJPDFDocument:
                    relativeUrl = string.Format("{0}{1}", DataLoader.Default.SharepointCRJSeriesRelativeUrl, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.SBCRJServiceBulletin:
                    relativeUrl = string.Format("{0}{1}", DataLoader.Default.SharepointCRJSeriesRelativeUrl, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.TISBDASH:
                    relativeUrl = string.Format("{0}{1}", DataLoader.Default.SharepointQSeriesRelativeUrl, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.TITechManualStatus:
                    if (SubFolder.Equals(DataLoader.Default.CRJSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointCRJSeriesRelativeUrl;
                    }
                    else if (SubFolder.Equals(DataLoader.Default.QSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointQSeriesRelativeUrl;
                    }
                    else if (SubFolder.Equals(DataLoader.Default.CSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointCSeriesRelativeUrl;
                    }
                    relativeUrl = string.Format("{0}{1}", iflyFolder, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.CSeriesSharePoint2010:
                    relativeUrl = DataLoader.Default.CSeriesFolder;
                    relativeUrl = string.Format("{0}{1}", DataLoader.Default.SharepointCSeriesRelativeUrl, this.GetDocumentGroupTitle());
                    break;
                case NotesDatabases.WorkingGroupsPresentationsMeetingMinutes:
                    if (SubFolder.Equals(DataLoader.Default.CRJSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointCRJSeriesRelativeUrl;
                    }
                    else if (SubFolder.Equals(DataLoader.Default.QSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointQSeriesRelativeUrl;
                    }
                    else if (SubFolder.Equals(DataLoader.Default.CSeriesFolder, StringComparison.OrdinalIgnoreCase))
                    {
                        iflyFolder = DataLoader.Default.SharepointCSeriesRelativeUrl;
                    }
                    relativeUrl = string.Format("{0}{1}", iflyFolder, this.GetDocumentGroupTitle());
                    break;
                default:
                    break;
            }
            return relativeUrl;
        }
        //public ContentTypeId GetDocumentSetContentTypeId()
        public string GetDocumentSetContentTypeId()
        {            
            SharePointContentType spCt = HelperClass.ContentTypes.SingleOrDefault(ct => ct.Name.Equals(HelperClass.GetDocumentSetContentType(this.DocumentType), 
                StringComparison.OrdinalIgnoreCase));
            //SharePointContentType spCt = HelperClass.ContentTypes.SingleOrDefault(ct => ct.Name.Equals(this.DocumentType + " " + DataLoader.Default.ContentTypeDocumentSet));
            if (spCt == null)
            {
                TraceFile.WriteLine("Could not load content type \"{0}\"", this.DocumentType);
                return null;
            }
            return spCt.StringId;
            //return spCt.Id;
        }
        //public ContentTypeId GetFileContentTypeId()
        public string GetFileContentTypeId()
        {
            SharePointContentType spCt = HelperClass.ContentTypes.SingleOrDefault(ct => ct.Name.Equals(this.DocumentType, StringComparison.OrdinalIgnoreCase));
            if (spCt == null)
            {
                TraceFile.WriteLine("Could not load content type \"{0}\"", this.DocumentType);
                return null;
            }
            ContentTypeId nct = new ContentTypeId();

            return spCt.StringId;
            //return spCt.Id;
        }
        //public string GetSubFolder()
        //{
        //    string result = null;
        //    switch (DocumentGroupType)
        //    {
        //        case DocumentGroups.EngineeringDocument:
        //            result = Attributes["AircraftFamily"];
        //            break;
        //        case DocumentGroups.GenericDocument:
        //            break;
        //        case DocumentGroups.ServiceDocument:
        //            break;
        //        case DocumentGroups.SuppliersDocuments:
        //            break;
        //        case DocumentGroups.TechnicalNewsletter:
        //            break;
        //        case DocumentGroups.TechnicalPublications:
        //            break;
        //        default:
        //            break;
        //    }
        //    return result;            
        //}
    }
}
