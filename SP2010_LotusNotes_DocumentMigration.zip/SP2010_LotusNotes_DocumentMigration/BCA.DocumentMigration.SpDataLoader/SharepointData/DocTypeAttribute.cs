﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.SharepointData
{
    public class DocTypeAttribute
    {
        public string DocumentType { get; set; }
        public string[] Mandatory { get; set; }
        public string[] Optional { get; set; }
    }
}
