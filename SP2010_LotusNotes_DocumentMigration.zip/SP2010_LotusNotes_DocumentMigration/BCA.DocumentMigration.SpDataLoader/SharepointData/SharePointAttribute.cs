﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.SharepointData
{
    public class SharePointAttribute
    {
        public string Name { get; set; }
        public string InternalName { get; set; }
        public string Sp2010InternalName { get; set; }
        //public string Description { get; set; }
        public string EntryMode { get; set; }
        public string DataType { get; set; }
        public string MaxLength { get; set; }
        public string DefaultValue { get; set; }

        public SharePointAttribute(string name, string internalName, string sp2010InternalName, string entryMode, string dataType, string maxLength, string defaultValue) 
        {
            this.Name = name;
            this.InternalName = internalName;
            this.Sp2010InternalName = sp2010InternalName;
            //this.Description = description;
            this.EntryMode = entryMode;
            this.DataType = dataType;
            this.MaxLength = maxLength;
            this.DefaultValue = defaultValue;
        }
    }
}
