﻿using BCA.DocumentMigration.SpDataLoader.Utils;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.SharepointData
{
    public class SharePointContentType
    {
        public string Name { get; set; }

        //public ContentTypeId Id { get; set; }
        public string StringId { get; set; }
        public List<SharePointField> Fields { get; set; }

        public SharePointContentType()
        {
        }
        public SharePointContentType(string name, string stringId)
        {
            this.Name = name;
            this.StringId = stringId;
            this.Fields = new List<SharePointField>();
        }
        //public SharePointContentType(string name, string stringId, ContentTypeId id)
        //{
        //    this.Name = name;
        //    this.StringId = stringId;
        //    this.Id = id;
        //    this.Fields = new List<SharePointField>();
        //}
        internal SharePointField GetField(string fieldName)
        {
            SharePointField sharePointField = null;

            if (HelperClass.SharepointForcedInternalNameMappings.ContainsKey(fieldName))
            {
                TraceFile.WriteLine("GetField - Switching to InternalName match for '{0}'", fieldName);
                sharePointField = Fields.SingleOrDefault(f => f.InternalName.Equals(HelperClass.SharepointForcedInternalNameMappings[fieldName],
                    StringComparison.OrdinalIgnoreCase));
            }
            else
            {
                sharePointField = Fields.SingleOrDefault(f => f.Title.Equals(fieldName, StringComparison.OrdinalIgnoreCase));

                if (sharePointField == null)
                {
                    sharePointField = Fields.SingleOrDefault(f => f.Title.Equals(fieldName + "(s)", StringComparison.OrdinalIgnoreCase));
                }

                if (sharePointField == null)
                {
                    TraceFile.WriteLine("No exact match found, trying partial match for '{0}'", fieldName);

                    int distance = int.MaxValue;
                    foreach (var field in Fields)
                    {
                        int tempDistance = HelperClass.LevenshteinDistance(fieldName.ToUpper(), field.Title.ToUpper());
                        if (tempDistance < distance)
                        {
                            distance = tempDistance;
                            sharePointField = field;
                        }
                    }
                    //TraceFile.WriteLine("'{0}' was partially matched to '{1}' / '{2}'", fieldName, sharePointField.Title, sharePointField.InternalName);
                }
            }
            TraceFile.WriteLine("GetField - '{0}' was matched to Sharepoint attribute '{1}' / '{2}'", fieldName, sharePointField.Title, sharePointField.InternalName);
            return sharePointField;
        }
    }
}
