﻿using BCA.DocumentMigration.SpDataLoader.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.SharepointData
{
    public class SharePointField
    {        
        public string Title { get; set; }
        public string InternalName { get; set; }
        public Guid Id { get; set; }
        public string TypeAsString { get; set; }
        public bool Required { get; set; }
        public bool AllowMultipleValues { get; set; }
        public SharePointDataTypes SharePointDataType { get; set; }
        public Dictionary<int, string> LookUpValues { get; set; }
        public string[] Choices { get; set; }

        public SharePointField()
        {
        }
        public SharePointField(string title, Guid id, string typeAsString, bool required, string internalName)
        {
            this.Title = title;
            this.Id = id;
            this.TypeAsString = typeAsString;
            this.LookUpValues = new Dictionary<int, string>();
            this.Required = required;
            this.AllowMultipleValues = false;
            this.InternalName = internalName;

            this.SetSharePointDataType(typeAsString);
        }

        private void SetSharePointDataType(string typeAsString)
        {
            if (typeAsString.Trim().Equals("Text", StringComparison.OrdinalIgnoreCase) ||
                (typeAsString.Trim().Equals("Note", StringComparison.OrdinalIgnoreCase)))
            {
                this.SharePointDataType = SharePointDataTypes.Text;
            }
            else if (typeAsString.ToUpper().Contains("LOOK"))
            {
                this.SharePointDataType = SharePointDataTypes.Lookup;
            }
            else if (typeAsString.Trim().Equals("Choice", StringComparison.OrdinalIgnoreCase))
            {
                this.SharePointDataType = SharePointDataTypes.Choice;
            }
            else if (typeAsString.Trim().Equals("Computed", StringComparison.OrdinalIgnoreCase))
            {
                this.SharePointDataType = SharePointDataTypes.Computed;
            }
            else if (typeAsString.Trim().Equals("DateTime", StringComparison.OrdinalIgnoreCase))
            {
                this.SharePointDataType = SharePointDataTypes.DateTime;
            }
            else if (typeAsString.Trim().Equals("Boolean", StringComparison.OrdinalIgnoreCase))
            {
                this.SharePointDataType = SharePointDataTypes.Boolean;
            }
            else if (typeAsString.Trim().Equals("Number", StringComparison.OrdinalIgnoreCase))
            {
                this.SharePointDataType = SharePointDataTypes.Number;
            }
            else
            {
                this.SharePointDataType = SharePointDataTypes.Other;
            }
        }
        internal int GetLookupValue(string attributeValue, string subFolder, out string lookupStringValue, string[] models, out string faultyAtaText, bool isBeginsWithField = false)
        {
            faultyAtaText = null;
            lookupStringValue = null;

            bool validValue;
            string tempSearchValue = isBeginsWithField ? string.Format("[{0}]{1}", subFolder, attributeValue) : attributeValue;
            KeyValuePair<int, string> lookupMatch;

            lookupMatch = LookUpValues.SingleOrDefault(l => l.Value.Trim().Equals(tempSearchValue.Trim(), StringComparison.OrdinalIgnoreCase));
            validValue = !lookupMatch.Equals(default(KeyValuePair<int, string>));

            if (!validValue && isBeginsWithField)
            {
                if (LookUpValues.Count(l => l.Value.StartsWith(tempSearchValue, StringComparison.OrdinalIgnoreCase)) > 1)
                {
                    var matchValues = LookUpValues.Where(l =>
                                      l.Value.StartsWith(tempSearchValue, StringComparison.OrdinalIgnoreCase));
                    lookupMatch = FindClosestLookupValue(matchValues, models);

                    validValue = !lookupMatch.Equals(default(KeyValuePair<int, string>));

                    if (validValue)
                    {
                        lookupStringValue = lookupMatch.Value.TrimStart(string.Format("[{0}]", subFolder));
                        TraceFile.WriteLine("GetLookupValue - Found Multiple Matches for '{0}' and picked '{1}' for models '{2}'",
                            tempSearchValue, lookupMatch.Value, string.Join(", ", models));
                        return lookupMatch.Key;
                    }
                    else
                    {
                        TraceFile.WriteLine("GetLookupValue - ERROR - Found Multiple Matches for '{0}' and Found NO MATCH for models '{1}'",
                            tempSearchValue, lookupMatch.Value, string.Join(", ", models));
                        return -1;
                    }
                }
                else
                {
                    lookupMatch = LookUpValues.SingleOrDefault(l => l.Value.StartsWith(tempSearchValue, StringComparison.OrdinalIgnoreCase));

                    validValue = !lookupMatch.Equals(default(KeyValuePair<int, string>));

                    if (validValue)
                    {
                        string trimMatch = lookupMatch.Value.TrimStart(tempSearchValue).Trim();
                        if (trimMatch.StartsWith("(", StringComparison.OrdinalIgnoreCase) && !trimMatch.Contains(models))
                        {
                            // add log entry here???????????????????????????
                            faultyAtaText = string.Format("{0}: {1}\nModel(s): {2}", this.InternalName,
                                lookupMatch.Value.TrimStart(string.Format("[{0}]", subFolder)), string.Join(", ", models));
                            TraceFile.WriteLine("GetLookupValue - ERROR - search value '{0}' - '{1}' does not contain expected models '{2}'",
                                tempSearchValue, lookupMatch.Value, string.Join(", ", models));
                            //return -1;
                            lookupStringValue = lookupMatch.Value.TrimStart(string.Format("[{0}]", subFolder));
                            return lookupMatch.Key;
                        }
                        else
                        {                            
                            TraceFile.WriteLine("GetLookupValue - '{0}' has match '{1}' for models '{2}'",
                                tempSearchValue, lookupMatch.Value, string.Join(", ", models));
                            lookupStringValue = lookupMatch.Value.TrimStart(string.Format("[{0}]", subFolder));
                            return lookupMatch.Key;
                        }
                    }
                    else
                    {
                        return -1;
                    }
                }

            }
            return (validValue ? lookupMatch.Key : -1);
        }

        private KeyValuePair<int, string> FindClosestLookupValue(IEnumerable<KeyValuePair<int, string>> matchValues, string[] models)
        {
            return matchValues.FirstOrDefault(mv => mv.Value.Contains(models));
        }

        internal bool GetChoiceValue(string attributeValue, out string choiceMatch)
        {
            choiceMatch = Choices.SingleOrDefault(l => l.Equals(attributeValue, StringComparison.OrdinalIgnoreCase));
            return !string.IsNullOrWhiteSpace(choiceMatch);
        }

        //internal int GetLookupValue(string attributeValue)
        //{
        //    var lookupMatch = LookUpValues.SingleOrDefault(l => l.Value.Equals(attributeValue, StringComparison.OrdinalIgnoreCase));

        //    return (!lookupMatch.Equals(default(KeyValuePair<int, string>)) ? lookupMatch.Key : -1);
        //}
        //internal int GetLookupValue(string attributeValue, string subFolder, out string lookupStringValue, bool isBeginsWithField = false)
        //{
        //    lookupStringValue = null;

        //    bool validValue;
        //    string tempSearchValue = isBeginsWithField ? string.Format("[{0}]{1}", subFolder, attributeValue) : attributeValue;
        //    KeyValuePair<int, string> lookupMatch;

        //    if (isBeginsWithField && LaunchConfiguration.Default.ALLOW_ATA_EXCEPTIONS)
        //    {
        //        if (LookUpValues.Count(l => l.Value.StartsWith(tempSearchValue, StringComparison.OrdinalIgnoreCase)) > 1)
        //        {
        //            int key = LookUpValues.First(l => l.Value.StartsWith(tempSearchValue, StringComparison.OrdinalIgnoreCase)).Key;
        //            var matchValues = LookUpValues.Select(l => l.Value).Distinct(StringComparer.OrdinalIgnoreCase).Where(l =>
        //                              l.StartsWith(tempSearchValue, StringComparison.OrdinalIgnoreCase)).Select(
        //                              l => l.TrimStart(string.Format("[{0}]", subFolder))).ToArray();
        //            string value = string.Format("{0}", string.Join("\n** ", matchValues));
        //            lookupMatch = new KeyValuePair<int, string>(key, value);
        //            lookupStringValue = lookupMatch.Value;
        //            return lookupMatch.Key;
        //        }
        //        else
        //        {
        //            lookupMatch = LookUpValues.SingleOrDefault(l => l.Value.Equals(tempSearchValue, StringComparison.OrdinalIgnoreCase));
        //        }

        //    }
        //    else
        //    {
        //        lookupMatch = LookUpValues.SingleOrDefault(l => l.Value.Equals(tempSearchValue, StringComparison.OrdinalIgnoreCase));

        //    }
        //    validValue = !lookupMatch.Equals(default(KeyValuePair<int, string>));

        //    if (isBeginsWithField && !validValue)
        //    {
        //        lookupMatch = LookUpValues.SingleOrDefault(l => l.Value.StartsWith(tempSearchValue, StringComparison.OrdinalIgnoreCase));
        //        if (!lookupMatch.Equals(default(KeyValuePair<int, string>)))
        //        {
        //            lookupStringValue = lookupMatch.Value.TrimStart(string.Format("[{0}]", subFolder));
        //            return lookupMatch.Key;
        //        }
        //        else
        //        {
        //            return -1;
        //        }
        //    }
        //    else
        //    {
        //        return (validValue ? lookupMatch.Key : -1);
        //    }

        //}
    }
}
