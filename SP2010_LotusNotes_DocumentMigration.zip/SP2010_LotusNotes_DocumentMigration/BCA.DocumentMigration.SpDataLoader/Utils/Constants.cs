﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{    
    public enum DocumentGroups
    {
        EngineeringDocument,
        GenericDocument,
        ServiceDocument,
        SuppliersDocuments,
        TechnicalNewsletter,
        TechnicalPublications
    }
    public enum NotesDatabases
    {
        THDTorontoLibrary,
        THDLibrary,
        WorkingGroups,
        SBCRJPDFDocument,
        SBCRJServiceBulletin,
        SBCRJCoverLetter,
        TISBDASH,
        TITechManualStatus,
        CSeriesSharePoint2010,
        WorkingGroupsPresentationsMeetingMinutes,
    }

    public enum ExcelReportSheets
    {
        General,
        NotesSuccess,
        NotesFailure,
        FilteringRules,
        TransformationRules,
        MandatoryFieldRules,
        FieldsLengthRules,
        SharePointData
    }
    public enum SharePointDataTypes
    {
        Other,
        Text,
        Lookup,
        MultiLookup,
        Choice,
        DateTime,
        Computed,
        Boolean,
        Number
    }
    public enum BuildEffectivityStatus
    {
        Success,
        SplitRange,
        ModelNotFound,
        UseEffectivityAsIs,
        EmptyResult
    }
    public static class Constants
    {
        public static readonly string[] MandatoryFieldCheckExclusionList = { "DocumentGroup", "DocumentType", "Created By", "Created On", "Document Format", "Size", "UNID", "Title of the Document" };
        public static readonly string[] THDRevisionCategoriesCheck = { "REO", "Kit Drawing" };
        public static readonly string[] SharepointATAFieldsInternalNames = { "MainATASNS", "SubATASNS" };
        public static readonly string SharepointMainATAFieldInternalName = "MainATASNS";
        public static readonly string SharepointSubATAFieldInternalName = "SubATASNS";
        public static readonly string[] SharePointExclusionList = { "Name","DocumentGroup", "DocumentType", "Created By", "Created On", "Document Format", "Size", "ContentType", "Content Type" };
        public static readonly string[] THDTorontoLibrarySharePointExclusionList = { "DocumentGroup", "DocumentType", "Created By", "Created On", "Document Format", "Size" };
        public static readonly string[] SharePointSubFolders = { DataLoader.Default.CRJSeriesFolder, DataLoader.Default.QSeriesFolder, DataLoader.Default.CSeriesFolder };
        public static readonly string[] SharePointFileInvalidEndingsReplace = { ".", " ", ".files", "_files", "-Dateien", "_fichiers", "_bestanden", "_file", "_archivos", "-filer",
                                                                         "_tiedostot", "_pliki", "_soubory", "_elemei", "_ficheiros", "_arquivos", "_dosyalar",
                                                                         "_datoteke", "_fitxers", "_failid", "_fails", "_bylos", "_fajlovi", "_fitxategiak" };
        public static readonly string[] SharePointFileInvalidEndingsCheck = { ".", ".files", "_files", "-Dateien", "_fichiers", "_bestanden", "_file", "_archivos", "-filer",
                                                                         "_tiedostot", "_pliki", "_soubory", "_elemei", "_ficheiros", "_arquivos", "_dosyalar",
                                                                         "_datoteke", "_fitxers", "_failid", "_fails", "_bylos", "_fajlovi", "_fitxategiak" };

        public static readonly string[] ThdTorontoLibraryFullEffectivityRanges = {  "003 - 672", 
                                                                                    "100 - 672",
                                                                                    "4001 - 4999",
                                                                                    "4001,4003 - 4999",
                                                                                    "4001,4003,4004,4006,4008 - 4140,4142 - 4999",
                                                                                    "4001,4003,4004,4006,4008 - 4999",
                                                                                    "4003 - 4004,4006,4008 - 4999",
                                                                                    "4003 - 4029,4031 - 4999",
                                                                                    "4003 - 4999",
                                                                                    "4003,4004,4006,4008 - 4140,4142 - 4999",
                                                                                    "4003,4004,4006,4008 - 4999"  };

        public static readonly string[] SbDashFullEffectivityRanges = {             "002 - 672",
                                                                                    "003 - 585,593 - 593,637 - 637",
                                                                                    "003 - 593",
                                                                                    "003 - 664",
                                                                                    "003 - 672",
                                                                                    "100 - 672",
                                                                                    "4001 - 4001,4003 - 4004,4006 - 4006,4008 - 4999",
                                                                                    "4001 - 4001,4003 - 4004,4006 - 4999",
                                                                                    "4001 - 4001,4003 - 4999",
                                                                                    "4001 - 4999"  };
        public static readonly string[] ServiceBulletinFullEffectivityRanges = {    "003 - 999",
                                                                                    "10002 - 10999,15001 - 15990,19001 - 19990",
                                                                                    "10003 - 10999,15001 - 15990",
                                                                                    "10005 - 10071,15001 - 15990",
                                                                                    "19001 - 19990" };
        public static Dictionary<string, string> WorkingGroupsPresentationsMeetingMinutesEffectivityTranslationMap = new Dictionary<string, string>
    {
        {"Q Series|||CRJ Series::CRJ100, CRJ200, CRJ440::All||Q Series|||CRJ Series::CRJ700::All||Q Series|||CRJ Series::CRJ705, CRJ900::All||Q Series|||CRJ Series::CRJ1000::All||Q Series|||CRJ Series::Q100::All||Q Series|||CRJ Series::Q200::All||Q Series|||CRJ Series::Q300::All||Q Series|||CRJ Series::Q400::All",
                "CRJ Series::CRJ100, CRJ200, CRJ440::All||CRJ Series::CRJ700::All||CRJ Series::CRJ705, CRJ900::All||CRJ Series::CRJ1000::All||Q Series::Q100::All||Q Series::Q200::All||Q Series::Q300::All||Q Series::Q400::All" }
    };
        //const int DATA_EXTRACT_HEADER_ROW = 4;
        public const string Categories = "Categories";
        public const string effectivityValuesSeparators = @"(?<=\d+)\s*?(,-|,[ ]*and|[ ,;/&.]|and)\s*(?=\d+)";// @"\s*(,-|[,;/&.]|and)\s*";
        public const string whiteSpaceRegex = @"[\n\r\t]+|(_x000D_)+";
        //public const string numericDateRegex = @"^\d{4}-\d{2}-\d{2}$";
        public const string numericDateRegex = @"^\d{2}(\d{2})-(\d{2})-(\d{2})$";
        public const string effectivityValuesSeparatorsReplacement = ",";
        public const string effectivityRangesIndicators = @"\s*([-−]|thru|to|through)\s*";
        public const string effectivityRangesIndicatorsReplacement = " - ";
        public const string effectivitySubsIndicators = @",*\s*(& subs|and subsequent|-subsequent|and subs|-[ ]*subs|-[ ]*sub)\s*";
        public const string effectivitySubsIndicatorsReplacement = " - ral";
        public const string ExcelSpecialCharacter = "_x000D_";
        public const string SharePointInvalidFolderCharsReplacement = "-";
        public const string SharePointInvalidFileCharsReplacement = " ";
        public const int AlphabetSize = 26;
        public const string CoverLetterFormat1 = "601R";
        public const string CoverLetterFormat2 = "670BA";
        public const string CoverLetterFormat1v2 = "601-R";
        public const string CoverLetterFormat2v2 = "670-BA";
        public const string ServiceBulletinNumberRegEx = @"([A-Za-z]*(670BA|601R)-(?!00)\d{2}[A-Za-z0-9-/]*)";
        public const string TransmittalLetterNumberRegEx = @"([A-Za-z]*(670BA|601R)-00[A-Za-z0-9-/]*)";
    }
}
