﻿using BCA.DocumentMigration.SpDataLoader.NotesData;
using BCA.DocumentMigration.SpDataLoader.Utils;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using SpreadsheetLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Collections.Concurrent;
using System.Text.RegularExpressions;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    class ExcelHelper
    {
        /// <summary>
        /// Load SharePoint fields from excel file
        /// </summary>
        /// <param name="fileName">Excel file</param>
        public static void LoadSharePointFields(string fileName)
        {
            //Load first work sheet of excel file
            using (SLDocument sl = new SLDocument(fileName))
            {
                //Get stats of excel sheet
                SLWorksheetStatistics stats = sl.GetWorksheetStatistics();
                int startCol = stats.StartColumnIndex;
                int startRow = stats.StartRowIndex;
                int endCol = stats.EndColumnIndex;
                int endRow = stats.EndRowIndex;

                int headerRow = DataLoader.Default.SharePointFieldsHeaderRow;
                int contentRow = headerRow + 1;

                for (int col = startCol; col <= endCol; col++)
                {
                    //TraceFile.WriteLine("Header {0}, {1}", col, sl.GetCellValueAsString(headerRow, col));
                }

                //Add SharePoint attributes from excel to object
                for (int row = contentRow; row <= endRow; row++)
                {
                    HelperClass.SharepointAttributes.Add(new SharePointAttribute(sl.GetCellValueAsString(row, 1).Trim(), // Name
                        sl.GetCellValueAsString(row, 5).Trim(), // Internal Name
                        sl.GetCellValueAsString(row, 6).Trim(), // SP 2010 Internal Name
                        sl.GetCellValueAsString(row, 8).Trim(), // Entry Mode
                        sl.GetCellValueAsString(row, 10).Trim(), // Data Type
                        sl.GetCellValueAsString(row, 11).Trim(), // MaxLength
                        sl.GetCellValueAsString(row, 14).Trim())); // Default Value

                    //for (int col = startCol; col <= endCol; col++)
                    //{
                    //    TraceFile.WriteLine("Row {0}, Col {1}: {2}", row, col, sl.GetCellValueAsString(row, col));
                    //}
                }
            }
            //SharepointAttributesNamesList from excel
            var SharepointAttributesNamesList = HelperClass.SharepointAttributes.Select(s => s.Name).ToList();
            SharepointAttributesNamesList.Add(DataLoader.Default.SharepointDocumentIDField);
            SharepointAttributesNamesList.Add(DataLoader.Default.Sharepoint2010DocumentSetIDField);
            SharepointAttributesNamesList.Add(DataLoader.Default.SharepointPortalEffectivityField);
            HelperClass.SharepointAttributesNames = SharepointAttributesNamesList.ToArray();
            //DataLoader.Default.SharePointNameField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharePointNameField);
            DataLoader.Default.SharepointModelNumberField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointModelNumberField);
            DataLoader.Default.SharepointSubModelNumberField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointSubModelNumberField);
            DataLoader.Default.SharepointEffectivityField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointEffectivityField);
            DataLoader.Default.SharePointAircrafFamilyField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharePointAircrafFamilyField);
            DataLoader.Default.SharePointDocumentTypeField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharePointDocumentTypeField);
            DataLoader.Default.SharePointDocumentGroupField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharePointDocumentGroupField);
            DataLoader.Default.SharepointRevisionField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointRevisionField);
            DataLoader.Default.SharepointAvailableOnPortal = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointAvailableOnPortal);
            DataLoader.Default.SharepointPartSerialNumberField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointPartSerialNumberField);
            DataLoader.Default.SharepointSubAtaField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointSubAtaField);
            DataLoader.Default.SharepointMainAtaField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointMainAtaField);
            DataLoader.Default.SharepointPartSerialNumberField = HelperClass.GetNormalizedSharePointAttributeName(DataLoader.Default.SharepointPartSerialNumberField);            
        }

        /// <summary>
        /// Get lotus notes extract from excel file to NotesExtract object
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="notesDatabase"></param>
        /// <returns></returns>
        public static NotesExtract LoadNotesExtract(string fileName, NotesDatabases notesDatabase)
        {
            TraceFile.WriteLine(true, "Processing {0}", fileName);

            int logsId = Interlocked.Increment(ref HelperClass.logsCounter);
            Logs logs = new Logs(HelperClass.GetContainingFolder(fileName));
            logs.DataBase = notesDatabase;
            HelperClass.ReportLogs.GetOrAdd(logsId, logs);
            //extract time starts
            Stopwatch sw = Stopwatch.StartNew();
            List<string> header = new List<string>();
            //FIFO collection
            ConcurrentQueue<NotesDocument> documents = new ConcurrentQueue<NotesDocument>();
            string dbName = null;
            //DateTime lastModified = DateTime.Now;
            NotesExtract notesExtract = null;
            //SLDocument sl = new SLDocument(fileName);
            //Get notest extract excel file
            using (SLDocument sl = new SLDocument(fileName))
            {
                SLWorksheetStatistics stats = sl.GetWorksheetStatistics();
                int startCol = stats.StartColumnIndex;
                int startRow = stats.StartRowIndex;
                int endCol = stats.EndColumnIndex;
                int endRow = stats.EndRowIndex;

                //TraceFile.WriteLine("StartColumnIndex: {0}", iStartColumnIndex);
                int title1Row = DataLoader.Default.DataExtractTitle1Row;
                int title2Row = DataLoader.Default.DataExtractTitle2Row;
                int dateRow = DataLoader.Default.DataExtractDateRow;
                int headerRow = DataLoader.Default.DataExtractHeaderRow;
                int contentRow = headerRow + 1;                
                //get database name from excel file
                dbName = sl.GetCellValueAsString(title2Row, startCol).Trim();

                for (int col = startCol; col <= endCol; col++)
                {
                    string rowValue = sl.GetCellValueAsString(headerRow, col);
                    if (!HelperClass.NullOrEmpty(rowValue))
                    {
                        header.Add(rowValue.Trim());
                    }
                    else
                    {
                        break;
                    }                    
                }

                for (int row = contentRow; row <= endRow; row++)
                {
                    bool addDocument = true;
                    //NotesDocument object to store data from excel
                    NotesDocument notesDocument = new NotesDocument();
                    for (int col = startCol; col <= endCol; col++)
                    {
                        string rowValue = sl.GetCellValueAsString(row, col);
                        if (col < startCol + header.Count && addDocument)
                        {                                                        
                            if (header[col - startCol].Trim().ToUpper().Equals(DataLoader.Default.Uid.ToUpper()))
                            {
                                notesDocument.Attributes.Add(header[col - startCol], rowValue.Trim());
                                notesDocument.Uid = sl.GetCellValueAsString(row, col).Trim();
                                addDocument = logs.AddLog(notesDocument.Uid);
                            }
                            else
                            {
                                if (!HelperClass.NullOrEmpty(rowValue))
                                {
                                    if (header[col - startCol].Trim().ToUpper().Contains("DATE") || header[col - startCol].Trim().ToUpper().Contains("TIME") ||
                                        HelperClass.FieldsWithDate.Contains(header[col - startCol].Trim(), StringComparer.OrdinalIgnoreCase))
                                    {
                                        DateTime dt = sl.GetCellValueAsDateTime(row, col);
                                        if (dt.Year > 1900 && (!header[col - startCol].Trim().Equals("SBAtaRef", StringComparison.OrdinalIgnoreCase) || 
                                            !Regex.IsMatch(rowValue.Trim(), @"^\d{1,4}$")))
                                        {
                                            notesDocument.Attributes.Add(header[col - startCol], String.Format("{0:MM/dd/yyyy}", dt));
                                        }
                                        else
                                        {
                                            notesDocument.Attributes.Add(header[col - startCol], rowValue.Trim().RemoveDiacritics().ReplaceIgnoreCase(Constants.ExcelSpecialCharacter, string.Empty));
                                        }
                                        
                                        //TraceFile.WriteLine("Date attempt");
                                    }
                                    else
                                    {
                                        notesDocument.Attributes.Add(header[col - startCol], rowValue.Trim().RemoveDiacritics().ReplaceIgnoreCase(Constants.ExcelSpecialCharacter, string.Empty));
                                    }                                    
                                }
                                else
                                {
                                    notesDocument.Attributes.Add(header[col - startCol], string.Empty);
                                }
                            }
                        }
                        else if (!HelperClass.NullOrEmpty(rowValue))
                        {
                            notesDocument.Attachments.Add(rowValue.Trim());
                        }
                        else
                        {
                            break;
                        }
                    }
                    if (addDocument)
                    {
                        documents.Enqueue(notesDocument);
                    }
                    else
                    {
                        //TraceFile.WriteLine("Skipping duplicate");
                    }
                    
                }
            }
            switch (notesDatabase)
            {
                case NotesDatabases.THDTorontoLibrary:
                    notesExtract = new THDTorontoLibrary(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.THDLibrary:
                    notesExtract = new THDLibrary(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.WorkingGroups:
                    notesExtract = new WorkingGroups(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.SBCRJCoverLetter:
                    notesExtract = new SB_CRJ_CoverLetter(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.SBCRJPDFDocument:
                    notesExtract = new SB_CRJ_PDFDocument(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.SBCRJServiceBulletin:
                    notesExtract = new SB_CRJ_ServiceBulletin(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.TISBDASH:
                    notesExtract = new SB_Dash(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.TITechManualStatus:
                    notesExtract = new TiTechManualStatus(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.CSeriesSharePoint2010:
                    notesExtract = new SP2010(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                case NotesDatabases.WorkingGroupsPresentationsMeetingMinutes:
                    notesExtract = new WorkingGroups_Presentations_MeetingMinutes(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
                default:
                    notesExtract = new NotesExtract(dbName, fileName, header, documents, notesDatabase, logsId);
                    break;
            }
            sw.Stop();
            TraceFile.WriteLine(true, "Finished Processing {0} in {1}", fileName, sw.Elapsed.ToString("mm\\:ss\\.ff"));
            return notesExtract;
            //sl.CloseWithoutSaving();
        }

        public static ConcurrentBag<NotesExtract> LoadNotesExtracts(string folder, NotesDatabases notesDatabase)
        {
            NotesExtract notesExtract = null;
            List<NotesDocument> notesDocuments = new List<NotesDocument>();
            ConcurrentBag<NotesExtract> notesExtracts = new ConcurrentBag<NotesExtract>();

            var files = Directory.GetFiles(folder, "*.xlsx", SearchOption.AllDirectories).Where(f => !f.StartsWith("~", StringComparison.OrdinalIgnoreCase));

            AutoResetEvent[] threadEvents = new AutoResetEvent[files.Count()];

            for (int i = 0; i < threadEvents.Length; ++i)
            {
                threadEvents[i] = new AutoResetEvent(false);
            }

            Stopwatch sw = Stopwatch.StartNew();
            int j = 0;
            foreach (var file in files)
            {
               // HelperClass.FreeMemory();
                //TraceFile.WriteLine("File {0}", file);                
                //TraceFile.WriteLine("File {0} - size: {1}", file, currentnotesExtract.Documents.Count);
                //currentnotesExtract = LoadNotesExtract(file, notesDatabase);

                ThreadPool.QueueUserWorkItem(delegate (object o)
                {
                    notesExtracts.Add(LoadNotesExtract(file, notesDatabase));
                    threadEvents[(int)o].Set();
                    HelperClass.FreeMemory();

                }, j);


                //if (notesExtract == null)
                //{
                //    notesExtract = currentnotesExtract;
                //}
                //else
                //{
                //    notesExtract.Documents.AddRange(currentnotesExtract.Documents);
                //}
                j++;
            }

            WaitHandle.WaitAll(threadEvents);
            sw.Stop();
            TraceFile.WriteLine("Elapsed time: {0}", sw.Elapsed.ToString("mm\\:ss\\.ff"));
            return notesExtracts;
            ////TraceFile.WriteLine("Final extract - size: {0}", notesExtract.Documents.Count);

            //if (notesExtracts.Count > 0)
            //{
            //    bool isSet = false;
            //    foreach (var extract in notesExtracts)
            //    {
            //        if (!isSet)
            //        {
            //            notesExtract = extract;
                        
            //            isSet = true;
            //        }
            //        notesDocuments.AddRange(extract.Documents);
            //    }

            //}
            //notesExtract.Documents = new ConcurrentQueue<NotesDocument>(notesDocuments);
            //return notesExtract;

        }

        //internal static void CreateExtractReport(NotesDatabases notesDatabase)
        //{
        //    string fileName = null, title = null;
        //    SLDocument sl = new SLDocument();
        //    SLStyle styleGeneral, styleTitle, styleNotes, styleNotesGreen, styleNotesRed, styleNotesGrey;

        //    SetProperties(notesDatabase, ref fileName, ref title, "");
        //    SetStyles(out styleGeneral, out styleTitle, out styleNotes, out styleNotesGreen, out styleNotesRed, out styleNotesGrey, sl);
        //    CreateSheets(sl);

        //    FillGeneralSheet(title, sl, styleGeneral, styleTitle);

        //    // Success Tab
        //    FillNotesSheet(sl, styleNotes, true);

        //    // Failure Tab
        //    FillNotesSheet(sl, styleNotes, false);

        //    FillFilteringSheet(sl, styleNotes);

        //    FillRuleSheet(sl, styleNotes, ExcelReportSheets.TransformationRules);
        //    FillRuleSheet(sl, styleNotes, ExcelReportSheets.MandatoryFieldRules);
        //    FillRuleSheet(sl, styleNotes, ExcelReportSheets.FieldsLengthRules);

        //    FillSharePointSheet(sl, styleNotes);

        //    sl.SelectWorksheet("General");

        //    sl.SaveAs(fileName);
        //}

        /// <summary>
        /// Creates excel report for given notes extract
        /// </summary>
        /// <param name="notesDatabase">notes database like THD library</param>
        /// <param name="logsId">logs id of notes database</param>
        internal static void CreateExtractReportFromTemplate(NotesDatabases notesDatabase, int logsId)
        {
            Logs logs = HelperClass.ReportLogs[logsId];
            string fileName = null, title = null;
            SLDocument sl   = new SLDocument(DataLoader.Default.ReportTemplatePath);
            SLStyle styleGeneral, styleTitle, styleNotes, styleNotesGreen, styleNotesRed, styleNotesGrey;

            SetProperties(notesDatabase, ref fileName, ref title, logs.Folder);
            SetStyles(out styleGeneral, out styleTitle, out styleNotes, out styleNotesGreen, out styleNotesRed, out styleNotesGrey, sl);
            //Fill summary sheet of excel report
            FillSummarySheet(title, sl, logsId);

            // Success Tab

            ConcurrentBag<NotesRow> notesRows;
            ConcurrentBag<List<string>> sharepointRows;
            ConcurrentBag<NotesRow> effectivityValidationRows;
            ConcurrentBag<NotesRow> ataValidationRows;

            logs.GetNotesAndSharepointRows(out notesRows, out sharepointRows, out effectivityValidationRows, out ataValidationRows);
            // Fill report sheet which will observed by business to verify migration
            FillReportSheet(sl, styleNotes, styleNotesGreen, styleNotesRed, styleNotesGrey, notesRows, logsId);

            notesRows = null;
            HelperClass.FreeMemory();
            // Fill sharepoint sheet. this data will be migrated to SharePoint
            FillSharePointSheet(sl, styleNotes, sharepointRows, logsId);

            sharepointRows = null;
            HelperClass.FreeMemory();

            if (effectivityValidationRows != null && effectivityValidationRows.Count > 0)
            {
                FillEffectivityValidationSheet(sl, styleNotes, styleNotesGreen, styleNotesRed, styleNotesGrey, effectivityValidationRows, logsId);

                effectivityValidationRows = null;
                HelperClass.FreeMemory();
            }
            else
            {
                sl.DeleteWorksheet("4-Effectivity Validation");
            }

            if (ataValidationRows != null && ataValidationRows.Count > 0)
            {
                FillAtaValidationSheet(sl, styleNotes, styleNotesGreen, styleNotesRed, styleNotesGrey, ataValidationRows, logsId);

                ataValidationRows = null;
                HelperClass.FreeMemory();
            }
            else
            {
                sl.DeleteWorksheet("5-ATA Validation");
            }

            sl.SelectWorksheet("1-Summary");

            sl.SaveAs(fileName);
        }
        //internal static void CreateExtractReportFromTemplateFull(NotesDatabases notesDatabase)
        //{
        //    string fileName = null, title = null;
        //    SLDocument sl = new SLDocument(DataLoader.Default.ReportTemplateFullPath);
        //    SLStyle styleGeneral, styleTitle, styleNotes, styleNotesGreen, styleNotesRed, styleNotesGrey;

        //    SetProperties(notesDatabase, ref fileName, ref title, "");
        //    SetStyles(out styleGeneral, out styleTitle, out styleNotes, out styleNotesGreen, out styleNotesRed, out styleNotesGrey, sl);
        //    //CreateSheets(sl);

        //    FillSummarySheet(title, sl);

        //    // Success Tab
        //    FillReportSheet(sl, styleNotes, styleNotesGreen, styleNotesRed, styleNotesGrey);


        //    FillFilteringSheet(sl, styleNotes);

        //    FillRuleSheet(sl, styleNotes, ExcelReportSheets.TransformationRules);
        //    FillRuleSheet(sl, styleNotes, ExcelReportSheets.MandatoryFieldRules);
        //    FillRuleSheet(sl, styleNotes, ExcelReportSheets.FieldsLengthRules);

        //    FillSharePointSheet(sl, styleNotes);

        //    sl.SelectWorksheet("1-Summary");

        //    sl.SaveAs(fileName);
        //}

        //private static void FillReportSheet(SLDocument sl, SLStyle styleNotes, SLStyle styleNotesGreen, SLStyle styleNotesRed, SLStyle styleNotesGrey)
        //{
        //    List<string> headers;
        //    List<List<string>> notesRows;
        //    int row;
        //    SLTable tbl;

        //    sl.SelectWorksheet("2-Report");

        //    headers = Logs.Instance.GetNotesHeaders();
        //    for (int i = 1; i <= headers.Count; ++i)
        //    {
        //        sl.SetCellValue(1, i, headers[i - 1]);

        //        if (headers[i - 1].Equals("Reason", StringComparison.OrdinalIgnoreCase))
        //        {
        //            sl.SetColumnWidth(i, 60);
        //        }
        //        else
        //        {
        //            sl.SetColumnWidth(i, 20);
        //        }

        //    }
        //    List<List<string>> errorFields;
        //    SLStyle customStyle = null;
        //    notesRows = Logs.Instance.GetNotesRows(out errorFields);
        //    row = 2;
        //    foreach (var resultRow in notesRows)
        //    {
        //        for (int i = 1; i <= resultRow.Count; ++i)
        //        {
        //            sl.SetCellValue(row, i, resultRow[i - 1]);                   

        //            if (i == 1)
        //            {
        //                if (resultRow[i - 1].Equals("Success", StringComparison.OrdinalIgnoreCase))
        //                {
        //                    sl.SetCellStyle(row, i, styleNotesGreen);
        //                    customStyle = styleNotes;
        //                }
        //                else if (resultRow[i - 1].Equals("Exclusion", StringComparison.OrdinalIgnoreCase))
        //                {
        //                    sl.SetCellStyle(row, i, styleNotesGrey);
        //                    customStyle = styleNotesGrey;
        //                }
        //                else if (resultRow[i - 1].Equals("Failure", StringComparison.OrdinalIgnoreCase))
        //                {
        //                    sl.SetCellStyle(row, i, styleNotesRed);
        //                    customStyle = styleNotesRed;
        //                }
        //            }
        //            else if (errorFields[row - 2].Contains(headers[i - 1], StringComparer.OrdinalIgnoreCase))
        //            {
        //                sl.SetCellStyle(row, i, customStyle);
        //            }
        //            else
        //            {
        //                sl.SetCellStyle(row, i, styleNotes);
        //            }
        //        }
        //        row++;
        //    }
        //    tbl = sl.CreateTable(1, 1, notesRows.Count + 1, headers.Count);
        //    tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
        //    sl.InsertTable(tbl);
        //}
        private static void FillAtaValidationSheet(SLDocument sl, SLStyle styleNotes, SLStyle styleNotesGreen, SLStyle styleNotesRed, SLStyle styleNotesGrey, ConcurrentBag<NotesRow> effectivityValidationRows, int logsId)
        {
            TraceFile.WriteLine("FillAtaValidationSheet");
            Logs logs = HelperClass.ReportLogs[logsId];
            List<string> headers;
            int row;
            SLTable tbl;
            bool validationSet = false;

            sl.SelectWorksheet("5-ATA Validation");

            headers = logs.GetNotesHeaders(true);
            for (int i = 1; i <= headers.Count; ++i)
            {
                sl.SetCellValue(1, i, headers[i - 1]);
                if (headers[i - 1].Equals("Validation", StringComparison.OrdinalIgnoreCase) && !validationSet)
                {
                    sl.SetColumnWidth(i, 60);
                    validationSet = true;
                }
                else
                {
                    sl.SetColumnWidth(i, 20);
                }             
            }
            row = 2;
            foreach (var resultRow in effectivityValidationRows)
            {
                for (int i = 1; i <= resultRow.Data.Count; ++i)
                {
                    sl.SetCellValue(row, i, resultRow.Data[i - 1]);

                    if (i == 1)
                    {
                        if (resultRow.Data[i - 1].Equals("Success", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesGreen);
                        }
                        else if (resultRow.Data[i - 1].Equals("Exclusion", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesGrey);
                        }
                        else if (resultRow.Data[i - 1].Equals("Failure", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesRed);
                        }
                    }
                    else
                    {
                        sl.SetCellStyle(row, i, styleNotes);
                    }
                }
                row++;
            }
            tbl = sl.CreateTable(1, 1, effectivityValidationRows.Count + 1, headers.Count);
            tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
            sl.InsertTable(tbl);
        }
        private static void FillEffectivityValidationSheet(SLDocument sl, SLStyle styleNotes, SLStyle styleNotesGreen, SLStyle styleNotesRed, SLStyle styleNotesGrey, ConcurrentBag<NotesRow> effectivityValidationRows, int logsId)
        {
            TraceFile.WriteLine("FillEffectivityValidationSheet");
            Logs logs = HelperClass.ReportLogs[logsId];
            List<string> headers;
            int row;
            SLTable tbl;

            sl.SelectWorksheet("4-Effectivity Validation");

            headers = logs.GetNotesHeaders(true);
            for (int i = 1; i <= headers.Count; ++i)
            {
                sl.SetCellValue(1, i, headers[i - 1]);
                sl.SetColumnWidth(i, 20);
            }
            row = 2;
            foreach (var resultRow in effectivityValidationRows)
            {
                for (int i = 1; i <= resultRow.Data.Count; ++i)
                {
                    sl.SetCellValue(row, i, resultRow.Data[i - 1]);

                    if (i == 1)
                    {
                        if (resultRow.Data[i - 1].Equals("Success", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesGreen);
                        }
                        else if (resultRow.Data[i - 1].Equals("Exclusion", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesGrey);
                        }
                        else if (resultRow.Data[i - 1].Equals("Failure", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesRed);
                        }
                    }
                    else
                    {
                        sl.SetCellStyle(row, i, styleNotes);
                    }
                }
                row++;
            }
            tbl = sl.CreateTable(1, 1, effectivityValidationRows.Count + 1, headers.Count);
            tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
            sl.InsertTable(tbl);
        }

        /// <summary>
        /// Fill Report sheet which will be used by business to validate migration rules and data
        /// </summary>
        /// <param name="sl"></param>
        /// <param name="styleNotes"></param>
        /// <param name="styleNotesGreen"></param>
        /// <param name="styleNotesRed"></param>
        /// <param name="styleNotesGrey"></param>
        /// <param name="notesRows">actual notes data rows</param>
        /// <param name="logsId"></param>
        private static void FillReportSheet(SLDocument sl, SLStyle styleNotes, SLStyle styleNotesGreen, SLStyle styleNotesRed, SLStyle styleNotesGrey, ConcurrentBag<NotesRow> notesRows, int logsId)
        {
            TraceFile.WriteLine("FillReportSheet");
            Logs logs = HelperClass.ReportLogs[logsId];
            List<string> headers;
            int row;
            SLTable tbl;
            bool reasonSet = false;
            int reasonIndex = 0;
            //selecting report worksheet
            sl.SelectWorksheet("2-Report");

            headers = logs.GetNotesHeaders();
            for (int i = 1; i <= headers.Count; ++i)
            {
                sl.SetCellValue(1, i, headers[i - 1]);
                //sl.SetCellValue(1, i, "testCrash");

                if (headers[i - 1].Equals("Status Reason", StringComparison.OrdinalIgnoreCase) && !reasonSet)
                {
                    sl.SetColumnWidth(i, 60);

                    reasonSet = true;
                    reasonIndex = i;
                }
                else
                {
                    sl.SetColumnWidth(i, 20);
                }

            }
            SLStyle customStyle = null;
            row = 2;
            foreach (var resultRow in notesRows)
            {
                for (int i = 1; i <= resultRow.Data.Count; ++i)
                {
                    sl.SetCellValue(row, i, resultRow.Data[i - 1]);
                    //sl.SetCellValue(row, i, "testCrash");

                    if (i == 1)
                    {
                        if (resultRow.Data[i - 1].Equals("Success", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesGreen);
                            customStyle = styleNotes;
                        }
                        else if (resultRow.Data[i - 1].Equals("Exclusion", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesGrey);
                            customStyle = styleNotesGrey;
                        }
                        else if (resultRow.Data[i - 1].Equals("Failure", StringComparison.OrdinalIgnoreCase))
                        {
                            sl.SetCellStyle(row, i, styleNotesRed);
                            customStyle = styleNotesRed;
                        }
                    }
                    else if (i != reasonIndex && resultRow.ErrorFields.Contains(headers[i - 1], StringComparer.OrdinalIgnoreCase))
                    {
                        sl.SetCellStyle(row, i, customStyle);
                    }
                    else
                    {
                        sl.SetCellStyle(row, i, styleNotes);
                    }
                }
                row++;
            }
            //tbl = sl.CreateTable(1, 1, notesRows.Count + 1, headers.Count - 1);
            tbl = sl.CreateTable(1, 1, notesRows.Count + 1, headers.Count);
            //tbl = sl.CreateTable("A1", "L100");
            tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
            sl.InsertTable(tbl);
        }

        //private static void FillSharePointSheet(SLDocument sl, SLStyle styleSharePoint)
        //{
        //    List<string> headers;
        //    List<List<string>> sharePointRows;
        //    int row;
        //    SLTable tbl;

        //    sl.SelectWorksheet("3-SharePoint");

        //    headers = Logs.Instance.GetSharePointHeaders();
        //    for (int i = 1; i <= headers.Count; ++i)
        //    {
        //        sl.SetCellValue(1, i, headers[i - 1]);
        //        sl.SetColumnWidth(i, 20);
        //    }

        //    sharePointRows = Logs.Instance.GetSharePointRows();
        //    row = 2;
        //    foreach (var resultRow in sharePointRows)
        //    {
        //        for (int i = 1; i <= resultRow.Count; ++i)
        //        {
        //            sl.SetCellValue(row, i, resultRow[i - 1]);
        //            sl.SetCellStyle(row, i, styleSharePoint);
        //        }
        //        row++;
        //    }
        //    tbl = sl.CreateTable(1, 1, sharePointRows.Count + 1, headers.Count);
        //    tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
        //    sl.InsertTable(tbl);
        //}

        private static void FillSharePointSheet(SLDocument sl, SLStyle styleSharePoint, ConcurrentBag<List<string>> sharePointRows, int logsId)
        {
            TraceFile.WriteLine("FillSharePointSheet");
            Logs logs = HelperClass.ReportLogs[logsId];
            List<string> headers;
            int row;
            SLTable tbl;

            sl.SelectWorksheet("3-SharePoint");

            headers = logs.GetSharePointHeaders();
            for (int i = 1; i <= headers.Count; ++i)
            {
                sl.SetCellValue(1, i, headers[i - 1]);
                sl.SetColumnWidth(i, 20);
            }

            row = 2;
            foreach (var resultRow in sharePointRows)
            {
                for (int i = 1; i <= resultRow.Count; ++i)
                {
                    sl.SetCellValue(row, i, resultRow[i - 1]);
                    sl.SetCellStyle(row, i, styleSharePoint);
                }
                row++;
            }
            tbl = sl.CreateTable(1, 1, sharePointRows.Count + 1, headers.Count);
            tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
            sl.InsertTable(tbl);
        }

    

        private static void FillSummarySheet(string title, SLDocument sl, int logsId)
        {
            int totalRecords, exclusions, successes, failures;
            Logs logs = HelperClass.ReportLogs[logsId];
            logs.PrintGeneralStats(out totalRecords, out exclusions, out successes, out failures);

            sl.SelectWorksheet("1-Summary");
            sl.SetCellValue("C1", title);
            sl.SetCellValue("C3", totalRecords);
            sl.SetCellValue("C4", exclusions);
            sl.SetCellValue("C5", successes);
            sl.SetCellValue("C6", failures);
            sl.AutoFitColumn("C");        

        }

        private static void SetProperties(NotesDatabases notesDatabase, ref string fileName, ref string title, string folder)
        {
            string unixTime = LaunchConfiguration.Default.APPEND_TIME_TO_REPORT_NAME ? "_" + HelperClass.UnixTimeToString() : string.Empty;
            switch (notesDatabase)
            {
                case NotesDatabases.THDTorontoLibrary:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.THDTorontoLibraryReportName,
                                              String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.THDTorontoLibraryReportName;
                    break;
                case NotesDatabases.THDLibrary:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.THDLibraryReportName,
                                              String.Format("{0:MM-dd-yyyy}{1}_{2}", DateTime.Now, unixTime, folder));
                    title = DataLoader.Default.THDLibraryReportName;
                    break;
                case NotesDatabases.WorkingGroups:                    
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.WorkingGroupsReportName,
                                              String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.WorkingGroupsReportName;
                    break;
                case NotesDatabases.SBCRJCoverLetter:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.SB_CRJ_CoverLetterReportName,
                          String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.SB_CRJ_CoverLetterReportName;
                    break;
                case NotesDatabases.SBCRJPDFDocument:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.SB_CRJ_PDF_DocumentReportName,
                          String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.SB_CRJ_PDF_DocumentReportName;
                    break;
                case NotesDatabases.SBCRJServiceBulletin:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.SB_CRJ_ServiceBulletinReportName,
                          String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.SB_CRJ_ServiceBulletinReportName;
                    break;
                case NotesDatabases.TISBDASH:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.SB_DashReportName,
                          String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.SB_DashReportName;
                    break;
                case NotesDatabases.TITechManualStatus:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.TiTechManualStatusReportName,
                          String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.TiTechManualStatusReportName;
                    break;
                case NotesDatabases.CSeriesSharePoint2010:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.SP2010ReportName,
                          String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.SP2010ReportName;
                    break;
                case NotesDatabases.WorkingGroupsPresentationsMeetingMinutes:
                    fileName = string.Format("{0}{1} {2}.xlsx", DataLoader.Default.ReportsPath, DataLoader.Default.WorkingGroupsPresentationsMeetingMinutesReportName,
                                              String.Format("{0:MM-dd-yyyy}{1}", DateTime.Now, unixTime));
                    title = DataLoader.Default.WorkingGroupsPresentationsMeetingMinutesReportName;
                    break;
                default:
                    break;
            }
        }

        //private static void CreateSheets(SLDocument sl)
        //{
        //    sl.AddWorksheet("General");
        //    sl.AddWorksheet("Success");
        //    sl.AddWorksheet("Failure");
        //    sl.AddWorksheet("Filtering");
        //    sl.AddWorksheet("Transformation");
        //    sl.AddWorksheet("Mandatory");
        //    sl.AddWorksheet("Fields Lengths");
        //    sl.AddWorksheet("SharePoint");
        //    sl.SelectWorksheet("General");
        //    sl.DeleteWorksheet("Sheet1");
        //}

        private static void SetStyles(out SLStyle styleGeneral, out SLStyle styleTitle, out SLStyle styleNotes, out SLStyle styleNotesGreen,
            out SLStyle styleNotesRed, out SLStyle styleNotesGrey, SLDocument sl)
        {
            styleGeneral = sl.CreateStyle();
            styleTitle = sl.CreateStyle();
            styleNotes = sl.CreateStyle();
            styleNotesGreen = sl.CreateStyle();
            styleNotesRed = sl.CreateStyle();
            styleNotesGrey = sl.CreateStyle();

            styleGeneral.SetFont("Arial", 14);
            styleGeneral.Border.LeftBorder.BorderStyle = BorderStyleValues.Thick;
            styleGeneral.Border.RightBorder.BorderStyle = BorderStyleValues.Thick;
            styleGeneral.Border.TopBorder.BorderStyle = BorderStyleValues.Thick;
            styleGeneral.Border.BottomBorder.BorderStyle = BorderStyleValues.Thick;
            styleGeneral.SetWrapText(true);
            styleTitle.SetFont("Arial", 18);

            styleNotes.SetWrapText(true);
            styleNotes.Alignment.Horizontal = HorizontalAlignmentValues.Left;

            styleNotesGreen.SetWrapText(true);
            styleNotesGreen.Alignment.Horizontal = HorizontalAlignmentValues.Left;
            styleNotesGreen.Fill.SetPatternType(PatternValues.Solid);
            styleNotesGreen.Fill.SetPatternForegroundColor(System.Drawing.Color.Green);

            styleNotesRed.SetWrapText(true);
            styleNotesRed.Alignment.Horizontal = HorizontalAlignmentValues.Left;
            styleNotesRed.Fill.SetPatternType(PatternValues.Solid);
            styleNotesRed.Fill.SetPatternForegroundColor(System.Drawing.Color.Salmon);

            styleNotesGrey.SetWrapText(true);
            styleNotesGrey.Alignment.Horizontal = HorizontalAlignmentValues.Left;
            styleNotesGrey.Fill.SetPatternType(PatternValues.Solid);
            styleNotesGrey.Fill.SetPatternForegroundColor(System.Drawing.Color.DarkGray);
        }
        //public static void CreateExcelFile(string fileName)
        //{
        //    SLDocument sl = new SLDocument();

        //    // set a boolean at "A1"
        //    sl.SetCellValue("A1", true);

        //    // set at row 2, columns 1 through 20, a value that's equal to the column index
        //    for (int i = 1; i <= 20; ++i) sl.SetCellValue(2, i, i);

        //    // set the value of PI
        //    sl.SetCellValue("B3", 3.14159);

        //    // set the value of PI at row 4, column 2 (or "B4") in string form.
        //    // use this when you already have numeric data in string form and don't
        //    // want to parse it to a double or float variable type
        //    // and then set it as a value.
        //    // Note that "3,14159" is invalid. Excel (or Open XML) stores numerals in
        //    // invariant culture mode. Frankly, even "1,234,567.89" is invalid because
        //    // of the comma. If you can assign it in code, then it's fine, like so:
        //    // double fTemp = 1234567.89;
        //    sl.SetCellValueNumeric(4, 2, "3.14159");

        //    // normal string data
        //    sl.SetCellValue("C6", "This is at C6!");

        //    // typical XML-invalid characters are taken care of,
        //    // in particular the & and < and >
        //    sl.SetCellValue("I6", "Dinner & Dance costs < $10");

        //    // this sets a cell formula
        //    // Note that if you want to set a string that starts with the equal sign,
        //    // but is not a formula, prepend a single quote.
        //    // For example, "'==" will display 2 equal signs
        //    sl.SetCellValue(7, 3, "=SUM(A2:T2)");

        //    // if you need cell references and cell ranges *really* badly, consider the SLConvert class.
        //    sl.SetCellValue(SLConvert.ToCellReference(7, 4), string.Format("=SUM({0})", SLConvert.ToCellRange(2, 1, 2, 20)));

        //    // dates need the format code to be displayed as the typical date.
        //    // Otherwise it just looks like a floating point number.
        //    sl.SetCellValue("C8", new DateTime(3141, 5, 9));
        //    SLStyle style = sl.CreateStyle();
        //    style.FormatCode = "d-mmm-yyyy";
        //    sl.SetCellStyle("C8", style);

        //    sl.SetCellValue(8, 6, "I predict this to be a significant date. Why, I do not know...");

        //    sl.SetCellValue(9, 4, 456.123789);
        //    // we don't have to create a new SLStyle because
        //    // we only used the FormatCode property
        //    style.FormatCode = "0.000%";
        //    sl.SetCellStyle(9, 4, style);

        //    sl.SetCellValue(9, 6, "Perhaps a phenomenal growth in something?");

        //    sl.SaveAs(fileName);

        //    TraceFile.WriteLine("End of program");
        //    //Console.ReadLine();
        //}

        //public static void LoadExcelFile(string fileName)
        //{
        //    //SLDocument sl = new SLDocument(fileName);
        //    using (SLDocument sl = new SLDocument(fileName))
        //    {
        //        SLWorksheetStatistics stats = sl.GetWorksheetStatistics();
        //        int startCol = stats.StartColumnIndex;
        //        int startRow = stats.StartRowIndex;
        //        int endCol = stats.EndColumnIndex;
        //        int endRow = stats.EndRowIndex;

        //        //TraceFile.WriteLine("StartColumnIndex: {0}", iStartColumnIndex);
        //        int title1Row = DataLoader.Default.DataExtractTitle1Row;
        //        int title2Row = DataLoader.Default.DataExtractTitle2Row;
        //        int dateRow = DataLoader.Default.DataExtractDateRow;
        //        int headerRow = DataLoader.Default.DataExtractHeaderRow;
        //        int contentRow = headerRow + 1;

        //        TraceFile.WriteLine("Title1: {0}", sl.GetCellValueAsString(title1Row, startCol));
        //        TraceFile.WriteLine("Title2: {0}", sl.GetCellValueAsString(title2Row, startCol));
        //        TraceFile.WriteLine("Date: {0}", String.Format("{0:yyyy-MM-dd}", sl.GetCellValueAsDateTime(dateRow, startCol)));

        //        for (int col = startCol; col <= endCol; col++)
        //        {
        //            TraceFile.WriteLine("Header {0}, {1}", col, sl.GetCellValueAsString(headerRow, col));
        //        }

        //        for (int row = contentRow; row <= endRow; row++)
        //        {
        //            for (int col = startCol; col <= endCol; col++)
        //            {
        //                TraceFile.WriteLine("Row {0}, Col {1}: {2}", row, col, sl.GetCellValueAsString(row, col));
        //            }
        //        }

        //    }
        //    //sl.CloseWithoutSaving();
        //}
        //private static void FillRuleSheet(SLDocument sl, SLStyle styleNotes, ExcelReportSheets excelReportSheet)
        //{
        //    string sheetName = null;
        //    string ruleDetails = null;

        //    int row;
        //    SLTable tbl;
        //    ConcurrentBag<Log> logList = Logs.Instance.LogList;

        //    switch (excelReportSheet)
        //    {
        //        case ExcelReportSheets.TransformationRules:
        //            sheetName = "Transformation";
        //            ruleDetails = "Rule Details";                    
        //            break;
        //        case ExcelReportSheets.MandatoryFieldRules:
        //            sheetName = "Mandatory";
        //            ruleDetails = "Tested Field";
        //            break;
        //        case ExcelReportSheets.FieldsLengthRules:
        //            sheetName = "Fields Lengths";
        //            ruleDetails = "Tested Field";
        //            break;
        //        default:
        //            break;
        //    }
        //    sl.SelectWorksheet(sheetName);

        //    sl.SetCellValue(1, 1, "Excel Row");
        //    sl.SetColumnWidth(1, 15);

        //    sl.SetCellValue(1, 2, "UNID");
        //    sl.SetColumnWidth(2, 20);

        //    sl.SetCellValue(1, 3, "Document Type");
        //    sl.SetColumnWidth(3, 20);

        //    sl.SetCellValue(1, 4, "Document Group");
        //    sl.SetColumnWidth(4, 20);

        //    sl.SetCellValue(1, 5, ruleDetails);
        //    sl.SetColumnWidth(5, 60);

        //    sl.SetCellValue(1, 6, "Rule Result");
        //    sl.SetColumnWidth(6, 20);


        //    sl.SetCellValue(1, 7, "Migration Status");
        //    sl.SetColumnWidth(7, 20);

        //    row = 2;
        //    foreach (var log in logList)
        //    {
        //        foreach (var rule in GetRulesResults(log, excelReportSheet))
        //        {
        //            sl.SetCellValue(row, 1, log.ExcelRow);
        //            sl.SetCellStyle(row, 1, styleNotes);

        //            sl.SetCellValue(row, 2, log.Uid);
        //            sl.SetCellStyle(row, 2, styleNotes);

        //            sl.SetCellValue(row, 3, log.DocumentType);
        //            sl.SetCellStyle(row, 3, styleNotes);

        //            sl.SetCellValue(row, 4, log.DocumentGroup);
        //            sl.SetCellStyle(row, 4, styleNotes);

        //            sl.SetCellValue(row, 5, rule.Value);
        //            sl.SetCellStyle(row, 5, styleNotes);

        //            sl.SetCellValue(row, 6, rule.Key ? "Success" : "Failure");
        //            sl.SetCellStyle(row, 6, styleNotes);

        //            sl.SetCellValue(row, 7, log.GetResult());
        //            sl.SetCellStyle(row, 7, styleNotes);

        //            row++;
        //        }

        //    }

        //    tbl = sl.CreateTable(1, 1, row - 1, 7);
        //    tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
        //    sl.InsertTable(tbl);
        //}

        //    private static List<KeyValuePair<bool, string>> GetRulesResults(Log log, ExcelReportSheets excelReportSheet)
        //    {
        //        List<KeyValuePair<bool, string>> rulesResults = null;

        //        switch (excelReportSheet)
        //        {
        //            case ExcelReportSheets.TransformationRules:
        //                rulesResults = log.TransformationRules;
        //                break;
        //            case ExcelReportSheets.MandatoryFieldRules:
        //                rulesResults = log.MandatoryFieldsRules;
        //                break;
        //            case ExcelReportSheets.FieldsLengthRules:
        //                rulesResults = log.FieldsLengthsRules;
        //                break;
        //            default:
        //                break;
        //        }
        //        return rulesResults;
        //}

        //private static void FillFilteringSheet(SLDocument sl, SLStyle styleNotes)
        //{
        //    int row;
        //    SLTable tbl;
        //    ConcurrentBag<Log> logList = Logs.Instance.LogList;

        //    sl.SelectWorksheet("Filtering");

        //    sl.SetCellValue(1, 1, "Excel Row");
        //    sl.SetColumnWidth(1, 15);

        //    sl.SetCellValue(1, 2, "UNID");
        //    sl.SetColumnWidth(2, 20);

        //    sl.SetCellValue(1, 3, "Rule Details");
        //    sl.SetColumnWidth(3, 60);

        //    sl.SetCellValue(1, 4, "Rule Result");
        //    sl.SetColumnWidth(4, 20);

        //    sl.SetCellValue(1, 5, "Migration Status");
        //    sl.SetColumnWidth(5, 20);

        //    row = 2;
        //    foreach (var log in logList)
        //    {
        //        foreach (var rule in log.FilteringRules)
        //        {
        //            sl.SetCellValue(row, 1, log.ExcelRow);
        //            sl.SetCellStyle(row, 1, styleNotes);

        //            sl.SetCellValue(row, 2, log.Uid);
        //            sl.SetCellStyle(row, 2, styleNotes);

        //            sl.SetCellValue(row, 3, rule.Value);
        //            sl.SetCellStyle(row, 3, styleNotes);

        //            sl.SetCellValue(row, 4, rule.Key ? "Success" : "Failure");
        //            sl.SetCellStyle(row, 4, styleNotes);

        //            sl.SetCellValue(row, 5, log.GetResult());
        //            sl.SetCellStyle(row, 5, styleNotes);

        //            row++;
        //        }

        //    }

        //    tbl = sl.CreateTable(1, 1, row - 1, 5);
        //    tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
        //    sl.InsertTable(tbl);
        //}

        //private static void FillNotesSheet(SLDocument sl, SLStyle styleNotes, bool success)
        //{
        //    List<string> headers;
        //    List<List<string>> notesRows;
        //    int row;
        //    SLTable tbl;

        //    if (success)
        //    {
        //        sl.SelectWorksheet("Success");
        //    }
        //    else
        //    {
        //        sl.SelectWorksheet("Failure");
        //    }

        //    headers = Logs.Instance.GetNotesHeaders();
        //    for (int i = 1; i <= headers.Count; ++i)
        //    {
        //        sl.SetCellValue(1, i, headers[i - 1]);
        //        //sl.SetCellStyle(1, i, styleNotes);
        //        sl.SetColumnWidth(i, 20);
        //    }

        //    notesRows = Logs.Instance.GetNotesRows(success);
        //    row = 2;
        //    foreach (var resultRow in notesRows)
        //    {
        //        for (int i = 1; i <= resultRow.Count; ++i)
        //        {
        //            sl.SetCellValue(row, i, resultRow[i - 1]);
        //            sl.SetCellStyle(row, i, styleNotes);
        //        }
        //        row++;
        //    }
        //    tbl = sl.CreateTable(1, 1, notesRows.Count + 1, headers.Count);
        //    tbl.SetTableStyle(SLTableStyleTypeValues.Medium9);
        //    sl.InsertTable(tbl);
        //}

        //private static void FillGeneralSheet(string title, SLDocument sl, SLStyle styleGeneral, SLStyle styleTitle)
        //{
        //    sl.SelectWorksheet("General");
        //    sl.SetCellValue("C1", title);
        //    sl.SetCellValue("A3", Logs.Instance.PrintGeneralStats());

        //    sl.SetCellStyle("C1", styleTitle);
        //    sl.SetCellStyle("A3", styleGeneral);

        //    sl.SetColumnWidth("A", 60);
        //    sl.SetColumnWidth("C", 50);
        //}
    }
}