﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    public static class ExtensionMethods
    {
        public static string ToDebugString<TKey, TValue>(this IDictionary<TKey, TValue> dictionary)
        {
            return "{" + string.Join(",", dictionary.Select(kv => kv.Key + "=" + kv.Value).ToArray()) + "}";
        }
        public static bool Contains(this string source, string toCheck, StringComparison comp)
        {
            return source != null && toCheck != null && source.IndexOf(toCheck, comp) >= 0;
        }
        public static string RemoveDiacritics(this string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return text;

            text = text.Normalize(NormalizationForm.FormD);
            var chars = (text.Replace('æ', 'a').Replace('œ', 'o')).Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark).ToArray();
            chars = (text.Replace('æ', 'a').Replace('œ', 'o')).Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark).ToArray();
            return new string(chars).Normalize(NormalizationForm.FormC);
        }
        public static string RunCharacterCheckASCII(string s)
        {
            string str = s;
            bool is_find = false;
            char ch;
            int ich = 0;
            try
            {
                char[] schar = str.ToCharArray();
                for (int i = 0; i < schar.Length; i++)
                {
                    ch = schar[i];
                    ich = (int)ch;
                    if (ich > 127) // not ascii or extended ascii
                    {
                        is_find = true;
                        schar[i] = '?';
                    }
                }
                if (is_find)
                    str = new string(schar);
            }
            catch (Exception ex)
            {
            }
            return str;
        }
        public static string ReturnCleanASCII(string s)
        {
            StringBuilder sb = new StringBuilder(s.Length);
            foreach (char c in s.ToCharArray())
            {
                if ((int)c > 127) // you probably don't want 127 either
                    continue;
                if ((int)c < 32)  // I bet you don't want control characters 
                    continue;
                //if (c == ',')
                //    continue;
                //if (c == '"')
                //    continue;
                sb.Append(c);
            }
            return sb.ToString();
        }
        public static string Sanitize(this string s)
        {
            string result = ReturnCleanASCII(s); //Encoding.ASCII.GetString(Encoding.ASCII.GetBytes(s));

            if (result != s)
            {
                TraceFile.WriteLine("Sanitize - Before / After: '{0}' / '{1}'", s, result);
            }
            return result;
        }
        public static bool EndsWith(this string text, string[] values, StringComparison comparisonType)
        {
            bool result = false;
            foreach (var value in values)
            {
                if (text.EndsWith(value, comparisonType))
                {
                    result = true;
                    break;
                }
            }
            return result;
        }
        public static bool Contains(this string text, string[] values)
        {
            bool result = false;
            foreach (var value in values)
            {
                string[] innerValues = value.Split(',');
                foreach (var innerValue in innerValues)
                {
                    if (text.Contains(innerValue.Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }
        public static bool EndsWith(this string text, string[] values, StringComparison comparisonType, out string endsWith)
        {
            endsWith = null;
            bool result = false;
            foreach (var value in values)
            {
                if (text.EndsWith(value, comparisonType))
                {
                    endsWith = value;
                    result = true;
                    break;
                }
            }
            return result;
        }
        public static string TrimEnd(this string text, string[] values, StringComparison comparisonType)
        {
            StringBuilder sb = new StringBuilder(text);
            string endsWith;
            while (sb.ToString().EndsWith(values, comparisonType, out endsWith))
            {
                sb.Remove(sb.Length - endsWith.Length, endsWith.Length);
            }
            return sb.ToString();
        }
        public static string TrimStart(this string text, string trimText)
        {
            StringBuilder sb = new StringBuilder(text);
            if (sb.ToString().StartsWith(trimText, StringComparison.OrdinalIgnoreCase))
            {
                sb.Remove(0, trimText.Length);
            }
            return sb.ToString();
        }
        public static bool NotStartsWith(this string text, string value)
        {
            return !text.StartsWith(value, StringComparison.OrdinalIgnoreCase);
        }
        public static bool NotContains(this string text, string value)
        {
            return !text.Contains(value, StringComparison.OrdinalIgnoreCase);
        }
        static public string ReplaceIgnoreCase(this string str, string from, string to)
        {
            str = Regex.Replace(str, from, to, RegexOptions.IgnoreCase);
            return str;
        }
        //public static string GetValidSharePointFolderName(this string folderName)
        //{
        //    //TraceFile.WriteLine("Validating FolderName '{0}'", folderName);
        //    StringBuilder sb = new StringBuilder();
        //    string result;
        //    //result = Regex.Replace(folderName, "[^A-Za-z0-9_. ]+", "-", RegexOptions.Compiled).Trim('.').TrimStart('_');
        //   // result = Regex.Replace(folderName, "[~#%&*{}\\\\:<>?/|\"]+", "-", RegexOptions.Compiled).Trim('.').TrimStart('_');
        //   // result = Regex.Replace(folderName, "[~#%&*{}\\\\:<>?/|\"]+", Constants.SharePointInvalidFolderCharsReplacement, RegexOptions.Compiled).Trim('.').TrimStart('_');
        //    result = Regex.Replace(folderName, @"[~#%&*{}\\:<>?/|""]+", Constants.SharePointInvalidFolderCharsReplacement, RegexOptions.Compiled).Trim('.').TrimStart('_');
        //    result = Regex.Replace(result, "[.]{2,}", ".", RegexOptions.Compiled);
        //    result = Regex.Replace(result, "\\s+", " ", RegexOptions.Compiled);
        //    //while (Regex.IsMatch(result, "(-{2,})|(-\\s+-)", RegexOptions.Compiled))
        //    //{
        //    //  result = Regex.Replace(result, "(-{2,})|(-\\s+-)", "-", RegexOptions.Compiled);
        //    //}

        //    sb.Append(result);
        //    sb.Replace("_vti_", "-vti-");
        //    //sb.repl
        //    if (!result.Equals(folderName))
        //    {
        //        TraceFile.WriteLine("Name \n\t'{0}' \nwas changed to\n \t'{1}'", folderName, result);
        //    }
        //    return sb.ToString();
        //}
        public static string GetValidSharePointFileName(this string fileName)
        {
            StringBuilder sb = new StringBuilder();
            string result;
            result = Regex.Replace(fileName, @"[~#%&*{}\\:<>?/|""]+", Constants.SharePointInvalidFileCharsReplacement, RegexOptions.Compiled);
            result = Regex.Replace(result, "[.]{2,}", ".", RegexOptions.Compiled);
            result = Regex.Replace(result, "\\s+", " ", RegexOptions.Compiled);

            sb.Append(result.TrimStart('.').TrimStart('_').TrimEnd(Constants.SharePointFileInvalidEndingsReplace, StringComparison.OrdinalIgnoreCase).Trim());
            
            if (!result.Equals(fileName))
            {
                TraceFile.WriteLine("File Name \n\t'{0}' \nwas changed to\n \t'{1}'", fileName, sb.ToString());
            }
            return sb.ToString();
        }
        public static string AllWhiteSpacesToSpaces(this string text)
        {
            return Regex.Replace(text, @"\s+", " ", RegexOptions.Compiled);
        }        
        public static string GetValidSharePointFolderName(this string fileName)
        {
            StringBuilder sb = new StringBuilder();
            string result;
            result = Regex.Replace(fileName, @"[~#%*{}:<>?""]+", Constants.SharePointInvalidFileCharsReplacement, RegexOptions.Compiled);
            result = Regex.Replace(result, @"[\\|/]+", Constants.SharePointInvalidFolderCharsReplacement, RegexOptions.Compiled);
            result = Regex.Replace(result, "[.]{2,}", ".", RegexOptions.Compiled);
            result = Regex.Replace(result, "\\s+", " ", RegexOptions.Compiled);

            sb.Append(result.TrimStart('.').TrimStart('_').TrimEnd(Constants.SharePointFileInvalidEndingsReplace, StringComparison.OrdinalIgnoreCase).Trim());

            sb.Replace("_vti_", "-vti-");
            sb.Replace("&", "and");

            if (!result.Equals(fileName))
            {
                TraceFile.WriteLine("Folder Name \n\t'{0}' \nwas changed to\n \t'{1}'", fileName, sb.ToString());
            }
            return sb.ToString();
        }

        //public static bool IsValidSharePointFileOrFolderName(this string fileName)
        //{
        //    bool isValid = true;
        //    if (Regex.IsMatch(fileName, @"[~#%&*{}\\:<>?/|""]+", RegexOptions.Compiled) ||
        //        Regex.IsMatch(fileName, "[.]{2,}", RegexOptions.Compiled) ||
        //        fileName.StartsWith(".", StringComparison.OrdinalIgnoreCase) ||
        //        fileName.StartsWith("_", StringComparison.OrdinalIgnoreCase) ||
        //        fileName.EndsWith(Constants.SharePointFileInvalidEndings, StringComparison.OrdinalIgnoreCase))
        //    {
        //        isValid = false;
        //    }

        //    if (!isValid)
        //    {
        //        TraceFile.WriteLine("File Name '{0}'is invalid", fileName);
        //    }
        //    return isValid;
        //}
        public static bool IsValidSharePointFileName(this string fileName)
        {
            bool isValid = true;
            if (Regex.IsMatch(fileName, @"[~#%&*{}\\:<>?/|""]+", RegexOptions.Compiled) ||
                Regex.IsMatch(fileName, "[.]{2,}", RegexOptions.Compiled) ||
                fileName.StartsWith(".", StringComparison.OrdinalIgnoreCase) ||
                fileName.StartsWith("_", StringComparison.OrdinalIgnoreCase) ||
                fileName.EndsWith(Constants.SharePointFileInvalidEndingsCheck, StringComparison.OrdinalIgnoreCase))
            {
                isValid = false;
            }

            if (!isValid)
            {
                TraceFile.WriteLine("File Name '{0}'is invalid", fileName);
            }
            return isValid;
        }
        public static string Print(this string[][] array)
        {
            StringBuilder builder = new StringBuilder();
            foreach (string[] mapping in array)
            {
                if (builder.Length == 0)
                {
                    builder.AppendFormat("{{\n    ({0} | {1})", mapping[0], mapping[1]);
                }
                else
                {
                    builder.AppendFormat("\n    ({0} | {1})", mapping[0], mapping[1]);
                }
            }
            builder.Append("   } ");
            return builder.ToString();
        }
        public static bool TryGetFileByServerRelativeUrl(this Web web, string serverRelativeUrl, out File file)
        {
            var ctx = web.Context;
            try
            {
                file = web.GetFileByServerRelativeUrl(serverRelativeUrl);
                ctx.Load(file);
                ctx.ExecuteQuery();
                return true;
            }
            catch (Exception e)
            {
                //TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                file = null;
                return false;
            }
            //catch (ServerException ex)
            //{
            //    if (ex.ServerErrorTypeName == "System.IO.FileNotFoundException")
            //    {
            //        file = null;
            //        return false;
            //    }
            //    throw;
            //}
        }
        public static bool TryGetFolderByServerRelativeUrl(this Web web, string serverRelativeUrl, out Folder folder)
        {
            var ctx = web.Context;
            try
            {
                folder = web.GetFolderByServerRelativeUrl(serverRelativeUrl);
                ctx.Load(folder);
                ctx.ExecuteQuery();
                return true;
            }
            catch (Exception e)
            {
                //TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                folder = null;
                return false;
            }
            //catch (ServerException ex)
            //{
            //    if (ex.ServerErrorTypeName == "System.IO.FileNotFoundException")
            //    {
            //        Folder = null;
            //        return false;
            //    }
            //    throw;
            //}
        }
        public static IEnumerable<IEnumerable<T>> Split<T>(this IEnumerable<T> list, int parts)
        {
            return list.Select((item, index) => new { index, item })
                       .GroupBy(x => x.index % parts)
                       .Select(x => x.Select(y => y.item));
        }

    }
}
