﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using BCA.DocumentMigration.SpDataLoader.SharepointData;
using Microsoft.SharePoint.Client;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using BCA.DocumentMigration.SpDataLoader.NotesData;
using System.Configuration;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    public static class HelperClass
    {
        //public static Dictionary<string, string> DocTypeToGroupMap                 = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        //public static Dictionary<string, string> CategoriesToDocTypeMap            = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public static ConcurrentDictionary<string, string> UnidToGuidMapping = new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public static Dictionary<string, string> FilteringRulesReverseMapping = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public static Dictionary<string, string> SharePointNormalizationMapping = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public static Dictionary<string, string> SharepointForcedInternalNameMappings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public static Dictionary<string, string> ThdLibraryAttachmentPaths = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public static List<SharePointAttribute> SharepointAttributes = new List<SharePointAttribute>();
        public static string[] SharepointAttributesNames = null;
        public static List<DocTypeAttribute> DocTypeAttributes = new List<DocTypeAttribute>();
        public static List<String> FieldsWithDate = new List<string>();
        public static List<String> ServiceBulletinWhitelist = new List<string>();
        public static List<String> AtaBlacklist = new List<string>();
        public static List<String> SharePointListsToDelete = new List<string>();
        //public static List<String> LookUpListsValueFields                            = new List<string>();
        public static Dictionary<string, string> LookUpFieldValueTitleMapping = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public static List<int> EffectivityExceptionsList = new List<int>();
        public static HashSet<string> UsedNotesFields = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static HashSet<string> BeginsWithSharePointFields = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static ConcurrentBag<KeyValuePair<string, string>> SharepointMigrationSkippedDocumentSets =
            new ConcurrentBag<KeyValuePair<string, string>>();
        public static ConcurrentBag<KeyValuePair<string, string>> SharepointMigrationFailedDocumentSetCreations =
            new ConcurrentBag<KeyValuePair<string, string>>();
        public static ConcurrentBag<KeyValuePair<string, string>> SharepointMigrationFailedPropertiesUpdate =
            new ConcurrentBag<KeyValuePair<string, string>>();
        public static ConcurrentBag<KeyValuePair<string, string>> SharepointMigrationSkippedFiles =
            new ConcurrentBag<KeyValuePair<string, string>>();
        public static ConcurrentBag<KeyValuePair<string, string>> SharepointMigrationFailedFileUploads =
            new ConcurrentBag<KeyValuePair<string, string>>();

        // *************

        public static ConcurrentDictionary<string, ContentTypeId> ContentTypeIds = new ConcurrentDictionary<string, ContentTypeId>(StringComparer.OrdinalIgnoreCase);
        public static ConcurrentDictionary<string, int> CurrentLibraryDuplicateNames = new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        public static Dictionary<string, int[]> ModelsEffectivities = new Dictionary<string, int[]>();
        public static Dictionary<string, string[]> ModelSubmodelMapping = new Dictionary<string, string[]>();
        public static ConcurrentDictionary<int, Logs> ReportLogs = new ConcurrentDictionary<int, Logs>();
        public static Dictionary<string, Dictionary<int, string>> LookUpValuesReference = new Dictionary<string, Dictionary<int, string>>(StringComparer.OrdinalIgnoreCase);
        public static Dictionary<string, string[]> ChoiceValuesReference = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
        public static Dictionary<int, string> MainAtaFamilyMapping = new Dictionary<int, string>();
        public static int logsCounter = 0;
        public static volatile bool checkedMandatoryFieldForCurrentExtract = false;

        public static readonly Object thisLock = new Object();

        internal static void AdjustEffectivityEmptyModelsTHD(string effectivity, string emptyEffectivityModels, Dictionary<string, string> attributes)
        {
            StringBuilder tempEffectivity = new StringBuilder(effectivity);
            StringBuilder tempModel = attributes.ContainsKey(DataLoader.Default.SharepointModelNumberField) ?
                new StringBuilder(attributes[DataLoader.Default.SharepointModelNumberField]) : null;
            StringBuilder tempSubModel = attributes.ContainsKey(DataLoader.Default.SharepointSubModelNumberField) ?
                new StringBuilder(attributes[DataLoader.Default.SharepointSubModelNumberField]) : null;
            string aircraftFamily = attributes.ContainsKey(DataLoader.Default.SharePointAircrafFamilyField) ?
                attributes[DataLoader.Default.SharePointAircrafFamilyField] : null;

            foreach (var model in emptyEffectivityModels.Split('\n'))
            {
                if (tempEffectivity != null && aircraftFamily != null)
                {
                    tempEffectivity.Replace(string.Format("||{0}::{1}::", aircraftFamily.Trim(), model.Trim()), "");
                    tempEffectivity.Replace(string.Format("{0}::{1}::||", aircraftFamily.Trim(), model.Trim()), "");
                }
                if (tempModel != null)
                {
                    tempModel.Replace(string.Format("{0}{1}", DataLoader.Default.MultiLookupSeparator, model.Trim()), "");
                    tempModel.Replace(string.Format("{0}{1}", model.Trim(), DataLoader.Default.MultiLookupSeparator), "");
                }
                if (tempSubModel != null && HelperClass.ModelSubmodelMapping.ContainsKey(model.Trim()))
                {
                    string[] subModels = HelperClass.ModelSubmodelMapping[model.Trim()];
                    foreach (var subModel in subModels)
                    {
                        tempSubModel.Replace(string.Format("{0}{1}", DataLoader.Default.MultiLookupSeparator, subModel.Trim()), "");
                        tempSubModel.Replace(string.Format("{0}{1}", subModel.Trim(), DataLoader.Default.MultiLookupSeparator), "");
                    }
                }
            }

            if (tempEffectivity != null)
            {
                attributes[DataLoader.Default.SharepointEffectivityField] = tempEffectivity.ToString().Trim();
            }
            if (tempModel != null)
            {
                attributes[DataLoader.Default.SharepointModelNumberField] = tempModel.ToString().Trim();
            }
            if (tempSubModel != null)
            {
                attributes[DataLoader.Default.SharepointSubModelNumberField] = tempSubModel.ToString().Trim();
            }
        }

        internal static void PrintLaunchParameters()
        {
            StringBuilder sb = new StringBuilder("\n################# Printing Launch Parameters BEGIN #################\n");
            foreach (SettingsProperty currentProperty in LaunchConfiguration.Default.Properties)
            {
                string propertyValue;
                if (currentProperty.PropertyType == typeof(System.Collections.Specialized.StringCollection))
                {
                    System.Collections.Specialized.StringCollection strs = LaunchConfiguration.Default[currentProperty.Name]
                        as System.Collections.Specialized.StringCollection;
                    propertyValue = string.Join(",", strs.Cast<string>().ToArray());
                }
                else
                {
                    propertyValue = LaunchConfiguration.Default[currentProperty.Name].ToString();
                }
                sb.AppendFormat("\t\t{0}:\t{1}\n", currentProperty.Name, propertyValue);
            }
            sb.AppendLine("################# Printing Launch Parameters END #################");
            TraceFile.WriteLine(sb.ToString(), true);
        }

        internal static void AdjustEffectivityEmptyModelsGlobal(string effectivity, string emptyEffectivityModels, Dictionary<string, string> attributes)
        {
            StringBuilder tempEffectivity = new StringBuilder(effectivity);
            string aircraftFamily = attributes.ContainsKey(DataLoader.Default.SharePointAircrafFamilyField) ?
                attributes[DataLoader.Default.SharePointAircrafFamilyField] : null;

            foreach (var model in emptyEffectivityModels.Split('\n'))
            {
                if (tempEffectivity != null && aircraftFamily != null)
                {
                    tempEffectivity.Replace(string.Format("{0}::{1}::", aircraftFamily.Trim(), model.Trim()),
                        string.Format("{0}::{1}::{2}", aircraftFamily.Trim(), model.Trim(), RulesConfiguration.Default.THD_LIBRARY_EFFECTIVITY_DEFAULT));
                }
            }

            if (tempEffectivity != null)
            {
                attributes[DataLoader.Default.SharepointEffectivityField] = tempEffectivity.ToString().Trim();
            }
        }

        //public static HashSet<string> THDTorontoLibraryUsedNotesFields             = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public static ConcurrentDictionary<string, string> SharePointToNotesFieldMap = new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        internal static void PrintSharepointMigrationExceptions()
        {
            StringBuilder sb = new StringBuilder("\n################# Printing Sharepoint Migration Exceptions BEGIN #################\n");

            PrintSharepointMigrationExceptionSection(sb, HelperClass.SharepointMigrationSkippedDocumentSets.GroupBy(kvp => kvp.Key),
                "\n\t***************** SKIPPED DOCUMENT SETS *****************\n");

            PrintSharepointMigrationExceptionSection(sb, HelperClass.SharepointMigrationFailedDocumentSetCreations.GroupBy(kvp => kvp.Key),
                "\n\t***************** FAILED DOCUMENT SET CREATIONS *****************\n");

            PrintSharepointMigrationExceptionSection(sb, HelperClass.SharepointMigrationFailedPropertiesUpdate.GroupBy(kvp => kvp.Key),
                "\n\t***************** FAILED DOCUMENT SET PROPERTIES UPDATES *****************\n");

            PrintSharepointMigrationExceptionSection(sb, HelperClass.SharepointMigrationSkippedFiles.GroupBy(kvp => kvp.Key),
                "\n\t***************** SKIPPED FILES *****************\n");

            PrintSharepointMigrationExceptionSection(sb, HelperClass.SharepointMigrationFailedFileUploads.GroupBy(kvp => kvp.Key),
                "\n\t***************** FAILED FILE UPLOADS *****************\n");

            sb.AppendLine("\n################# Printing Sharepoint Migration Exceptions END #################");

            TraceFile.WriteLine(sb.ToString(), true);

            System.IO.File.WriteAllText(string.Format("{0}Sharepoint_Migration_Exceptions_{1}.txt", DataLoader.Default.LogsPath, DateTime.Now.ToString("yyyyMMddHHmmss")), sb.ToString());
        }

        private static void PrintSharepointMigrationExceptionSection(StringBuilder sb, IEnumerable<IGrouping<string, KeyValuePair<string, string>>> groups, string title)
        {
            sb.Append(title);
            foreach (var group in groups)
            {
                sb.AppendFormat("\n\t\t{0} ({1} {2})", group.Key, group.Count(), group.Count() == 1 ? "entry" : "entries");
                foreach (var keyValuePair in group)
                {
                    sb.AppendFormat("\n\t\t\t{0}", keyValuePair.Value);
                }
                sb.AppendLine();
            }
        }

        internal static string GetAlphabetIncrement(int index)
        {
            string alphabetSequence = string.Empty;

            while (index > 0)
            {
                alphabetSequence = char.ConvertFromUtf32(64 + (index % Constants.AlphabetSize)) + alphabetSequence;
                index /= Constants.AlphabetSize;
            }

            return alphabetSequence;
        }

        public static List<SharePointContentType> ContentTypes = new List<SharePointContentType>();

        public static bool NullOrEmpty(string s)
        {
            return s == null || s.Trim().Equals(string.Empty);
        }

        /// <summary>
        /// Converts CSV file to Dictionary object
        /// </summary>
        /// <param name="file">CSV file</param>
        /// <param name="separator">tab delimited</param>
        /// <param name="map">key value dictioinary</param>
        public static void CsvToDictionary(string file, string separator, Dictionary<string, string> map)
        {
            using (TextFieldParser parser = new TextFieldParser(file))
            {
                parser.Delimiters = new string[] { separator };
                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    if (fields != null && fields.Length == 2)
                    {
                        map.Add(fields[0], fields[1]);
                    }
                }
            }
        }

        /// <summary>
        /// Converts csv file to key value(arrary) dictionary
        /// </summary>
        /// <param name="file">csv file</param>
        /// <param name="separator">tab or any toher delimiter</param>
        /// <param name="map">dictionary (key, array of value)</param>
        public static void CsvToDictionary(string file, string separator, Dictionary<string, string[]> map)
        {
            using (TextFieldParser parser = new TextFieldParser(file))
            {
                parser.Delimiters = new string[] { separator };
                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    if (fields != null)
                    {
                        map.Add(fields[0], fields.Skip(1).ToArray());
                    }
                }
            }
        }
        public static string[][] CsvTArrayOfArray(string file, string separator)
        {
            List<string[]> arrayOfArray = new List<string[]>();
            using (TextFieldParser parser = new TextFieldParser(file))
            {
                parser.Delimiters = new string[] { separator };
                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    arrayOfArray.Add(fields);
                }
            }
            return arrayOfArray.ToArray();
        }

        public static string[] CsvToArray(string file, string separator)
        {
            return CsvTArrayOfArray(file, separator)[0];
        }
        /// <summary>
        /// Read txt file and add data to list of string.
        /// </summary>
        /// <param name="file"></param>
        /// <param name="list"></param>
        public static void TxtToList(string file, List<string> list)
        {
            string line;

            // Read the file and display it line by line.
            System.IO.StreamReader sr =
               new System.IO.StreamReader(file);
            while ((line = sr.ReadLine()) != null)
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    list.Add(line.Trim());
                }
            }

            sr.Close();
        }
        public static void TxtToList(string file, List<int> list)
        {
            string line;

            // Read the file and display it line by line.
            System.IO.StreamReader sr =
               new System.IO.StreamReader(file);
            while ((line = sr.ReadLine()) != null)
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    int effectivity;
                    if (int.TryParse(line.Trim(), out effectivity))
                    {
                        list.Add(effectivity);
                    }

                }
            }

            sr.Close();
        }
        public static DocTypeAttribute GetDocTypeAttribute(string documentType)
        {
            DocTypeAttribute dta = null;

            dta = DocTypeAttributes.Where(a => a.DocumentType.Equals(documentType, StringComparison.OrdinalIgnoreCase)).FirstOrDefault<DocTypeAttribute>();

            if (dta == null)
            {
                TraceFile.WriteLine("No Match found for documentType {0}", documentType);
            }

            return dta;
        }

        internal static void PrintAttachmentStats(ConcurrentQueue<DocSet> docSets, string dbName, string attachmentsFolder)
        {
            StringBuilder sb = new StringBuilder("\n################# Printing '" + dbName + "' Attachments Stats BEGIN #################\n");

            List<string> failedAttachments;
            var attachments = docSets.Where(d => d.ReadyForSharePoint).SelectMany(ds => HelperClass.ToAttachmentPath(attachmentsFolder, ds.Uid, ds.Attachments)).ToArray();
            long attachmentsize = HelperClass.GetTotalAttachmentSize(attachments, out failedAttachments);
            string sizeString = HelperClass.GetBytesReadable(attachmentsize);

            sb.AppendFormat("\t\tNumber of attachments: {0}\n", attachments.Count());
            sb.AppendFormat("\t\tTotal size: {0}\n", sizeString);
            sb.AppendFormat("\t\tNumber of failed attachments: {0}\n", failedAttachments.Count);

            if (failedAttachments.Count > 0)
            {
                sb.AppendLine("\t\tFailed attachments:");
                foreach (var failedAttachment in failedAttachments)
                {
                    sb.AppendLine("\t\t\t" + failedAttachment);
                }
            }

            sb.AppendLine("################# Printing '" + dbName + "' Attachments Stats END #################");
            TraceFile.WriteLine(sb.ToString(), true);
        }

        public static SharePointAttribute GetSharePointAttribute(string sharePointAttribute)
        {
            SharePointAttribute spa = null;

            spa = SharepointAttributes.Where(s => s.Name.Equals(sharePointAttribute, StringComparison.OrdinalIgnoreCase)).FirstOrDefault<SharePointAttribute>();

            if (spa == null)
            {
                TraceFile.WriteLine("No Match found for SharePoint Attribute {0}", sharePointAttribute);
            }

            return spa;
        }

        /// <summary>
        /// 
        /// </summary>
        public static void PrepareData()
        {
            //Create direcotry for reports
            System.IO.Directory.CreateDirectory(DataLoader.Default.ReportsPath);

            //Convert data in txt file from path \input\\rules\\Global\\ to dictionary object(key, value)
            CsvToDictionary(DataLoader.Default.SharepointNormalizationManualListPath, "\t", SharePointNormalizationMapping);
            CsvToDictionary(DataLoader.Default.SharepointForcedInternalNameMappingsPath, "\t", SharepointForcedInternalNameMappings);
            ExcelHelper.LoadSharePointFields(DataLoader.Default.SharePointFieldsPath);
            //CsvToDictionary(DataLoader.Default.LNCategoriesSPDocTypesMappingPath, "\t", CategoriesToDocTypeMap);
            //CsvToDictionary(DataLoader.Default.DocTypesGroupsMappingPath, "\t", DocTypeToGroupMap);
            CsvToDictionary(DataLoader.Default.FilterRulesReverseMappingPath, "\t", FilteringRulesReverseMapping);
            CsvToDictionary(DataLoader.Default.LookUpFieldValueTitleMappingPath, "\t", LookUpFieldValueTitleMapping);
            CsvToDictionary(DataLoader.Default.ThdLibraryAttachmentPath, "\t", ThdLibraryAttachmentPaths);
            CsvToDictionary(DataLoader.Default.ModelSubmodelMappingPath, "\t", ModelSubmodelMapping);


            //DocTypeAttributes = (List<DocTypeAttribute>)JsonHelper.ParseJson<DocTypeAttribute>(DataLoader.Default.MandatoryFieldsPath);
            SetMandatoryOptionalFields(DocTypeAttributes);
            //TxtToList(DataLoader.Default.LookUpListsValueFieldsPath, LookUpListsValueFields);
            TxtToList(DataLoader.Default.FieldsWithDate, FieldsWithDate);
            TxtToList(DataLoader.Default.SB_CRJ_ServiceBulletinWhitelistPath, ServiceBulletinWhitelist);
            TxtToList(DataLoader.Default.ATA_Blacklist, AtaBlacklist);
            TxtToList(DataLoader.Default.Sharepoint_Lists_To_Delete_Path, SharePointListsToDelete);
            TxtToList(DataLoader.Default.EffectivityExceptionsListPath, EffectivityExceptionsList);
            SetModelsEffectivities(DataLoader.Default.EffectivityPerModelsPath, ModelsEffectivities);

            LoadDataFiles();
        }

        private static void LoadDataFiles()
        {
            if (HelperClass.FilesExist(string.Format("{0}{1}", DataLoader.Default.SavedObjectsPath, DataLoader.Default.SerializedUnidToGuid)))
            {
                HelperClass.UnidToGuidMapping = new ConcurrentDictionary<string, string>(Serializer.Deserialize<Dictionary<string, string>>(string.Format("{0}{1}",
                    DataLoader.Default.SavedObjectsPath, DataLoader.Default.SerializedUnidToGuid)));
            }
        }

        private static void SetModelsEffectivities(string path, Dictionary<string, int[]> modelsEffectivities)
        {
            string[][] effectivities = CsvTArrayOfArray(path, ",");
            foreach (var modelEffectivity in effectivities)
            {
                string key = modelEffectivity[0];
                List<int> effies = new List<int>();
                for (int i = 1; i < modelEffectivity.Length; i++)
                {
                    string currentEffy = modelEffectivity[i];
                    if (!string.IsNullOrWhiteSpace(currentEffy))
                    {
                        int effy;
                        if (currentEffy.Contains(Constants.effectivityRangesIndicatorsReplacement.Trim()))
                        {
                            effies.AddRange(ExtractEffectivityRange(currentEffy.Trim(), Constants.effectivityRangesIndicatorsReplacement.Trim()));
                        }
                        else if (int.TryParse(currentEffy.Trim(), out effy))
                        {
                            effies.Add(effy);
                        }
                    }
                }
                modelsEffectivities.Add(key.Replace("/", ", "), effies.ToArray());
            }
            TraceFile.WriteLine("Completed SetModelsEffectivities");

        }

        private static IEnumerable<int> ExtractEffectivityRange(string value, string separator)
        {
            string[] range = value.Split(new string[] { separator }, StringSplitOptions.None);

            int from, to;

            if (range != null && range.Length == 2 && int.TryParse(range[0].Trim(), out from) &&
                int.TryParse(range[1].Trim(), out to) && to >= from)
            {
                return Enumerable.Range(from, to - from + 1);
            }
            else if (range.Length == 1 && int.TryParse(range[0].Trim(), out from))
            {
                return new List<int> { from };
            }

            return new List<int>();
        }

        /// <summary>
        /// Forces garbage collector to claim unused memory
        /// </summary>
        public static void FreeMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
        private static void SetMandatoryOptionalFields(List<DocTypeAttribute> docTypeAttributes)
        {
            string[][] matrix = CsvTArrayOfArray(DataLoader.Default.MandatoryFieldsMatrixPath, ",");
            string[] columns_ContentTypes = CsvToArray(DataLoader.Default.MandatoryFieldsColumnsPath, ",");
            string[][] rows_Attributes = CsvTArrayOfArray(DataLoader.Default.MandatoryFieldsRowsPath, ",");

            for (int i = 0; i < columns_ContentTypes.Length; i++)
            {
                DocTypeAttribute dta = new DocTypeAttribute();
                dta.DocumentType = columns_ContentTypes[i].Trim();
                List<string> mandatory = new List<string>();
                List<string> optional = new List<string>();
                for (int j = 0; j < rows_Attributes.Length; j++)
                {
                    if (matrix[j][i].Equals("M", StringComparison.OrdinalIgnoreCase))
                    {
                        mandatory.Add(GetNormalizedSharePointAttributeName(rows_Attributes[j][0].Trim()));
                    }
                    else if (matrix[j][i].Equals("O", StringComparison.OrdinalIgnoreCase))
                    {
                        optional.Add(GetNormalizedSharePointAttributeName(rows_Attributes[j][0].Trim()));
                    }
                }
                dta.Mandatory = mandatory.ToArray();
                dta.Optional = optional.ToArray();
                docTypeAttributes.Add(dta);

            }
        }

        internal static void RemoveDuplicatesFromTHDLibrary(ConcurrentBag<NotesExtract> thdLibraries, string removeDuplicatesFrom)
        {
            TraceFile.WriteLine(true, "RemoveDuplicatesFromTHDLibrary - Entering");
            if (thdLibraries.Any(l => HelperClass.ReportLogs[l.LogsId].Folder == removeDuplicatesFrom))
            {
                var library = thdLibraries.SingleOrDefault(l => HelperClass.ReportLogs[l.LogsId].Folder == removeDuplicatesFrom);
                HashSet<string> unids = new HashSet<string>();
                HashSet<string> unidsTemp = new HashSet<string>();
                foreach (var document in library.Documents)
                {
                    unids.Add(document.Uid.Trim());
                }
                foreach (var thdlibrary in thdLibraries.Where(l => HelperClass.ReportLogs[l.LogsId].Folder != removeDuplicatesFrom))
                {
                    foreach (var document in thdlibrary.Documents)
                    {
                        unidsTemp.Add(document.Uid.Trim());
                    }
                }
                var uniqueValues = unids.Except(unidsTemp);

                TraceFile.WriteLine("RemoveDuplicatesFromTHDLibrary - '{0}' contains {1} unique values out of {2}", removeDuplicatesFrom, uniqueValues.Count(), unids.Count);
            }

        }

        /// <summary>
        /// Clear data from all cached objects
        /// </summary>
        public static void ResetReusableFields()
        {
            //Logs.Instance.Reset();
            SharePointToNotesFieldMap.Clear();
            CurrentLibraryDuplicateNames.Clear();
            UsedNotesFields.Clear();
            BeginsWithSharePointFields.Clear();
            checkedMandatoryFieldForCurrentExtract = false;
        }
        public static long UnixTime()
        {
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            return Convert.ToInt64((DateTime.Now - epoch).TotalSeconds);
        }

        public static string UnixTimeToString()
        {
            var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            return Convert.ToInt64((DateTime.Now - epoch).TotalSeconds).ToString();
        }

        internal static void FillDataStructuresForFields(List<Rule> rules, List<NotesSharepointMapping> mappings, NotesDatabases notesDatabase)
        {
            AddUsedNotesFields(rules);
            AddUsedNotesAndBeginsWithSharePointFields(mappings);

            if (notesDatabase == NotesDatabases.THDTorontoLibrary)
            {
                foreach (var notesField in RulesConfiguration.Default.THD_TORONTO_LIBRARY_EXTRA_NOTES_FIELDS)
                {
                    UsedNotesFields.Add(notesField.Trim());
                }
            }
        }
        internal static void AddUsedNotesAndBeginsWithSharePointFields(List<NotesSharepointMapping> mappings)
        {
            foreach (var mapping in mappings)
            {
                UsedNotesFields.UnionWith(mapping.GetNotesFields());
                if ((!string.IsNullOrWhiteSpace(mapping.CustomMethod) &&
                    mapping.CustomMethod.Contains(DataLoader.Default.BeginsWithKeyword, StringComparison.OrdinalIgnoreCase)) ||
                     (!string.IsNullOrWhiteSpace(mapping.CustomMappingMode) && mapping.CustomMappingMode.Contains(DataLoader.Default.BeginsWithKeyword,
                     StringComparison.OrdinalIgnoreCase)))
                {
                    BeginsWithSharePointFields.Add(mapping.Sharepoint);
                }
            }
        }

        public static string GetDocumentSetContentType(string documentType)
        {
            string documentSetContentType;
            if (LaunchConfiguration.Default.DOCUMENT_SET_REMOVE_PARENTHESIS)
            {
                documentSetContentType = string.Format("{0} {1}", Regex.Replace(documentType.Trim(), @"\s*\(.+?\)\s*$", ""), DataLoader.Default.ContentTypeDocumentSet);
            }
            else
            {
                documentSetContentType = string.Format("{0} {1}", documentType.Trim(), DataLoader.Default.ContentTypeDocumentSet);
            }
            //TraceFile.WriteLine("Converted content type '{0}' to document set content type '{1}'", documentType, documentSetContentType);

            return documentSetContentType;
        }

        //internal static void AddUsedNotesAndBeginsWithSharePointFields(List<NotesSharepointMapping> mappings)
        //{
        //    foreach (var mapping in mappings.Where(m => !string.IsNullOrWhiteSpace(m.Notes) || m.RulesMapping != null))
        //    {
        //        UsedNotesFields.Add(mapping.Notes);
        //        if (!string.IsNullOrWhiteSpace(mapping.NotesFallback))
        //        {
        //            UsedNotesFields.Add(mapping.NotesFallback);
        //        }
        //        if (mapping.RulesMapping != null)
        //        {
        //            foreach (var ruleMapping in mapping.RulesMapping)
        //            {
        //                UsedNotesFields.UnionWith(ruleMapping.Value.GetFields());
        //            }
        //        }
        //        if (!string.IsNullOrWhiteSpace(mapping.CustomMethod) &&
        //            (mapping.CustomMethod.Contains(DataLoader.Default.BeginsWithKeyword, StringComparison.OrdinalIgnoreCase) ||
        //             mapping.CustomMappingMode.Contains(DataLoader.Default.BeginsWithKeyword, StringComparison.OrdinalIgnoreCase)))
        //        {
        //            BeginsWithSharePointFields.Add(mapping.Sharepoint);
        //        }
        //    }
        //}
        internal static void AddUsedNotesFields(List<Rule> rules)
        {
            foreach (var rule in rules)
            {
                UsedNotesFields.UnionWith(rule.GetFields());
            }

        }
        public static int LevenshteinDistance(String a, String b)
        {

            if (string.IsNullOrEmpty(a))
            {
                if (!string.IsNullOrEmpty(b))
                {
                    return b.Length;
                }
                return 0;
            }

            if (string.IsNullOrEmpty(b))
            {
                if (!string.IsNullOrEmpty(a))
                {
                    return a.Length;
                }
                return 0;
            }

            Int32 cost;
            Int32[,] d = new int[a.Length + 1, b.Length + 1];
            Int32 min1;
            Int32 min2;
            Int32 min3;

            for (Int32 i = 0; i <= d.GetUpperBound(0); i += 1)
            {
                d[i, 0] = i;
            }

            for (Int32 i = 0; i <= d.GetUpperBound(1); i += 1)
            {
                d[0, i] = i;
            }

            for (Int32 i = 1; i <= d.GetUpperBound(0); i += 1)
            {
                for (Int32 j = 1; j <= d.GetUpperBound(1); j += 1)
                {
                    cost = Convert.ToInt32(!(a[i - 1] == b[j - 1]));

                    min1 = d[i - 1, j] + 1;
                    min2 = d[i, j - 1] + 1;
                    min3 = d[i - 1, j - 1] + cost;
                    d[i, j] = Math.Min(Math.Min(min1, min2), min3);
                }
            }

            return d[d.GetUpperBound(0), d.GetUpperBound(1)];
        }
        public static string GetClosestMatch(string input, string[] values)
        {
            try
            {
                int distance = int.MaxValue;
                int matchIndex = -1;

                for (int i = 0; i < values.Length; i++)
                {
                    int tempDistance = HelperClass.LevenshteinDistance(input.Trim().ToUpper(), values[i].Trim().ToUpper());
                    if (tempDistance < distance)
                    {
                        distance = tempDistance;
                        matchIndex = i;
                    }
                }

                TraceFile.WriteLine("'{0}' was matched to '{1}'", input, values[matchIndex]);
                return values[matchIndex];
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static string GetNormalizedSharePointAttributeName(string spAttribute)
        {
            string result = null;
            if (SharepointAttributesNames.Contains(spAttribute))
            {
                return spAttribute;
            }
            else if (SharePointNormalizationMapping.ContainsKey(spAttribute))
            {
                result = GetClosestMatch(SharePointNormalizationMapping[spAttribute], SharepointAttributesNames);
                return result;
            }
            else
            {
                TraceFile.WriteLine("GetNormalizedSharePointAttributeName - Attempting partial match for '{0}'", spAttribute);
                result = GetClosestMatch(spAttribute, SharepointAttributesNames);
                return result;
            }
        }

        internal static void PrintAttachmentStats(Dictionary<string, ConcurrentQueue<DocSet>> docSetCollections, string dbName, Dictionary<string, string> libraryAttachmentPaths)
        {
            StringBuilder sb = new StringBuilder("\n################# Printing '" + dbName + "' Attachments Stats BEGIN #################\n");
            long totalAttachmentsize = 0;
            long totalAttachmentsCount = 0;
            foreach (var docSets in docSetCollections)
            {
                List<string> failedAttachments;
                var attachments = docSets.Value.Where(d => d.ReadyForSharePoint).SelectMany(ds => HelperClass.ToAttachmentPath(libraryAttachmentPaths[docSets.Key], ds.Uid, ds.Attachments)).ToArray();

                long attachmentsize = HelperClass.GetTotalAttachmentSize(attachments, out failedAttachments);
                string sizeString = HelperClass.GetBytesReadable(attachmentsize);

                totalAttachmentsize += attachmentsize;
                totalAttachmentsCount += attachments.Count();
                sb.AppendFormat("\t\t{0}\n", docSets.Key);
                sb.AppendFormat("\t\t\tNumber of attachments: {0}\n", attachments.Count());
                sb.AppendFormat("\t\t\tSize: {0}\n", sizeString);
                sb.AppendFormat("\t\t\tNumber of failed attachments: {0}\n", failedAttachments.Count);

                if (failedAttachments.Count > 0)
                {
                    sb.AppendLine("\t\t\tFailed attachments:");
                    foreach (var failedAttachment in failedAttachments)
                    {
                        sb.AppendLine("\t\t\t\t" + failedAttachment);
                    }
                }
            }

            string totalSizeString = HelperClass.GetBytesReadable(totalAttachmentsize);
            sb.AppendFormat("\n\t\tTotal number of attachments: {0}\n", totalAttachmentsCount);
            sb.AppendFormat("\t\tTotal size: {0}\n", totalSizeString);

            sb.AppendLine("################# Printing '" + dbName + "' Attachments Stats END #################");
            TraceFile.WriteLine(sb.ToString(), true);
        }

        public static bool FilesExist(params string[] files)
        {
            foreach (var file in files)
            {
                if (!System.IO.File.Exists(file))
                {
                    return false;
                }
            }
            return true;
        }
        public static string GetContainingFolder(string fileName)
        {
            Regex r1 = new Regex(@"^.+?([^\\]+)\\[^\\]+\.[\w]+$");
            Match match = r1.Match(fileName);
            string result = null;
            if (match.Success)
            {
                result = match.Groups[1].Value;
            }

            return result;
        }
        public static bool BuildEffectivity(string currentEffectivity, out string effectivity, Dictionary<string, string> spAttributes, out string emptyModels, bool replaceByAllIfFullRange = true)
        {
            //CRJ Series::700::10002 - 10500||CRJ Series::1000::19001 - 19980,19985,19987 - 19999
            // need attibutes, take model and family, and for each model, create proper format
            effectivity = null;
            emptyModels = null;
            StringBuilder sb = new StringBuilder();
            string airCraftFamily = spAttributes[DataLoader.Default.SharePointAircrafFamilyField].Trim();
            string[] models = spAttributes[DataLoader.Default.SharepointModelNumberField].Split(
                new string[] { DataLoader.Default.MultiLookupSeparator }, StringSplitOptions.None).Select(m => m.Trim()).ToArray();
            List<string> usedModels = new List<string>();
            HashSet<int> referenceList = new HashSet<int>(), assignedList = new HashSet<int>();
            bool containsSubsequent = currentEffectivity.EndsWith(DataLoader.Default.EffectivitySubsequent, StringComparison.OrdinalIgnoreCase);
            bool containsSplitRange = false;
            string[] splitEffectivities = null;
            foreach (var model in models)
            {
                if (!usedModels.Contains(model, StringComparer.OrdinalIgnoreCase))
                {
                    string msns;
                    BuildEffectivityStatus status = GetSerials(currentEffectivity, model, out msns, referenceList, assignedList, out splitEffectivities,
                        replaceByAllIfFullRange, containsSubsequent ? DataLoader.Default.EffectivitySubsequent : null);

                    switch (status)
                    {
                        case BuildEffectivityStatus.Success:
                            sb.AppendFormat("{0}{1}::{2}::{3}", sb.Length > 0 ? DataLoader.Default.ModelEffectivitySeparator : string.Empty,
                                            airCraftFamily, model, msns);
                            usedModels.Add(model);
                            break;
                        case BuildEffectivityStatus.SplitRange:
                            sb.AppendFormat("{0}{1}::{2}::{3}", sb.Length > 0 ? DataLoader.Default.ModelEffectivitySeparator : string.Empty,
                                            airCraftFamily, model, msns);
                            usedModels.Add(model);
                            containsSplitRange = true;
                            TraceFile.WriteLine("BuildEffectivity {0} - Split Range for model '{1}' and effectivity '{2}'", spAttributes[DataLoader.Default.SharepointDocumentIDField], model, currentEffectivity);

                            break;
                        case BuildEffectivityStatus.UseEffectivityAsIs:
                            sb.AppendFormat("{0}{1}::{2}::{3}", sb.Length > 0 ? DataLoader.Default.ModelEffectivitySeparator : string.Empty,
                                            airCraftFamily, model, currentEffectivity);
                            usedModels.Add(model);
                            break;
                        case BuildEffectivityStatus.ModelNotFound:
                            TraceFile.WriteLine("BuildEffectivity {0} - model '{1}' not found", spAttributes[DataLoader.Default.SharepointDocumentIDField], model);
                            return false;
                        case BuildEffectivityStatus.EmptyResult:
                            sb.AppendFormat("{0}{1}::{2}::{3}", sb.Length > 0 ? DataLoader.Default.ModelEffectivitySeparator : string.Empty,
                                airCraftFamily, model, string.Empty);
                            TraceFile.WriteLine("BuildEffectivity {0} - model '{1}' matched to none of these msns: {2}", spAttributes[DataLoader.Default.SharepointDocumentIDField], model, currentEffectivity);
                            break;
                        //return false;
                        default:
                            break;
                    }
                }
            }

            if (referenceList.Count > assignedList.Count)
            {
                IEnumerable<int> unassignedMsns = referenceList.Except(assignedList);
                bool rejectItem = false;
                if (splitEffectivities != null && splitEffectivities.Length > 0)
                {
                    foreach (var splitEffectivity in splitEffectivities)
                    {
                        if (rejectItem)
                        {
                            break;
                        }
                        string[] tempEffectivityArray = splitEffectivity.Split(new string[] { Constants.effectivityRangesIndicatorsReplacement },
                            StringSplitOptions.None);
                        foreach (var tempEffectivity in tempEffectivityArray)
                        {
                            int effy;
                            if (int.TryParse(tempEffectivity.Trim(), out effy) && unassignedMsns.Contains(effy))
                            {
                                rejectItem = true;
                            }
                        }
                    }
                }
                if (rejectItem)
                {
                    TraceFile.WriteLine("BuildEffectivity {0} - following msns were not assigned to any model: '{1}'", spAttributes[DataLoader.Default.SharepointDocumentIDField],
                        string.Join(",", unassignedMsns.ToArray()));
                    return false;
                }
                else
                {
                    TraceFile.WriteLine("BuildEffectivity {0} - following msns were not assigned to any model BUT they were inside ranges: '{1}'", spAttributes[DataLoader.Default.SharepointDocumentIDField],
                        string.Join(",", unassignedMsns.ToArray()));
                }
            }
            if (usedModels.Count == 0)
            {
                TraceFile.WriteLine("BuildEffectivity {0} - no models found any match: '{1}'", spAttributes[DataLoader.Default.SharepointDocumentIDField],
                    string.Join(",", models));
                return false;
            }
            else if (usedModels.Count < models.Length)
            {
                emptyModels = string.Join("\n", models.Except(usedModels).ToArray());
                //TraceFile.WriteLine("BuildEffectivity {0} - all msns assigned, but following model(s) have empty effectivity: '{1}'", spAttributes[DataLoader.Default.SharepointDocumentIDField],
                //    emptyModels);

            }
            if (containsSplitRange)
            {
                TraceFile.WriteLine("BuildEffectivity {0} - SPLITRANGE - converted '{1}' to '{2}'", spAttributes[DataLoader.Default.SharepointDocumentIDField], currentEffectivity, sb.ToString());

            }
            else
            {
                TraceFile.WriteLine("BuildEffectivity {0} - converted '{1}' to '{2}'", spAttributes[DataLoader.Default.SharepointDocumentIDField], currentEffectivity, sb.ToString());

            }
            effectivity = sb.ToString();
            return true;
        }

        public static BuildEffectivityStatus GetSerials(string currentEffectivity, string model, out string msns, HashSet<int> referenceList, HashSet<int> assignedList, out string[] splitEffectivities, bool replaceByAllIfFullRange, string putBackAtTheEnd = null)
        {
            bool splitRange = false;
            msns = null;
            splitEffectivities = null;

            if (!currentEffectivity.Any(c => char.IsDigit(c)))
            {
                return BuildEffectivityStatus.UseEffectivityAsIs;
            }
            //string[] splitEffectivities;
            StringBuilder sb = new StringBuilder();


            int[] modelMsns = null;

            if (ModelsEffectivities.ContainsKey(model.Trim()))
            {
                modelMsns = ModelsEffectivities[model.Trim()];
            }
            else
            {
                TraceFile.WriteLine("Model '{0}' has no matching serial numbers", model.Trim());
                return BuildEffectivityStatus.ModelNotFound;
            }

            if (putBackAtTheEnd != null)
            {
                splitEffectivities = MergeRanges(currentEffectivity.Remove(currentEffectivity.Length - putBackAtTheEnd.Length).Split(
                    new string[] { Constants.effectivityValuesSeparatorsReplacement }, StringSplitOptions.None));
            }
            else
            {
                splitEffectivities = MergeRanges(currentEffectivity.Split(
                    new string[] { Constants.effectivityValuesSeparatorsReplacement }, StringSplitOptions.None));
            }

            if (referenceList.Count == 0)
            {
                referenceList.UnionWith(ToFullEffectivity(splitEffectivities));
                referenceList.RemoveWhere(rl => HelperClass.EffectivityExceptionsList.Contains(rl));
            }

            List<int> fullModelMatch = new List<int>();

            foreach (var splitEffectivity in splitEffectivities)
            {
                var values = ExtractEffectivityRange(splitEffectivity.Trim(), Constants.effectivityRangesIndicatorsReplacement.Trim());
                bool isFullRangeMatch = true;
                List<int> rangeMatch = new List<int>();
                foreach (var value in values)
                {
                    if (modelMsns.Contains(value))
                    {
                        rangeMatch.Add(value);
                        fullModelMatch.Add(value);
                        assignedList.Add(value);
                    }
                    else
                    {
                        isFullRangeMatch = false;
                    }
                }
                if (isFullRangeMatch)
                {
                    //sb.AppendFormat("{0}{1}{2}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
                    //    string.Empty, splitEffectivity.Trim(), !string.IsNullOrWhiteSpace(putBackAtTheEnd) ? putBackAtTheEnd : string.Empty);
                    sb.AppendFormat("{0}{1}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement : string.Empty, splitEffectivity.Trim());
                }
                else if (rangeMatch.Count > 0)
                {
                    rangeMatch.Sort();
                    sb.AppendFormat("{0}{1}{2}{3}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
                        string.Empty, rangeMatch.First(), Constants.effectivityRangesIndicatorsReplacement, rangeMatch.Last());
                    //sb.AppendFormat("{0}{1}{2}{3}{4}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
                    //    string.Empty, rangeMatch.First(), Constants.effectivityRangesIndicatorsReplacement, rangeMatch.Last(),
                    //    !string.IsNullOrWhiteSpace(putBackAtTheEnd) ? putBackAtTheEnd : string.Empty);

                    //                   sb.AppendFormat("{0}{1}{2}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
                    //                       string.Empty, ToEffectivityString(rangeMatch), !string.IsNullOrWhiteSpace(putBackAtTheEnd) ? putBackAtTheEnd : string.Empty);
                    splitRange = true;
                }
            }
            if (sb.Length == 0)
            {
                return BuildEffectivityStatus.EmptyResult;
            }
            if (replaceByAllIfFullRange && !modelMsns.Except(fullModelMatch).Any())
            {
                TraceFile.WriteLine("GetSerials - '{0}' contains full '{1}' range, replacing by All", sb.ToString(), model.Trim());
                msns = RulesConfiguration.Default.EffectivityAll;
            }
            else
            {
                msns = sb.ToString() + (!string.IsNullOrWhiteSpace(putBackAtTheEnd) ? putBackAtTheEnd : string.Empty);
            }
            return !splitRange ? BuildEffectivityStatus.Success : BuildEffectivityStatus.SplitRange;
        }

        private static string[] MergeRanges(string[] effectivityArray)
        {
            HashSet<string> effectivitySet = new HashSet<string>();
            string[] result;
            foreach (var effectivity in effectivityArray)
            {
                string[] range = effectivity.Split(new string[] { Constants.effectivityRangesIndicatorsReplacement },
                    StringSplitOptions.None);
                int start, end;
                bool singleValue = range.Length == 1;
                bool include = true;
                if (ExtractRange(range, out start, out end))
                {
                    foreach (var tempEffectivity in effectivityArray.Where(e => e != effectivity && e.Contains(Constants.effectivityRangesIndicatorsReplacement)))
                    {
                        string[] rangeTemp = tempEffectivity.Split(new string[] { Constants.effectivityRangesIndicatorsReplacement },
                                StringSplitOptions.None);

                        int startTemp, endTemp;

                        if (ExtractRange(rangeTemp, out startTemp, out endTemp))
                        {
                            OptimizeRange(ref start, ref end, singleValue, ref include, startTemp, endTemp);
                        }
                        else
                        {
                            TraceFile.WriteLine("MergeRanges - Unable to extract int from '{0}'", tempEffectivity);
                            return effectivityArray;
                        }
                    }
                    if (include)
                    {
                        if (singleValue)
                        {
                            effectivitySet.Add(start + "");
                        }
                        else
                        {
                            effectivitySet.Add(string.Format("{0}{1}{2}", start, Constants.effectivityRangesIndicatorsReplacement, end));
                        }
                    }
                }
                else
                {
                    TraceFile.WriteLine("MergeRanges - Unable to extract int from '{0}'", effectivity);
                    return effectivityArray;
                }
            }
            var sortedEffies = effectivitySet.ToList();
            sortedEffies.Sort(new NaturalStringComparer());
            result = sortedEffies.ToArray();
            if (result.Length != effectivityArray.Length)
            {
                TraceFile.WriteLine("MergeRanges - Simplified '{0}' to '{1}'", string.Join(",", effectivityArray), string.Join(",", result));
            }

            return result;
        }

        private static void OptimizeRange(ref int start, ref int end, bool singleValue, ref bool include, int startTemp, int endTemp)
        {
            if (singleValue)
            {
                if (start >= startTemp && start <= endTemp)
                {
                    include = false;
                    TraceFile.WriteLine("OptimizeRange - {0} included in range {1}-{2} - will be excluded", start, startTemp, endTemp);
                }
            }
            else
            {
                if (startTemp <= start && endTemp >= end)
                {
                    start = startTemp;
                    end = endTemp;
                }
                else if (startTemp <= start && (endTemp < end && endTemp >= start))
                {
                    start = startTemp;
                }
                else if ((startTemp > start && startTemp <= end) && endTemp >= end)
                {
                    end = endTemp;
                }
            }
        }

        private static bool ExtractRange(string[] range, out int start, out int end)
        {
            bool result = false;
            start = -1;
            end = -1;
            if (range.Length == 2)
            {
                if (int.TryParse(range[0].Trim(), out start) && int.TryParse(range[1].Trim(), out end))
                {
                    result = true;
                }
            }
            else if (range.Length == 1)
            {
                if (int.TryParse(range[0].Trim(), out start))
                {
                    end = start;
                    result = true;
                }
            }
            return result;
        }

        private static string ToEffectivityString(List<int> rangeMatch)
        {
            StringBuilder sb = new StringBuilder();
            rangeMatch.Sort();
            for (int i = 0; i < rangeMatch.Count; )
            {
                var start = rangeMatch[i];
                int size = 1;
                while (++i < rangeMatch.Count && rangeMatch[i] == start + size)
                {
                    size++;
                }

                if (size == 1)
                {
                    sb.AppendFormat("{0}{1}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
                        string.Empty, start.ToString());
                }

                else if (size == 2)
                {
                    sb.AppendFormat("{0}{1}{2}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
                        string.Empty, start.ToString(), Constants.effectivityValuesSeparatorsReplacement + (start + 1).ToString());
                }
                else if (size > 2)
                {
                    //Constants.effectivityRangesIndicatorsReplacement
                    sb.AppendFormat("{0}{1}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
                        string.Empty, start + Constants.effectivityRangesIndicatorsReplacement + (start + size - 1));

                }
            }
            TraceFile.WriteLine("ToEffectivityString - Converted rangeMath '{0}' to {1}", string.Join(",", rangeMatch), sb.ToString());
            return sb.ToString();
        }

        private static IEnumerable<int> ToFullEffectivity(string[] splitEffectivities)
        {
            HashSet<int> effectivities = new HashSet<int>();
            foreach (var splitEffectivity in splitEffectivities)
            {
                effectivities.UnionWith(ExtractEffectivityRange(splitEffectivity.Trim(), Constants.effectivityRangesIndicatorsReplacement.Trim()));
            }
            return effectivities;
        }

        internal static double GetMigrationRate(double totalMilliseconds, int itemCount)
        {
            return Math.Round(Convert.ToSingle(itemCount / (totalMilliseconds / 60000d)),
                2, MidpointRounding.AwayFromZero);
        }
        internal static double GetMigrationRateSeconds(double totalMilliseconds, double itemCount)
        {
            return Math.Round(Convert.ToSingle(itemCount / (totalMilliseconds / 1000d)),
                4, MidpointRounding.AwayFromZero);
        }

        public static double ConvertBytesToMegabytes(long bytes)
        {
            return (bytes / 1024d) / 1024d;
        }

        public static double ConvertKilobytesToMegabytes(long kilobytes)
        {
            return kilobytes / 1024d;
        }

        // Returns the human-readable file size for an arbitrary, 64-bit file size 
        // The default format is "0.### XB", e.g. "4.2 KB" or "1.434 GB"
        public static string GetBytesReadable(long i)
        {
            // Get absolute value
            long absolute_i = (i < 0 ? -i : i);
            // Determine the suffix and readable value
            string suffix;
            double readable;
            if (absolute_i >= 0x1000000000000000) // Exabyte
            {
                suffix = "EB";
                readable = (i >> 50);
            }
            else if (absolute_i >= 0x4000000000000) // Petabyte
            {
                suffix = "PB";
                readable = (i >> 40);
            }
            else if (absolute_i >= 0x10000000000) // Terabyte
            {
                suffix = "TB";
                readable = (i >> 30);
            }
            else if (absolute_i >= 0x40000000) // Gigabyte
            {
                suffix = "GB";
                readable = (i >> 20);
            }
            else if (absolute_i >= 0x100000) // Megabyte
            {
                suffix = "MB";
                readable = (i >> 10);
            }
            else if (absolute_i >= 0x400) // Kilobyte
            {
                suffix = "KB";
                readable = i;
            }
            else
            {
                return i.ToString("0 B"); // Byte
            }
            // Divide by 1024 to get fractional value
            readable = (readable / 1024);
            // Return formatted number with suffix
            return readable.ToString("0.### ") + suffix;
        }
        internal static long GetTotalAttachmentSize(string[] attachmentsPaths)
        {
            long byteSize = 0;
            string currAttachment = null;

            foreach (var attachment in attachmentsPaths)
            {

                try
                {
                    currAttachment = attachment;
                    FileInfo info = new FileInfo(attachment.Trim());
                    byteSize += info.Length;
                }

                catch (Exception e)
                {
                    TraceFile.WriteLine("GetTotalAttachmentSize - Issue extracting size for '{0}'", currAttachment);
                    TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                }
            }

            return byteSize;
        }

        internal static long GetTotalAttachmentSize(string[] attachmentsPaths, out List<string> failedAttachments)
        {
            long byteSize = 0;
            string currAttachment = null;
            failedAttachments = new List<string>();

            foreach (var attachment in attachmentsPaths)
            {
                try
                {
                    currAttachment = attachment;
                    FileInfo info = new FileInfo(attachment.Trim());
                    byteSize += info.Length;
                }

                catch (Exception e)
                {
                    TraceFile.WriteLine("GetTotalAttachmentSize - Issue extracting size for '{0}'", currAttachment);
                    failedAttachments.Add(currAttachment);
                    TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                }
            }

            return byteSize;
        }

        internal static IEnumerable<string> ToAttachmentPath(string attachmentFolder, string uid, Dictionary<string, string> attachments)
        {
            List<string> attachmentPaths = new List<string>();

            foreach (var attachment in attachments)
            {
                attachmentPaths.Add(string.Format("{0}\\{1}\\{2}", attachmentFolder, uid, attachment.Key).ToString());
            }
            return attachmentPaths;
        }
        public static string UnidToGuid(string uid)
        {

            if (!UnidToGuidMapping.ContainsKey(uid))
            {
                bool foundUniqueGuid = false;
                string newGuid;
                while (!foundUniqueGuid)
                {
                    newGuid = Guid.NewGuid().ToString();
                    lock (HelperClass.thisLock)
                    {
                        if (!UnidToGuidMapping.Any(x => x.Value == newGuid))
                        {
                            foundUniqueGuid = true;
                            UnidToGuidMapping[uid] = newGuid;
                            TraceFile.WriteLine("UnidToGuid - Generated guid '{0}' for '{1}'", newGuid, uid);
                        }
                    }
                }
            }
            else
            {
                TraceFile.WriteLine("UnidToGuid - Found already existing guid '{0}' for '{1}'", UnidToGuidMapping[uid], uid);
            }
            return UnidToGuidMapping[uid].Trim().ToUpper();
        }
        public static Dictionary<string, List<DocSet>> ToSerializableCollection(Dictionary<string, ConcurrentQueue<DocSet>> docSetCollections)
        {
            Dictionary<string, List<DocSet>> docSetCollectionsForSerialization = new Dictionary<string, List<DocSet>>();
            foreach (var docSetCollection in docSetCollections)
            {
                docSetCollectionsForSerialization[docSetCollection.Key] = new List<DocSet>(docSetCollection.Value);

            }
            return docSetCollectionsForSerialization;
        }
        public static Dictionary<string, ConcurrentQueue<DocSet>> ToConcurrentCollection(Dictionary<string, List<DocSet>> docSetCollectionsSerializable)
        {
            Dictionary<string, ConcurrentQueue<DocSet>> docSetCollectionsForSerialization = new Dictionary<string, ConcurrentQueue<DocSet>>();
            foreach (var docSetCollectionSerializable in docSetCollectionsSerializable)
            {
                docSetCollectionsForSerialization[docSetCollectionSerializable.Key] = new ConcurrentQueue<DocSet>(docSetCollectionSerializable.Value);

            }
            return docSetCollectionsForSerialization;
        }

        public static string[] StringCollectionToArray(System.Collections.Specialized.StringCollection stringCollection)
        {
            return stringCollection.Cast<string>().ToArray();
        }


        //public static bool BuildEffectivity(string currentEffectivity, out string effectivity, Dictionary<string, string> spAttributes)
        //{
        //    //CRJ Series::700::10002 - 10500||CRJ Series::1000::19001 - 19980,19985,19987 - 19999
        //    // need attibutes, take model and family, and for each model, create proper format
        //    effectivity = null;
        //    StringBuilder sb = new StringBuilder();
        //    string airCraftFamily = spAttributes[DataLoader.Default.SharePointAircrafFamilyField];
        //    string[] models = spAttributes[DataLoader.Default.SharepointModelNumberField].Split(
        //        new string[] { DataLoader.Default.MultiLookupSeparator }, StringSplitOptions.None);
        //    List<string>  usedModels = new List<string>(), referenceList = new List<string>(), assignedList = new List<string>();
        //    bool containsSubsequent = currentEffectivity.EndsWith(DataLoader.Default.EffectivitySubsequent, StringComparison.OrdinalIgnoreCase);

        //    foreach (var model in models)
        //    {
        //        if (!usedModels.Contains(model, StringComparer.OrdinalIgnoreCase))
        //        {
        //            usedModels.Add(model);
        //            string msns;
        //            BuildEffectivityStatus status = GetSerials(currentEffectivity, model, out msns, referenceList, assignedList,
        //                containsSubsequent ? DataLoader.Default.EffectivitySubsequent : null);

        //            switch (status)
        //            {
        //                case BuildEffectivityStatus.Success:
        //                    sb.AppendFormat("{0}{1}::{2}::{3}", sb.Length > 0 ? DataLoader.Default.ModelEffectivitySeparator : string.Empty,
        //                                    airCraftFamily, model, msns);
        //                    break;
        //                case BuildEffectivityStatus.UseEffectivityAsIs:
        //                    sb.AppendFormat("{0}{1}::{2}::{3}", sb.Length > 0 ? DataLoader.Default.ModelEffectivitySeparator : string.Empty,
        //                                    airCraftFamily, model, currentEffectivity);
        //                    break;
        //                case BuildEffectivityStatus.ModelNotFound:
        //                    TraceFile.WriteLine("BuildEffectivity {0} - model '{1}' not found", spAttributes[DataLoader.Default.SharepointDocumentIDField], model);
        //                    return false;
        //                case BuildEffectivityStatus.EmptyResult:
        //                    TraceFile.WriteLine("BuildEffectivity {0} - model '{1}' matched to none of these msns: {2}", spAttributes[DataLoader.Default.SharepointDocumentIDField], model, currentEffectivity);
        //                    return false;
        //                default:
        //                    break;
        //            }
        //            if (status == BuildEffectivityStatus.Success)
        //            {

        //            }
        //            else if (status == BuildEffectivityStatus.UseEffectivityAsIs)
        //            {

        //            }
        //            else if (status == BuildEffectivityStatus.EmptyResult)
        //            {
        //                return false;
        //            }
        //        }
        //    }

        //    if (referenceList.Count > assignedList.Count)
        //    {
        //        TraceFile.WriteLine("BuildEffectivity {0} - following msns were not assigned to any model: '{1}'", spAttributes[DataLoader.Default.SharepointDocumentIDField],
        //            string.Join(",", referenceList.Except(assignedList).ToArray()));
        //        return false;
        //    }
        //    TraceFile.WriteLine("BuildEffectivity {0} - converted '{1}' to '{2}'", spAttributes[DataLoader.Default.SharepointDocumentIDField], currentEffectivity, sb.ToString());
        //    effectivity = sb.ToString();
        //    return true;
        //}

        //public static BuildEffectivityStatus GetSerials(string currentEffectivity, string model, out string msns, List<string> referenceList, List<string> assignedList, string putBackAtTheEnd = null)
        //{
        //    msns = null;

        //    if (!currentEffectivity.Any(c => char.IsDigit(c)))
        //    {
        //        return BuildEffectivityStatus.UseEffectivityAsIs;
        //    }
        //    string[] splitEffectivities;
        //    StringBuilder sb = new StringBuilder();


        //    int[] modelMsns = null;

        //    if (ModelsEffectivities.ContainsKey(model.Trim()))
        //    {
        //        modelMsns = ModelsEffectivities[model.Trim()];
        //    }
        //    else
        //    {
        //        TraceFile.WriteLine("Model '{0}' has no matching serial numbers", model.Trim());
        //        return BuildEffectivityStatus.ModelNotFound;
        //    }            

        //    if (putBackAtTheEnd != null)
        //    {
        //        splitEffectivities = currentEffectivity.Remove(currentEffectivity.Length - putBackAtTheEnd.Length).Split(
        //            new string[] { Constants.effectivityValuesSeparatorsReplacement }, StringSplitOptions.None);
        //    }
        //    else
        //    {
        //        splitEffectivities = currentEffectivity.Split(
        //            new string[] { Constants.effectivityValuesSeparatorsReplacement }, StringSplitOptions.None);
        //    }

        //    if (referenceList.Count == 0)
        //    {
        //        referenceList.AddRange(splitEffectivities);
        //    }

        //    foreach (var splitEffectivity in splitEffectivities)
        //    {
        //        var values = ExtractEffectivityRange(splitEffectivity.Trim(), Constants.effectivityRangesIndicatorsReplacement.Trim());
        //        bool isMatch = true;
        //        foreach (var value in values)
        //        {
        //            if (!modelMsns.Contains(value))
        //            {
        //                isMatch = false;
        //            }
        //        }
        //        if (isMatch)
        //        {
        //            assignedList.Add(splitEffectivity);
        //            sb.AppendFormat("{0}{1}", sb.Length > 0 ? Constants.effectivityValuesSeparatorsReplacement :
        //                string.Empty, splitEffectivity);
        //        }
        //    }
        //    if (sb.Length == 0)
        //    {
        //        return BuildEffectivityStatus.EmptyResult;
        //    }
        //    msns = sb.ToString();
        //    return BuildEffectivityStatus.Success;
        //}
    }
}
