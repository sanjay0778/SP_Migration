﻿using BCA.DocumentMigration.SpDataLoader.Rules;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    class JsonHelper
    {
        /// <summary>
        /// Returs JSON object of type Rule/T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="jsonFile"></param>
        /// <returns></returns>
        public static IList<T> ParseJson<T>(string jsonFile)
        {
            IList<T> jsonObjects = new List<T>();
            using (TextReader reader = File.OpenText(jsonFile))
            {
                //Reads JSON file
                JsonTextReader jsonReader = new JsonTextReader(File.OpenText(jsonFile));
                jsonReader.SupportMultipleContent = true;                

                while (true)
                {
                    if (!jsonReader.Read())
                    {
                        break;
                    }
                    JsonSerializer jSerializer = new JsonSerializer();
                    //creates JSON object of type T(Rule)
                    T jsonObject = jSerializer.Deserialize<T>(jsonReader);
                    jsonObjects.Add(jsonObject);
                }              
            }
            return jsonObjects;
        }
    }
}