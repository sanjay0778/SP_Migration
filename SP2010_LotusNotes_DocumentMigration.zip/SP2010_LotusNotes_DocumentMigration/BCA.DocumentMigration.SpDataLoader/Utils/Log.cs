﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    public class Log
    {
        public bool Success { get; set;}
        public bool FilesAttached { get; set; }
        public string Uid { get; set;}
        public string DocumentGroup { get; set; }
        public string DocumentType { get; set; }
        public string EmptyEffectivityModels { get; set; }
        public string FaultyAtas { get; set; }

        public int ExcelRow { get; set; }

        public Dictionary<string, string> NotesAttributes { get; set; }
        public Dictionary<string, string> SharePointAttributes { get; set; }
        public List<KeyValuePair<bool, string>> FilteringRules { get; set; }
        public List<KeyValuePair<bool, string>> TransformationRules { get; set; }
        public List<KeyValuePair<bool, string>> MandatoryFieldsRules { get; set; }
        public List<KeyValuePair<bool, string>> FieldsLengthsRules { get; set; }
        public StringBuilder SharepointValidation { get; set; }

        public List<string[]> FilteringRulesFailedFields { get; set; }
        public List<string[]> TransformationRulesFailedFields { get; set; }
        public List<string> MandatoryFieldsRulesFailedFields { get; set; }
        public List<string> FieldsLengthsRulesFailedFields { get; set; }
        public List<string> InvalidFileNames { get; set; }


        public Log(string uId, int excelRow)
        {
            this.Uid                              = uId;
            this.FilteringRules                   = new List<KeyValuePair<bool, string>>();
            this.TransformationRules              = new List<KeyValuePair<bool, string>>();
            this.MandatoryFieldsRules             = new List<KeyValuePair<bool, string>>();
            this.FieldsLengthsRules               = new List<KeyValuePair<bool, string>>();
            this.ExcelRow                         = excelRow;
            this.Success                          = true;
            this.SharePointAttributes             = new Dictionary<string, string>();
            this.FilesAttached                    = true;
            this.FilteringRulesFailedFields       = new List<string[]>();
            this.TransformationRulesFailedFields  = new List<string[]>();
            this.MandatoryFieldsRulesFailedFields = new List<string>();
            this.FieldsLengthsRulesFailedFields   = new List<string>();
            this.InvalidFileNames                 = new List<string>();
        }

        public Log()
        {
        }

        internal string GetResult()
        {
            string result = null;

            if (!Success && FilteringRules.Count > 0)
            {
                result = "Exclusion";
            }
            else
            {
                result = Success ? "Success" : "Failure";
            }

            return result;
        }

        internal string GetErrors()
        {
            StringBuilder errors = new StringBuilder();
            int i;
            if (!Success)
            {
                if (GetResult().Equals("Exclusion"))
                {
                    //errors.Append(DataLoader.Default.ReportError_Filtering);
                    foreach (var rule in FilteringRules)
                    {
                        if (!rule.Key && !errors.ToString().Contains(rule.Value))
                        {
                            if (errors.Length > 0)
                            {
                                errors.AppendLine();
                            }
                            errors.Append(rule.Value);
                        }
                    }
                }
                else if (SharepointValidation != null && SharepointValidation.Length > 0)
                {
                    return SharepointValidation.ToString();
                }
                else
                {
                    if (TransformationRules.Exists(r => !r.Key))
                    {
                        i = 0;
                        foreach (var rule in TransformationRules)
                        {
                            if (!rule.Key && string.IsNullOrWhiteSpace(rule.Value) && !errors.ToString().Contains(
                                FormatErrorFields(TransformationRulesFailedFields[i], DataLoader.Default.ReportError_Transformation)))
                            {
                                if (errors.Length > 0)
                                {
                                    errors.AppendLine();
                                }
                                errors.Append(FormatErrorFields(TransformationRulesFailedFields[i], DataLoader.Default.ReportError_Transformation));
                            }
                            else if (!rule.Key && rule.Value.Contains(DataLoader.Default.ReportError_Transformation_Effectivity) &&
                                !errors.ToString().Contains(FormatErrorFields(TransformationRulesFailedFields[i], DataLoader.Default.ReportError_Transformation_Effectivity)))
                            {
                                if (errors.Length > 0)
                                {
                                    errors.AppendLine();
                                }
                                
                                errors.Append(FormatErrorFields(TransformationRulesFailedFields[i], DataLoader.Default.ReportError_Transformation_Effectivity));
                            }
                            i++;
                        }
                    }

                    if (MandatoryFieldsRules.Exists(r => !r.Key))
                    {
                        i = 0;
                        foreach (var rule in MandatoryFieldsRules)
                        {
                            if (!rule.Key && !errors.ToString().Contains(MandatoryFieldsRulesFailedFields[i]) &&
                                !errors.ToString().Contains(string.Format("{0}: {1}", MandatoryFieldsRulesFailedFields[i],
                                    DataLoader.Default.ReportError_Mandatory)))
                            {
                                if (errors.Length > 0)
                                {
                                    errors.AppendLine();
                                }
                                errors.AppendFormat("{0}: {1}", MandatoryFieldsRulesFailedFields[i],
                                    DataLoader.Default.ReportError_Mandatory);
                            }
                            i++;
                        }
                    }
                    if (FieldsLengthsRules.Exists(r => !r.Key))
                    {
                        i = 0;
                        foreach (var rule in FieldsLengthsRules)
                        {
                            if (!rule.Key && !errors.ToString().Contains(string.Format("{0}: {1}", FieldsLengthsRulesFailedFields[i],
                                    DataLoader.Default.ReportError_InvalidFieldLength)))
                            {
                                if (errors.Length > 0)
                                {
                                    errors.AppendLine();
                                }
                                errors.AppendFormat("{0}: {1}", FieldsLengthsRulesFailedFields[i],
                                    DataLoader.Default.ReportError_InvalidFieldLength);
                            }
                            i++;
                        }
                    }
                    if (!FilesAttached)
                    {
                        if (errors.Length > 0)
                        {
                            errors.AppendLine();
                        }
                        errors.Append(DataLoader.Default.ReportError_Attachments);
                    }
                    foreach (var invalidFileName in InvalidFileNames)
                    {
                        if (errors.Length > 0 && !errors.ToString().Contains(string.Format("{0}: {1}", DataLoader.Default.ReportError_InvalidFileName, invalidFileName)))
                        {
                            errors.AppendLine();
                        }
                        errors.AppendFormat("{0}: {1}", DataLoader.Default.ReportError_InvalidFileName, invalidFileName);
                    }
                }
            }
            else
            {
                errors.Append(DataLoader.Default.ReportError_NoError);
            }
            return errors.ToString();
        }

        private string FormatErrorFields(string[] errorFields, string text)
        {
            if (errorFields == null || errorFields.Length == 0)
            {
                throw new Exception(string.Format("FormatErrorFields - no error fields for '{0}'", text));
                
            }
            string errorFieldToString = errorFields.Length > 1 ? string.Format("[{0}]", string.Join(", ", errorFields)) : errorFields[0];
            return string.Format("{0}: {1}", errorFieldToString, text);
        }
    }
}
