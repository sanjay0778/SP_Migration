﻿using BCA.DocumentMigration.SpDataLoader.NotesData;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    public class Logs
    {
        //public List<Log> LogList { get; set; }
        public ConcurrentBag<Log> LogList { get; set; } 
        public int NextExcelRow;
        private int _numerOfThreadsNotYetCompleted;

        //private static Lazy<Logs> logs = new Lazy<Logs>(() => new Logs("test"));

        public string Folder { get; set; }

        public NotesDatabases DataBase { get; set; }

        //public static Logs Instance { get { return logs.Value; } set { logs = new Lazy<Logs>(() => value); } }
        
        public Logs(string folder)
        {
            LogList = new ConcurrentBag<Log>();//new List<Log>();
            NextExcelRow = DataLoader.Default.DataExtractHeaderRow + 1;
            this.Folder = folder;          
        }
        public void Reset()
        {
            if (LogList.Count > 0 || NextExcelRow != DataLoader.Default.DataExtractHeaderRow + 1)
            {
                LogList = new ConcurrentBag<Log>();//new List<Log>();
                NextExcelRow = DataLoader.Default.DataExtractHeaderRow + 1;
            }
        }
        public bool AddLog(string uId)
        {
            Stopwatch sw = Stopwatch.StartNew();
            if (!this.Contains(uId))
            {
                LogList.Add(new Log(uId, NextExcelRow));
                NextExcelRow++;
                sw.Stop();
                //TraceFile.WriteLine(true, "Logs Timer - AddLog: {0}", sw.ElapsedMilliseconds);
                return true;
            }
            else
            {
                //TraceFile.WriteLine(true, "Duplicate - Log already contains UNID {0}", uId);
                sw.Stop();
                //TraceFile.WriteLine(true, "Logs Timer - AddLog: {0}", sw.ElapsedMilliseconds);
                return false;
            }
        }
        internal bool Contains(string id)
        {
            //int matchCount = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).Count();
            //return matchCount > 0;
            return LogList.Any(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase));
        }
        public Log GetLog(string id)
        {
            Log log = LogList.FirstOrDefault<Log>(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase));

            if (log != null)
            {
                TraceFile.WriteLine(true, "GetLog - UNID {0} found in logs", id);
            }
            else
            {
                TraceFile.WriteLine(true, "GetLog Error - UNID {0} not found in logs", id);
            }
            return log;
        }
        //public void AddNotesAttributes(string id, Dictionary<string, string> attributes)
        //{
        //    Stopwatch sw = Stopwatch.StartNew();
        //    Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

        //    if (log != null)
        //    {
        //        log.NotesAttributes = attributes;
        //    }
        //    else
        //    {                
        //        TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);                
        //    }
        //    sw.Stop();
        //    //TraceFile.WriteLine(true, "Logs Timer - AddNotesAttributes: {0}", sw.ElapsedMilliseconds);
        //}
        public bool PassedValidation(string id)
        {
            Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

            return (log != null ? log.Success : false);
        }
        public void AddSharePointAttributes(string id, Dictionary<string, string> attributes)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

            if (log != null)
            {
                log.SharePointAttributes = attributes;
            }
            else
            {                
                TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);                
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddSharePointAttributes: {0}", sw.ElapsedMilliseconds);
        }
        //public void AddFilteringRule(string id, bool success, string text, List<String> notesFields = null)
        //{
        //    if (success)
        //    {
        //        return;
        //    }
        //    Stopwatch sw = Stopwatch.StartNew();
        //    Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

        //    if (log != null)
        //    {
        //        log.FilteringRules.Add(new KeyValuePair<bool, string>(success, text));
        //        if (notesFields != null)
        //        {
        //            foreach (var notesField in notesFields)
        //            {
        //                log.FilteringRulesFailedFields.Add(notesField);
        //            }
        //        }
        //        //else
        //        //{
        //        //    log.FilteringRulesFailedFields.Add(string.Empty);
        //        //}

        //        if (!success && log.Success)
        //        {
        //            log.Success = false;
        //        }
        //    }
        //    else
        //    {
        //        TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);
        //    }
        //    sw.Stop();
        //    //TraceFile.WriteLine(true, "Logs Timer - AddFilteringRule: {0}", sw.ElapsedMilliseconds);
        //}
        //public void AddTransformationRule(string id, bool success, string text, string notesField = "")
        //{
        //    if (success)
        //    {
        //        return;
        //    }
        //    Stopwatch sw = Stopwatch.StartNew();
        //    Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

        //    if (log != null)
        //    {
        //        log.TransformationRules.Add(new KeyValuePair<bool, string>(success, text));
        //        //log.TransformationRulesFailedFields.Add(success ? string.Empty : notesField);
        //        log.TransformationRulesFailedFields.Add(notesField);
        //        if (!success && log.Success)
        //        {
        //            log.Success = false;
        //        }
        //    }
        //    else
        //    {
        //        TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);
        //    }
        //    sw.Stop();
        //    //TraceFile.WriteLine(true, "Logs Timer - AddTransformationRule: {0}", sw.ElapsedMilliseconds);
        //}
        public void AddMandatoryFieldsRule(string id, bool success, string text, string notesField = "")
        {
            if (success)
            {
                return;
            }
            Stopwatch sw = Stopwatch.StartNew();
            Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

            if (log != null)
            {
                log.MandatoryFieldsRules.Add(new KeyValuePair<bool, string>(success, text));
                log.MandatoryFieldsRulesFailedFields.Add(notesField);
                //log.MandatoryFieldsRulesFailedFields.Add(success ? string.Empty : notesField);
                if (!success && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddMandatoryFieldsRule: {0}", sw.ElapsedMilliseconds);
        }
        public void AddFieldsLengthsRule(string id, bool success, string text, string notesField = "")
        {
            if (success)
            {
                return;
            }
            Stopwatch sw = Stopwatch.StartNew();
            Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

            if (log != null)
            {
                log.FieldsLengthsRules.Add(new KeyValuePair<bool, string>(success, text));
                log.FieldsLengthsRulesFailedFields.Add(notesField);
                //log.FieldsLengthsRulesFailedFields.Add(success ? string.Empty : notesField);
                if (!success && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddFieldsLengthsRule: {0}", sw.ElapsedMilliseconds);
        }
        public void AddTypes(string id, string docGroup, string docType)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();
            if (log != null)
            {
                log.DocumentGroup = docGroup;
                log.DocumentType = docType;
            }
            else
            {
                TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddTypes: {0}", sw.ElapsedMilliseconds);
        }
        internal void AddInvalidFileName(string id, string fileName)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();

            if (log != null)
            {
                log.InvalidFileNames.Add(fileName);
                if (log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddInvalidFileName: {0}", sw.ElapsedMilliseconds);
        }
        public void AddFilesAttached(string id, bool filesAttached)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Log log = LogList.Where(l => l.Uid.Equals(id, StringComparison.OrdinalIgnoreCase)).First<Log>();
            if (log != null)
            {
                log.FilesAttached = filesAttached;

                if (!filesAttached && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine(true, "Error - UNID {0} not found in log", id);
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddFilesAttached: {0}", sw.ElapsedMilliseconds);
        }
        public string PrintGeneralStats()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Total items in the Excel Report: {0}\n", LogList.Count);
            sb.AppendFormat("Remaining items after filtering rules: {0}\n", LogList.Where(l => l.TransformationRules.Count > 0).Count());
            sb.AppendFormat("Remaining items after all validations: {0}\n", LogList.Where(l => l.Success).Count());
            return sb.ToString();
        }

        internal List<string> GetNotesHeaders(bool validationTab = false)
        {
            List<string> headers = LogList.Where(l => l.NotesAttributes != null && l.NotesAttributes.Count > 0).First<Log>()
                                                 .NotesAttributes.Keys.Where(a => GetUsedNotesFields().Contains(a)).ToList();
            headers.Insert(0, validationTab ? "Validation" :"Status Reason");
            headers.Insert(0, "Migration Status");
            return headers;
        }
        internal List<string> GetSharePointHeaders()
        {
            List<string> headers = LogList.Where(l =>l.SharePointAttributes != null &&
                                                 l.SharePointAttributes.Count > 0).First<Log>().SharePointAttributes.Keys.ToList();
            headers.Insert(0, "Migration Status");
            return headers;
        }

        public List<List<string>> GetNotesRows(bool success)
        {
            List<List<string>> result = new List<List<string>>();
            foreach (var log in LogList.Where(l => l.Success == success))
            {
                result.Add(log.NotesAttributes.Values.ToList());
            }
            return result;
        }
        //public List<List<string>> GetNotesRows(out List<List<string>> errorFields)
        //{
        //    errorFields = new List<List<string>>();
        //    List<List<string>> result = new List<List<string>>();
        //    List<string> currentAttributes = null;
        //    List<string> currentErrorFields = null;
        //    foreach (var log in LogList.Where(l => l.NotesAttributes != null &&
        //                                         l.NotesAttributes.Count > 0))
        //    {

        //        currentAttributes = (log.NotesAttributes.Where(a => GetUsedNotesFields().Contains(a.Key))
        //                             .ToDictionary(x => x.Key, x => x.Value)).Values.ToList();
        //        currentAttributes.Insert(0, log.GetErrors());
        //        currentAttributes.Insert(0, log.GetResult());
        //        result.Add(currentAttributes);

        //        currentErrorFields = new List<string>();
        //        foreach (var failedField in log.FilteringRulesFailedFields)
        //        {
        //            currentErrorFields.AddRange(failedField);
        //        }
        //        foreach (var failedField in log.TransformationRulesFailedFields)
        //        {
        //            currentErrorFields.AddRange(failedField);
        //        }
        //        //currentErrorFields.AddRange(log.FilteringRulesFailedFields);
        //        //currentErrorFields.AddRange(log.TransformationRulesFailedFields);
        //        currentErrorFields.AddRange(log.MandatoryFieldsRulesFailedFields);
        //        currentErrorFields.AddRange(log.FieldsLengthsRulesFailedFields);
        //        errorFields.Add(currentErrorFields);
        //    }
        //    return result;
        //}
        public List<List<string>> GetSharePointRows()
        {
            List<List<string>> result = new List<List<string>>();
            List<string> currentAttributes = null;
            foreach (var log in LogList.Where(l => l.SharePointAttributes != null && l.SharePointAttributes.Count > 0))
            {
                currentAttributes = log.SharePointAttributes.Values.ToList();
                currentAttributes.Insert(0, log.GetResult());
                result.Add(currentAttributes);
            }
            return result;
        }

        /// <summary>
        /// Fills notes rows and Sharepoint rows
        /// </summary>
        /// <param name="notesRows"></param>
        /// <param name="sharepointRows"></param>
        /// <param name="effectivityValidationRows"></param>
        /// <param name="ataValidationRows"></param>
        public void GetNotesAndSharepointRows(out ConcurrentBag<NotesRow> notesRows, out ConcurrentBag<List<string>> sharepointRows,
            out ConcurrentBag<NotesRow> effectivityValidationRows, out ConcurrentBag<NotesRow> ataValidationRows)
        {
            ataValidationRows = null;
            effectivityValidationRows = null;
            ConcurrentBag<NotesRow> tempNotesRows = new ConcurrentBag<NotesRow>();
            ConcurrentBag<List<string>> tempSharepointRows = new ConcurrentBag<List<string>>();
            ConcurrentBag<NotesRow> tempEffectivityValidationRows = new ConcurrentBag<NotesRow>();
            ConcurrentBag<NotesRow> tempAtaValidationRows = new ConcurrentBag<NotesRow>();

            AutoResetEvent threadEvent = new AutoResetEvent(false);
            _numerOfThreadsNotYetCompleted = LogList.Count;

            int i = 0;
            foreach (var log in LogList)
            {
                ThreadPool.QueueUserWorkItem(delegate (object o)
                {
                    List<string> currentAttributes;
                    List<string> currentAttributesEffectivity;
                    List<string> currentAttributesAta;
                    if (log.SharePointAttributes != null && log.SharePointAttributes.Count > 0)
                    {
                        currentAttributes = log.SharePointAttributes.Values.ToList();
                        currentAttributes.Insert(0, log.GetResult());
                        tempSharepointRows.Add(currentAttributes);
                    }

                    if (log.NotesAttributes != null &&
                        log.NotesAttributes.Count > 0)
                    {                        
                        List<string> currentErrorFields = new List<string>();

                        currentAttributes = (log.NotesAttributes.Where(a => GetUsedNotesFields().Contains(a.Key))
                                             .ToDictionary(x => x.Key, x => x.Value)).Values.ToList();
                        currentAttributes.Insert(0, log.GetErrors());
                        currentAttributes.Insert(0, log.GetResult());

                        //currentErrorFields.AddRange(log.FilteringRulesFailedFields);
                        //currentErrorFields.AddRange(log.TransformationRulesFailedFields);

                        foreach (var failedField in log.FilteringRulesFailedFields)
                        {
                            currentErrorFields.AddRange(failedField);
                        }
                        foreach (var failedField in log.TransformationRulesFailedFields)
                        {
                            currentErrorFields.AddRange(failedField);
                        }

                        currentErrorFields.AddRange(log.MandatoryFieldsRulesFailedFields);
                        currentErrorFields.AddRange(log.FieldsLengthsRulesFailedFields);

                        tempNotesRows.Add(new NotesRow(currentAttributes, currentErrorFields));

                        if (!string.IsNullOrWhiteSpace(log.EmptyEffectivityModels))
                        {
                            currentAttributesEffectivity = new List<string>(currentAttributes);
                            currentAttributesEffectivity[1] = log.EmptyEffectivityModels;
                            tempEffectivityValidationRows.Add(new NotesRow(currentAttributesEffectivity, null));
                        }
                        if (!string.IsNullOrWhiteSpace(log.FaultyAtas))
                        {
                            currentAttributesAta = new List<string>(currentAttributes);
                            currentAttributesAta[1] = log.FaultyAtas;
                            tempAtaValidationRows.Add(new NotesRow(currentAttributesAta, null));
                        }
                    }

                    //TraceFile.WriteLine(true, "Thread number: {0}", (int)o);

                    if (Interlocked.Decrement(ref _numerOfThreadsNotYetCompleted) == 0)
                    {
                        threadEvent.Set();
                    }
                    //HelperClass.FreeMemory();
                }, i);
                i++;
            }
            threadEvent.WaitOne();

            notesRows = tempNotesRows;
            sharepointRows = tempSharepointRows;
            effectivityValidationRows = tempEffectivityValidationRows;
            ataValidationRows = tempAtaValidationRows;
        }

        internal void PrintGeneralStats(out int totalRecords, out int exclusions, out int successes, out int failures)
        {
            totalRecords = LogList.Count;
            exclusions = LogList.Where(l => l.FilteringRules.Count > 0).Count();
            successes = LogList.Where(l => l.Success).Count();
            failures = LogList.Where(l => !l.Success).Count() - exclusions;
        }
        internal HashSet<string> GetUsedNotesFields()
        {
            return HelperClass.UsedNotesFields;
        }
        public void AddNotesAttributes(Log log, Dictionary<string, string> attributes)
        {
            Stopwatch sw = Stopwatch.StartNew();

            if (log != null)
            {
                log.NotesAttributes = attributes;
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddNotesAttributes: {0}", sw.ElapsedMilliseconds);
        }
        public void AddSharePointAttributes(Log log, Dictionary<string, string> attributes)
        {
            Stopwatch sw = Stopwatch.StartNew();

            if (log != null)
            {
                log.SharePointAttributes = attributes;
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddSharePointAttributes: {0}", sw.ElapsedMilliseconds);
        }
        public void AddFilteringRule(Log log, bool success, string text, List<String> notesFields = null)
        {
            if (success)
            {
                return;
            }
            Stopwatch sw = Stopwatch.StartNew();

            if (log != null)
            {
                log.FilteringRules.Add(new KeyValuePair<bool, string>(success, text));
                if (notesFields != null)
                {
                    log.FilteringRulesFailedFields.Add(notesFields.ToArray());
                }

                if (!success && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddFilteringRule: {0}", sw.ElapsedMilliseconds);
        }
        public void AddTransformationRule(Log log, bool success, string text, string[] notesFields = null)
        {
            if (success)
            {
                return;
            }
            Stopwatch sw = Stopwatch.StartNew();

            if (log != null)
            {
                log.TransformationRules.Add(new KeyValuePair<bool, string>(success, text));
                //log.TransformationRulesFailedFields.Add(success ? string.Empty : notesField);
                if (notesFields != null)
                {
                    log.TransformationRulesFailedFields.Add(notesFields);
                }
                if (!success && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddTransformationRule: {0}", sw.ElapsedMilliseconds);
        }
        public void AddMandatoryFieldsRule(Log log, bool success, string text, string notesField = "")
        {
            if (success)
            {
                return;
            }
            Stopwatch sw = Stopwatch.StartNew();
            if (log != null)
            {
                log.MandatoryFieldsRules.Add(new KeyValuePair<bool, string>(success, text));
                log.MandatoryFieldsRulesFailedFields.Add(notesField);
                //log.MandatoryFieldsRulesFailedFields.Add(success ? string.Empty : notesField);
                if (!success && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddMandatoryFieldsRule: {0}", sw.ElapsedMilliseconds);
        }
        public void AddFieldsLengthsRule(Log log, bool success, string text, string notesField = "")
        {
            if (success)
            {
                return;
            }

            Stopwatch sw = Stopwatch.StartNew();
            if (log != null)
            {
                log.FieldsLengthsRules.Add(new KeyValuePair<bool, string>(success, text));
                log.FieldsLengthsRulesFailedFields.Add(notesField);
                //log.FieldsLengthsRulesFailedFields.Add(success ? string.Empty : notesField);
                if (!success && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddFieldsLengthsRule: {0}", sw.ElapsedMilliseconds);
        }
        public void AddTypes(Log log, string docGroup, string docType)
        {
            Stopwatch sw = Stopwatch.StartNew();
            if (log != null)
            {
                log.DocumentGroup = docGroup;
                log.DocumentType = docType;
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddTypes: {0}", sw.ElapsedMilliseconds);
        }
        internal void AddInvalidFileName(Log log, string fileName)
        {
            Stopwatch sw = Stopwatch.StartNew();
            if (log != null)
            {
                log.InvalidFileNames.Add(fileName);
                if (log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddInvalidFileName: {0}", sw.ElapsedMilliseconds);
        }
        public void AddFilesAttached(Log log, bool filesAttached)
        {
            Stopwatch sw = Stopwatch.StartNew();
            if (log != null)
            {
                log.FilesAttached = filesAttached;

                if (!filesAttached && log.Success)
                {
                    log.Success = false;
                }
            }
            else
            {
                TraceFile.WriteLine("Log is null");
            }
            sw.Stop();
            //TraceFile.WriteLine(true, "Logs Timer - AddFilesAttached: {0}", sw.ElapsedMilliseconds);
        }
    }
}
