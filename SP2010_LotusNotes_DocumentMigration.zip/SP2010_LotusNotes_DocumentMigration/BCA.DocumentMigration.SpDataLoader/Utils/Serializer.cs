﻿using MsgPack.Serialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    public static class Serializer
    {
        public static void Serialize<T>(T thisObj, string filePath)
        {
            var serializer = MessagePackSerializer.Get<T>();

            using (var byteStream = new MemoryStream())
            {
                serializer.Pack(byteStream, thisObj);
                File.WriteAllBytes(filePath, byteStream.ToArray());
            }
        }

        public static T Deserialize<T>(string filePath)
        {
            var serializer = MessagePackSerializer.Get<T>();
            using (var byteStream = new MemoryStream(File.ReadAllBytes(filePath)))
            {
                return serializer.Unpack(byteStream);
            }
        }
    }
}
