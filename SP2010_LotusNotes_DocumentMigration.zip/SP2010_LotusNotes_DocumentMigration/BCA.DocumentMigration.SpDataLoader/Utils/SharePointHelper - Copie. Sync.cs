﻿using BCA.DocumentMigration.SpDataLoader.SharepointData;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    public static class SharePointHelper
    {
        /// <summary>
        /// Uploads the specified file to a SharePoint site
        /// </summary>
        /// <param name="context">SharePoint Client Context</param>
        /// <param name="listTitle">List Title</param>
        /// <param name="fileName">File Name</param>
        private static void UploadFile(ClientContext context, string listTitle, string fileName)
        {
            using (var fs = new FileStream(fileName, FileMode.Open))
            {
                var fi = new FileInfo(fileName);
                var list = context.Web.Lists.GetByTitle(listTitle);
                context.Load(list.RootFolder);
                context.ExecuteQuery();
                var fileUrl = String.Format("{0}/{1}", list.RootFolder.ServerRelativeUrl, fi.Name);

                Microsoft.SharePoint.Client.File.SaveBinaryDirect(context, fileUrl, fs, true);
            }
        }

        private static bool UploadFile(ClientContext context, Folder folder, string fullFilePath, string cleansedName)
        {
            Stopwatch sw = Stopwatch.StartNew();
            bool result = true;
            try
            {
                using (var fs = new FileStream(fullFilePath, FileMode.Open))
                {
                    //var fi = new FileInfo(fullFilePath);
                    //var list = context.Web.Lists.GetByTitle(listTitle);
                    context.Load(folder, f => f.ServerRelativeUrl);
                    context.ExecuteQuery();
                    //var fileUrl = String.Format("{0}/{1}", folder.ServerRelativeUrl, fi.Name);
                    var fileUrl = String.Format("{0}/{1}", folder.ServerRelativeUrl, cleansedName);
                    Microsoft.SharePoint.Client.File.SaveBinaryDirect(context, fileUrl, fs, true);
                }
            }
            catch (Exception e)
            {

                TraceFile.WriteLine("failed to load file '{0}'", fullFilePath);
                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                result = false;
            }
            sw.Stop();
            TraceFile.WriteLine(true, "File upload duration: {0}", sw.Elapsed.TotalMilliseconds);
            return result;
        }

        public static CamlQuery CreateAllFilesQuery()
        {
            var qry = new CamlQuery();
            //qry.ViewXml = "<View Scope=\"RecursiveAll\"><Query><Where><Eq><FieldRef Name=\"FSObjType\" /><Value Type=\"Integer\">0</Value></Eq></Where></Query></View>";
            qry.ViewXml = "<Query><Where><Eq><FieldRef Name=\"FSObjType\" /><Value Type=\"Integer\">0</Value></Eq></Where></Query>";
            return qry;
        }
        public static CamlQuery CreateFolderByDocumentIDQuery(string documentID, string contentTypeId)
        {
            var qry = new CamlQuery();
            qry.ViewXml = string.Format("<View Scope=\"RecursiveAll\"><Query><And><Where><Eq><FieldRef Name=\"{0}\" /><Value Type=\"Text\">{1}</Value></Eq><Eq><FieldRef Name=\"ContentTypeId\" /><Value Type=\"ContentTypeId\">{2}</Value></Eq></And></Where></Query></View>", DataLoader.Default.SharepointDocumentIDField, documentID, contentTypeId);
            return qry;
        }

        public static CamlQuery CreateAllFoldersQuery()
        {
            var qry = new CamlQuery();
            qry.ViewXml = "<Query><Where><Eq><FieldRef Name=\"FSObjType\" /><Value Type=\"Integer\">1</Value></Eq></Where></Query>";
            return qry;
        }

        public static bool IsDocumentSet(this SPListItem item)
        {
            bool documentSetItem = false;
            Microsoft.Office.DocumentManagement.DocumentSets.DocumentSet documentSet = null;

            if (null != item) //&& item.IsFolder())
            {
                documentSet = Microsoft.Office.DocumentManagement.DocumentSets.DocumentSet.GetDocumentSet(item.Folder);

                if (null != documentSet)
                    documentSetItem = true;
            }
            return documentSetItem;
        }

        //public static void UpdateFolderProperties(ClientContext context, Folder folder, Dictionary<string, object> folderProperties)
        //{
        //    ListItem updateFileListItem = folder.ListItemAllFields;

        //    LoadContext(context, updateFileListItem);

        //    foreach (var folderProperty in folderProperties)
        //    {
        //        TraceFile.WriteLine("Adding {0} - {1}", folderProperty.Key, folderProperty.Value);
        //        updateFileListItem[folderProperty.Key] = folderProperty.Value;
        //    }

        //    updateFileListItem.Update();

        //    context.ExecuteQuery();

        //    TraceFile.WriteLine("Executed Query to update fields");
        //}

        public static bool UpdateFileProperties(ClientContext context, String serverRelativeUrl, Dictionary<string, object> fileProperties)
        {
            Stopwatch sw = Stopwatch.StartNew();
            bool result = true;
            try
            {
                TraceFile.WriteLine("Entering UpdateFileProperties for '{0}'", serverRelativeUrl);
                // Update the Metadata for the uploaded file in to the Document Set
                Microsoft.SharePoint.Client.File oFile = context.Web.GetFileByServerRelativeUrl(serverRelativeUrl);
                LoadContext(context, oFile);
                //oFile.ListItemAllFields["Migrated"] = true;
                //oFile.CheckOut();
                ListItem updateFileListItem = oFile.ListItemAllFields;

                LoadContext(context, updateFileListItem);

                //foreach (var property in updateFileListItem.FieldValues)
                //{
                //    TraceFile.WriteLine("Current field '{0}' - value '{1}'", property.Key, property.Value);
                //}

                foreach (var fileProperty in fileProperties)
                {
                    TraceFile.WriteLine("Adding {0} - {1}", fileProperty.Key, fileProperty.Value);
                    if (updateFileListItem.FieldValues.ContainsKey(fileProperty.Key))
                    {
                        TraceFile.WriteLine("This property is available. Current value: '{0}' - New value: {1}", updateFileListItem[fileProperty.Key], fileProperty.Value);
                        updateFileListItem[fileProperty.Key] = fileProperty.Value;//.ToString();   
                    }
                    else
                    {
                        TraceFile.WriteLine("This property is not available");
                    }


                }

                //updateFileListItem["Effectivity"] = "Challenger::855::All";

                updateFileListItem.Update();

                context.ExecuteQuery();

                TraceFile.WriteLine("Executed Query to update fields");

                //updateFileListItem["AircraftFamily"] = "Challenger";
                //updateFileListItem["AircraftModel"] = 1;
                //updateFileListItem["Effectivity"] = "Challenger::850::All";
                //updateFileListItem["Description"] = "Test";
                //updateFileListItem.Update();
                //oFile.CheckIn("", CheckinType.OverwriteCheckIn);

            }
            catch (Exception e)
            {

                TraceFile.WriteLine("Error while updating file properties for '{0}'", serverRelativeUrl);
                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                result = false;
            }
            sw.Stop();
            TraceFile.WriteLine(true, "File properties update duration: {0}", sw.Elapsed.TotalMilliseconds);
            return result;
        }

        public static void LoadContext(ClientContext context, params ClientObject[] loadList)
        {

            foreach (var loadItem in loadList)
            {
                context.Load(loadItem);
            }

            context.ExecuteQuery();
        }

        //public static void GetContentTypesDetails(ClientContext context, Web web)
        //{
        //    ContentTypeCollection contentTypeCollection = web.AvailableContentTypes;
        //    context.Load(contentTypeCollection);
        //    context.ExecuteQuery();

        //    foreach (var contentType in contentTypeCollection)
        //    {
        //        TraceFile.WriteLine("Content Type List: " + contentType.Name + "---" + contentType.StringId);
        //        if (!contentType.Name.Contains("Action Register Document Set"))
        //        {
        //            continue;
        //        }
        //        FieldCollection fields = contentType.Fields;
        //        context.Load(fields);
        //        context.ExecuteQuery();
        //        foreach (var field in fields)
        //        {
        //            TraceFile.WriteLine("\t\t\t Property: " + field.Title + " --- " + field.Id + " ---- " + field.TypeAsString + " ---- " + field.TypeDisplayName + " ---- "
        //                + field.TypeShortDescription + " ---- " + field.Required);
        //            if (field is FieldLookup)
        //            {
        //                var lookupField = field as FieldLookup;
        //                TraceFile.WriteLine("\t\t\tMultiValues: {0}", lookupField.AllowMultipleValues);
        //            }
        //            //if (field is FieldLookup)
        //            //{
        //            //    TraceFile.WriteLine("We have a lookup!");
        //            //    var lookupField = field as FieldLookup;
        //            //    TraceFile.WriteLine("LookupList-LookupField: {0}-{1}-{2}-{3}-{4}-{5}", lookupField.LookupList, lookupField.LookupField, lookupField.PrimaryFieldId, lookupField.LookupWebId, lookupField.InternalName, lookupField.Title);
        //            //    //lookupField.
        //            //    if (string.IsNullOrWhiteSpace(lookupField.LookupList))
        //            //    {
        //            //        continue;
        //            //    }

        //                //    ClientContext context2 = new ClientContext(DataLoader.Default.SharepointUrlRoot);
        //                //    Web web2 = context2.Web;
        //                //    context2.Load(web2);

        //                //    var lookupList = web2.Lists.GetById(Guid.Parse(lookupField.LookupList));//web.Lists.GetById(lookupField.LookupWebId);//web.Lists.GetById(Guid.Parse(lookupField.LookupList));
        //                //                                                                           //var lookupList = web.GetList(lookupField.LookupList);
        //                //                                                                           //var lookupList = web.GetList(Guid.Parse(lookupField.LookupList));
        //                //                                                                           //var lookupList = context.LoadQuery<List>(web.Lists.Where(l => l.Id.ToString().Equals(lookupField.LookupList)).First<List>());

        //                //    // var lookupList = web.Lists[]
        //                //    TraceFile.WriteLine("Line 167");
        //                //    //Guid lulGuid = Guid.Parse(lookupField.LookupList);

        //                //    //var lookupListFirst = context.LoadQuery(web.Lists.Where(l => l.Id == lookupField.Id));
        //                //    //context.ExecuteQuery();

        //                //    // if (lookupList == null)
        //                //    // {
        //                //    //      continue;
        //                //    //  }

        //                //    try
        //                //    {
        //                //     //   context.ExecuteQuery();

        //                //     //   lookupList = lookupListFirst.First<List>();
        //                //        LoadContext(context2, lookupList);


        //                //    }
        //                //    catch (Exception)
        //                //    {
        //                //        TraceFile.WriteLine("Couldn't load list");
        //                //        continue;                            
        //                //    }
        //                //    TraceFile.WriteLine("LookupList Count: {0}", lookupList.ItemCount);
        //                //    //LoadContext(context, lookupList);
        //                //    TraceFile.WriteLine("LookupList Count: {0}", lookupList.ItemCount);

        //                //    if (lookupList.ItemCount > 0)
        //                //    {
        //                //        var qry = new CamlQuery();
        //                //        qry.ViewXml = String.Format("<Query><OrderBy><FieldRef Name='{0}'/></OrderBy></Query>", lookupField.LookupField);
        //                //        var items = lookupList.GetItems(qry);
        //                //        TraceFile.WriteLine("Line 168");
        //                //        LoadContext(context2, items);
        //                //        TraceFile.WriteLine("Line 169");
        //                //        TraceFile.WriteLine("items Count: {0}", items.Count);
        //                //        foreach (ListItem lookupListItem in items)
        //                //        {
        //                //            context2.Load(lookupListItem, luli => luli.Id);
        //                //            context2.Load(lookupListItem, luli => luli.FieldValuesAsText);
        //                //            //context.Load(lookupListItem.FieldValues);
        //                //            //context.Load(lookupListItem, luli => luli[lookupField.LookupField]);
        //                //            context2.ExecuteQuery();
        //                //            TraceFile.WriteLine("Line 170");
        //                //            TraceFile.WriteLine("Lookup Value {0}-{1}", lookupListItem.Id, lookupListItem.FieldValuesAsText);//, lookupListItem[lookupField.LookupField].ToString());
        //                //            foreach (var value in lookupListItem.FieldValues)
        //                //            {
        //                //                TraceFile.WriteLine("Name-Value: {0}-{1}", value.Key, value.Value);
        //                //            }
        //                //        }


        //                //    }
        //                //    // var query = new SPQuery();

        //                //    //query.Query = String.Format("<OrderBy><FieldRef Name='{0}'/></OrderBy>", lookupField.LookupField);

        //                //    //foreach (SPListItem item in lookupList.GetItems(query))
        //                //    //{
        //                //    //     results.Add(new SPFieldLookupValue(item.ID, item[lookupField.LookupField].ToString()));
        //                //    //}

        //                //}
        //                //else
        //                //{
        //                //    TraceFile.WriteLine("Type is {0}", field.GetType());
        //                //}
        //        }
        //    }
        //}
        internal static void LoadDocumentSetsIntoSharepoint(IEnumerable<DocSet> docSetPartition, string filePath)
        {
            var docSetsByRelativeUrl = docSetPartition.GroupBy(ds => ds.GetRelativeParentFolderUrl());
            TraceFile.WriteLine("LoadDocumentSetsIntoSharepoint - number of groups: {0}", docSetsByRelativeUrl.Count());
            using (ClientContext context = new ClientContext(DataLoader.Default.SharepointUrl))
            {
                Web web = context.Web;
                context.Load(web);
                var lists = context.LoadQuery(web.Lists.Where(l => l.BaseType == BaseType.DocumentLibrary));                
                context.ExecuteQuery();

                foreach (var dsGroup in docSetsByRelativeUrl)
                {
                    var results = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.File>>();
                    var resultsFolder = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.Folder>>();
                    var fileProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                    var folderProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

                    Folder folder;                    
                    if (web.TryGetFolderByServerRelativeUrl(dsGroup.Key, out folder))
                    {
                        TraceFile.WriteLine("==================================== Loaded Folder");
                        //TraceFile.WriteLine("==================================== SubFolder: {0}", dsGroup.Key);
                        TraceFile.WriteLine("==================================== Folder Relative URL: {0}", folder.ServerRelativeUrl);

                        foreach (var docSet in dsGroup)
                        {
                            try
                            {
                                string documentSetUrl = null;
                                var documentSetExists = false;
                                if (LaunchConfiguration.Default.CHECK_SHAREPOINT_DUPLICATES)
                                {
                                    Folder dummyFolder;
                                    if (!web.TryGetFolderByServerRelativeUrl(string.Format("{0}/{1}", folder.ServerRelativeUrl, docSet.Name), out dummyFolder))
                                    {
                                        TraceFile.WriteLine("{0} -- {1}", docSet.Name, docSet.Uid);
                                        documentSetUrl = CreateDocumentSet(context, folder, docSet.GetDocumentSetContentTypeId(), docSet.Name);
                                        if (documentSetUrl == null)
                                        {
                                            RetryDocumentSetCreation(context, web, folder, docSet, ref documentSetUrl, ref dummyFolder);
                                        }
                                    }
                                    else
                                    {
                                        TraceFile.WriteLine("Document Set '{0}' already exists - did not create for {1}", dummyFolder.ServerRelativeUrl, docSet.Uid);
                                        documentSetExists = true;
                                        documentSetUrl = DataLoader.Default.SharepointUrlBase + dummyFolder.ServerRelativeUrl;
                                    }
                                }
                                else
                                {
                                    documentSetUrl = CreateDocumentSet(context, folder, docSet.GetDocumentSetContentTypeId(), docSet.Name);
                                    if (documentSetUrl == null)
                                    {
                                        Folder dummyFolder = null;
                                        RetryDocumentSetCreation(context, web, folder, docSet, ref documentSetUrl, ref dummyFolder);
                                    }
                                }

                                if (!string.IsNullOrWhiteSpace(documentSetUrl) && !documentSetExists)
                                {
                                    TraceFile.WriteLine("==================================== Document Group Creation Result: {0}", documentSetUrl);
                                    string documentSetServerRelativeUrl;

                                    if (documentSetUrl.Trim().StartsWith(DataLoader.Default.SharepointUrlBase, StringComparison.OrdinalIgnoreCase))
                                    {
                                        documentSetServerRelativeUrl = documentSetUrl.Trim().Remove(0, DataLoader.Default.SharepointUrlBase.Length);
                                    }
                                    else
                                    {
                                        documentSetServerRelativeUrl = documentSetUrl.Trim();
                                    }

                                    Folder docSetFolder;

                                    if (!web.TryGetFolderByServerRelativeUrl(documentSetServerRelativeUrl, out docSetFolder))
                                    {
                                        TraceFile.WriteLine("Failed to load Document Set '{0}'. Cannot proceed with setting up properties.",
                                            documentSetServerRelativeUrl);
                                        break;
                                    }

                                    if (!documentSetExists)
                                    {
                                        if (!SetDocumentSetProperties(context, docSet, docSetFolder))
                                        {
                                            RetryDocumentSetPropertiesUpdate(context, docSet, docSetFolder);
                                        }
                                    }

                                    TraceFile.WriteLine("Starting File Upload");
                                    foreach (var attachment in docSet.Attachments)
                                    {
                                        string sharepointFileName = string.IsNullOrWhiteSpace(attachment.Value) ? attachment.Key : attachment.Value;
                                        string fullFilepath = string.Format("{0}\\{1}\\{2}", filePath, docSet.Uid, attachment.Key);
                                        TraceFile.WriteLine("Loading '{0}'", fullFilepath);

                                        if (LaunchConfiguration.Default.CHECK_SHAREPOINT_DUPLICATES)
                                        {
                                            Microsoft.SharePoint.Client.File dummyFile;
                                            if (!web.TryGetFileByServerRelativeUrl(string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), out dummyFile))
                                            {
                                                if (!string.IsNullOrWhiteSpace(attachment.Value))
                                                {
                                                    TraceFile.WriteLine("Loading File '{0}' with cleansed Name '{1}'", attachment.Key, attachment.Value);
                                                }
                                                if (UploadFile(context, docSetFolder, fullFilepath, sharepointFileName))
                                                {
                                                    fileProperties.Clear();
                                                    //fileProperties.Add("ContentTypeId", docSet.GetFileContentTypeId());
                                                    fileProperties.Add("TitleOfTheDocument", docSet.TextFields["TitleOfTheDocumentSet"]);
                                                    //fileProperties.Add("Title", docSet.TextFields["TitleOfTheDocumentSet"]);
                                                    //fileProperties.Add("DescriptionOfDocument", docSet.TextFields["DocumentSetDescription"]);
                                                    if (!UpdateFileProperties(context, string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), fileProperties))
                                                    {
                                                        RetryFilePropertiesUpdate(context, docSet, string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), fileProperties);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                TraceFile.WriteLine("File '{0}' already exists", dummyFile.ServerRelativeUrl);
                                            }
                                        }
                                        else
                                        {
                                            if (!string.IsNullOrWhiteSpace(attachment.Value))
                                            {
                                                TraceFile.WriteLine("Loading File '{0}' with cleansed Name '{1}'", attachment.Key, attachment.Value);
                                            }
                                            if (UploadFile(context, docSetFolder, fullFilepath, sharepointFileName))
                                            {
                                                fileProperties.Clear();
                                                //fileProperties.Add("ContentTypeId", docSet.GetFileContentTypeId());
                                                fileProperties.Add("TitleOfTheDocument", docSet.TextFields["TitleOfTheDocumentSet"]);
                                                //fileProperties.Add("Title", docSet.TextFields["TitleOfTheDocumentSet"]);
                                                //fileProperties.Add("DescriptionOfDocument", docSet.TextFields["DocumentSetDescription"]);

                                                if (!UpdateFileProperties(context, string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), fileProperties))
                                                {
                                                    RetryFilePropertiesUpdate(context, docSet, string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), fileProperties);
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (string.IsNullOrWhiteSpace(documentSetUrl))
                                {
                                    TraceFile.WriteLine("DocumentSetUrl empty, cannot proceed further -- '{0}'", docSet.Uid);
                                }
                                else if (documentSetExists)
                                {
                                    TraceFile.WriteLine("DocumentSet already exists - skipping meta data setting and attachments upload further: '{0}' -- '{1}'",
                                        documentSetUrl, docSet.Uid);
                                }
                            }
                            catch (Exception e)
                            {

                                TraceFile.WriteLine("Unhandled Error while processing document set {0} --- skipping this document set", docSet.Uid);
                                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                            }
                        }
                    }
                    else
                    {
                        TraceFile.WriteLine("LoadDocumentSetsIntoSharepoint - Relative URL '{0}' not found", dsGroup.Key);
                    }
                }

            }

        }
        private static void RetryDocumentSetPropertiesUpdate(ClientContext context, DocSet docSet, Folder docSetFolder)
        {
            for (int i = 0; i < LaunchConfiguration.Default.SHAREPOINT_RETRIES; i++)
            {
                TraceFile.WriteLine("RetryDocumentSetPropertiesUpdate --- Retry {0} of {1} -- {2}", i + 1, LaunchConfiguration.Default.SHAREPOINT_RETRIES, docSet.Uid);
                Thread.Sleep(LaunchConfiguration.Default.SHAREPOINT_WAIT);
                if (SetDocumentSetProperties(context, docSet, docSetFolder))
                {
                    TraceFile.WriteLine("Document Set properties successfully updated upon retry: '{0}' -- {1}", docSetFolder.ServerRelativeUrl, docSet.Uid);
                    break;
                }
            }
        }
        private static void RetryFilePropertiesUpdate(ClientContext context, DocSet docSet, String serverRelativeUrl, Dictionary<string, object> fileProperties)
        {
            for (int i = 0; i < LaunchConfiguration.Default.SHAREPOINT_RETRIES; i++)
            {
                TraceFile.WriteLine("RetryFilePropertiesUpdate --- Retry {0} of {1} -- {2}", i + 1, LaunchConfiguration.Default.SHAREPOINT_RETRIES, docSet.Uid);
                Thread.Sleep(LaunchConfiguration.Default.SHAREPOINT_WAIT);
                if (UpdateFileProperties(context, serverRelativeUrl, fileProperties))
                {
                    TraceFile.WriteLine("File properties successfully updated upon retry: '{0}' -- {1}", serverRelativeUrl, docSet.Uid);
                    break;
                }
            }
        }
        private static void RetryDocumentSetCreation(ClientContext context, Web web, Folder folder, DocSet docSet, ref string documentSetUrl, ref Folder dummyFolder)
        {
            for (int i = 0; i < LaunchConfiguration.Default.SHAREPOINT_RETRIES; i++)
            {
                Thread.Sleep(LaunchConfiguration.Default.SHAREPOINT_WAIT);

                TraceFile.WriteLine("RetryDocumentSetCreation --- Retry {0} of {1} -- {2}", i + 1, LaunchConfiguration.Default.SHAREPOINT_RETRIES, docSet.Uid);
                if (web.TryGetFolderByServerRelativeUrl(string.Format("{0}/{1}", folder.ServerRelativeUrl, docSet.Name), out dummyFolder))
                {
                    documentSetUrl = DataLoader.Default.SharepointUrlBase + dummyFolder.ServerRelativeUrl;
                    TraceFile.WriteLine("CreateDocumentSet returned an error but document set was created: '{0}' -- {1}", documentSetUrl, docSet.Uid);
                    break;
                }
                else
                {
                    TraceFile.WriteLine("Calling CreateDocumentSet again -- {0}", docSet.Uid);
                    documentSetUrl = CreateDocumentSet(context, folder, docSet.GetDocumentSetContentTypeId(), docSet.Name);
                }
                if (documentSetUrl != null)
                {
                    TraceFile.WriteLine("Document Set was successfully created upon retry: '{0}' -- {1}", documentSetUrl, docSet.Uid);
                    break;
                }
            }
        }

        //internal static void LoadDocumentSetsIntoSharepoint(IEnumerable<DocSet> docSetPartition, string filePath)
        //{
        //    using (ClientContext context = new ClientContext(DataLoader.Default.SharepointUrl))
        //    {
        //        Web web = context.Web;
        //        context.Load(web);
        //        var lists = context.LoadQuery(web.Lists.Where(l => l.BaseType == BaseType.DocumentLibrary));
        //        var documentSetExists = false;
        //        context.ExecuteQuery();

        //        foreach (var docSet in docSetPartition)
        //        {
        //            var results = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.File>>();
        //            var resultsFolder = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.Folder>>();
        //            var fileProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        //            var folderProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);


        //            List list = lists.SingleOrDefault(l => l.Title.Trim().Equals(docSet.GetDocumentLibrary(), StringComparison.OrdinalIgnoreCase));
        //            if (list != null)
        //            {
        //                TraceFile.WriteLine("==================================== List Not Null");
        //                var items = list.GetItems(SharePointHelper.CreateAllFoldersQuery());

        //                context.Load(items);
        //                context.ExecuteQuery();

        //                string documentSetUrl = null;
        //                TraceFile.WriteLine("Looking for Document Group Title '{0}'", docSet.GetDocumentGroupTitle());
        //                foreach (var listItem in items)
        //                {
        //                    Folder folder = listItem.Folder;
        //                    context.Load(folder, f => f.Name);
        //                    context.Load(folder, f => f.Properties);
        //                    context.Load(folder, f => f.ServerRelativeUrl);
        //                    context.Load(folder, f => f.ListItemAllFields);
        //                    context.Load(folder, f => f.ListItemAllFields.FieldValuesAsText);
        //                    context.ExecuteQuery();
        //                    if (docSet.GetDocumentGroupTitle().Equals(folder.Name, StringComparison.OrdinalIgnoreCase))
        //                    {
        //                        TraceFile.WriteLine("==================================== Loaded Folder");
        //                        TraceFile.WriteLine("==================================== SubFolder: {0}", docSet.GetDocumentGroupTitle());
        //                        TraceFile.WriteLine("==================================== Folder Relative URL: {0}", folder.ServerRelativeUrl);
        //                        Folder dummyFolder;
        //                        if (!web.TryGetFolderByServerRelativeUrl(string.Format("{0}/{1}", folder.ServerRelativeUrl, docSet.Name), out dummyFolder))
        //                        {
        //                            documentSetUrl = CreateDocumentSet(context, folder, docSet.GetDocumentSetContentTypeId(), docSet.Name);
        //                        }
        //                        else
        //                        {
        //                            TraceFile.WriteLine("Folder '{0}' already exists", dummyFolder.ServerRelativeUrl);
        //                            documentSetExists = true;
        //                            documentSetUrl = DataLoader.Default.SharepointUrlBase + dummyFolder.ServerRelativeUrl;
        //                        }

        //                        break;
        //                    }
        //                }
        //                if (!string.IsNullOrWhiteSpace(documentSetUrl))
        //                {
        //                    TraceFile.WriteLine("==================================== Document Group Creation Result: {0}", documentSetUrl);
        //                    string documentSetServerRelativeUrl = documentSetUrl.Trim().Remove(0, DataLoader.Default.SharepointUrlBase.Length);
        //                    Folder docSetFolder = web.GetFolderByServerRelativeUrl(documentSetServerRelativeUrl);
        //                    if (!documentSetExists)
        //                    {
        //                        SetDocumentSetProperties(context, docSet, docSetFolder);
        //                    }

        //                    TraceFile.WriteLine("Starting File Upload");
        //                    foreach (var attachment in docSet.Attachments)
        //                    {
        //                        string sharepointFileName = string.IsNullOrWhiteSpace(attachment.Value) ? attachment.Key : attachment.Value;
        //                        string fullFilepath = string.Format("{0}\\{1}\\{2}", filePath, docSet.Uid, attachment.Key);
        //                        TraceFile.WriteLine("Loading '{0}'", fullFilepath);
        //                        Microsoft.SharePoint.Client.File dummyFile;
        //                        if (!web.TryGetFileByServerRelativeUrl(string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), out dummyFile))
        //                        {
        //                            if (!string.IsNullOrWhiteSpace(attachment.Value))
        //                            {
        //                                TraceFile.WriteLine("Loading File '{0}' with cleansed Name '{1}'", attachment.Key, attachment.Value);
        //                            }
        //                            UploadFile(context, docSetFolder, fullFilepath, sharepointFileName);
        //                            fileProperties.Clear();
        //                            //fileProperties.Add("ContentTypeId", docSet.GetFileContentTypeId());
        //                            fileProperties.Add("TitleOfTheDocument", docSet.TextFields["TitleOfTheDocumentSet"]);
        //                            //fileProperties.Add("Title", docSet.TextFields["TitleOfTheDocumentSet"]);
        //                            //fileProperties.Add("DescriptionOfDocument", docSet.TextFields["DocumentSetDescription"]);
        //                            UpdateFileProperties(context, string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), fileProperties);
        //                        }
        //                        else
        //                        {
        //                            TraceFile.WriteLine("File '{0}' already exists", dummyFile.ServerRelativeUrl);
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }

        //}

        //public static void SetContentTypesDetails(ClientContext context, Web web)
        //{
        //    ContentTypeCollection contentTypeCollection = web.AvailableContentTypes;
        //    context.Load(contentTypeCollection);
        //    context.ExecuteQuery();
        //    SharePointContentType sharePointContentType;
        //    SharePointField sharePointField;

        //    foreach (var contentType in contentTypeCollection)
        //    {
        //        TraceFile.WriteLine("Content Type List: " + contentType.Name + "---" + contentType.StringId);
        //        sharePointContentType = new SharePointContentType(contentType.Name, contentType.StringId);
        //        FieldCollection fields = contentType.Fields;
        //        context.Load(fields);
        //        context.ExecuteQuery();
        //        foreach (var field in fields)
        //        {
        //            TraceFile.WriteLine("\t\t\t Property: " + field.Title + " --- " + field.Id + " ---- " + field.TypeAsString);
        //            sharePointField = new SharePointField(field.Title, field.Id, field.TypeAsString, field.Required, field.InternalName);
        //            if (field is FieldLookup)
        //            {
        //                var lookupField = field as FieldLookup;

        //                Guid lookUpGuid;

        //                if (string.IsNullOrWhiteSpace(lookupField.LookupList) || !Guid.TryParse(lookupField.LookupList.Trim(), out lookUpGuid))
        //                {
        //                    TraceFile.WriteLine("\t\t\t\tIssue with lookupList: {0}", lookupField.LookupList);
        //                    continue;
        //                }

        //                using (ClientContext contextRoot = new ClientContext(DataLoader.Default.SharepointUrlRoot))
        //                {
        //                    Web webRoot = contextRoot.Web;
        //                    contextRoot.Load(webRoot);

        //                    var lookupList = webRoot.Lists.GetById(lookUpGuid);
        //                    try
        //                    {
        //                        LoadContext(contextRoot, lookupList);
        //                    }
        //                    catch (Exception)
        //                    {
        //                        TraceFile.WriteLine("\t\t\t\tCouldn't load list");
        //                        continue;
        //                    }

        //                    if (lookupField.AllowMultipleValues)
        //                    {
        //                        sharePointField.AllowMultipleValues = lookupField.AllowMultipleValues;
        //                        sharePointField.SharePointDataType = SharePointDataTypes.MultiLookup;
        //                    }
        //                    if (lookupList.ItemCount > 0)
        //                    {
        //                        var qry = new CamlQuery();
        //                        qry.ViewXml = String.Format("<Query><OrderBy><FieldRef Name='{0}'/></OrderBy></Query>", lookupField.LookupField);
        //                        var items = lookupList.GetItems(qry);
        //                        LoadContext(contextRoot, items);
        //                        foreach (ListItem lookupListItem in items)
        //                        {
        //                            contextRoot.Load(lookupListItem, l => l.Id);
        //                            contextRoot.ExecuteQuery();
        //                            sharePointField.LookUpValues.Add(lookupListItem.Id, lookupListItem.FieldValues[DataLoader.Default.LookUpValueFieldName].ToString());
        //                            TraceFile.WriteLine("\t\t\t\t\tAdding lookUp value: {0}-{1}", lookupListItem.Id, lookupListItem.FieldValues[DataLoader.Default.LookUpValueFieldName].ToString());
        //                        }
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                sharePointField.LookUpValues = null;
        //            }
        //            sharePointContentType.Fields.Add(sharePointField);
        //        }
        //        HelperClass.ContentTypes.Add(sharePointContentType);
        //    }
        //}

        public static void SetContentTypesDetails(ClientContext context, Web web, params string[] contentTypes)
        {
            ContentTypeCollection contentTypeCollection = web.AvailableContentTypes;
            context.Load(contentTypeCollection);
            context.ExecuteQuery();
            SharePointContentType sharePointContentType;
            SharePointField sharePointField;
            HashSet<string> multiLookUpFields = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            TraceFile.WriteLine("Preliminary Plain Listing of Content Types Because Mathurin Changed the Site Again");
            foreach (var contentType in contentTypeCollection)
            {
                TraceFile.WriteLine("Content Type Name: " + contentType.Name + "---" + contentType.StringId);
            }

            foreach (var contentType in contentTypeCollection.Where(ct => contentTypes.Contains(ct.Name)))
            {
                TraceFile.WriteLine("Content Type List: " + contentType.Name + "---" + contentType.StringId);
                sharePointContentType = new SharePointContentType(contentType.Name, contentType.StringId);
                FieldCollection fields = contentType.Fields;
                context.Load(fields);
                context.ExecuteQuery();
                foreach (var field in fields)
                {
                    TraceFile.WriteLine("\t\t\t Property: " + field.Title + " --- " + field.Id + " --- " + field.TypeAsString + " --- " + field.InternalName);
                    sharePointField = new SharePointField(field.Title, field.Id, field.TypeAsString, field.Required, field.InternalName);
                    //if (field.Hidden && field.Required)
                    //{
                    //    TraceFile.WriteLine("Required Hidden Field: '{0}'", field.InternalName);
                    //}
                    //if (field.Hidden && !field.Required)
                    //{
                    //    TraceFile.WriteLine("Optional Hidden Field: '{0}'", field.InternalName);
                    //}
                    if (field is FieldLookup && !HelperClass.LookUpValuesReference.ContainsKey(sharePointField.InternalName))
                    {
                        var lookupField = field as FieldLookup;

                        Guid lookUpGuid;

                        if (string.IsNullOrWhiteSpace(lookupField.LookupList) || !Guid.TryParse(lookupField.LookupList.Trim(), out lookUpGuid))
                        {
                            TraceFile.WriteLine("\t\t\t\tIssue with lookupList: {0}", lookupField.LookupList);
                            continue;
                        }
                        //TraceFile.WriteLine("LookupField Title|staticName|lookupList|LookupWebId: {0} | {1} | {2} | {3}", lookupField.Title, lookupField.StaticName, lookupField.LookupList, lookupField.LookupWebId);
                        var contextRoot = context;
                        Web webRoot = contextRoot.Web;
                        contextRoot.Load(webRoot);

                        //TraceFile.WriteLine("LookUpGuid: '{0}'", lookUpGuid);
                        var lookupList = webRoot.Lists.GetById(lookUpGuid);
                        try
                        {
                            LoadContext(contextRoot, lookupList);
                        }
                        catch (Exception)
                        {
                            TraceFile.WriteLine("\t\t\t\tCouldn't load list");
                            continue;
                        }
                        if (lookupField.AllowMultipleValues)
                        {
                            sharePointField.AllowMultipleValues = lookupField.AllowMultipleValues;
                            sharePointField.SharePointDataType = SharePointDataTypes.MultiLookup;
                            TraceFile.WriteLine("\t\t\t\tMultiLookup Found!");
                            multiLookUpFields.Add(sharePointField.InternalName);
                        }
                        if (lookupList.ItemCount > 0)
                        {
                            ExtractLookupValues(sharePointField, field, lookupField, contextRoot, lookupList);
                        }
                    }
                    else if (HelperClass.LookUpValuesReference.ContainsKey(sharePointField.InternalName))
                    {
                        TraceFile.WriteLine("Lookup field '{0}' was already added, reusing previously added values", sharePointField.InternalName);
                        sharePointField.LookUpValues = HelperClass.LookUpValuesReference[sharePointField.InternalName];
                        if (multiLookUpFields.Contains(sharePointField.InternalName))
                        {
                            TraceFile.WriteLine("Previously flagged as Multi Lookup field");
                            sharePointField.AllowMultipleValues = true;
                            sharePointField.SharePointDataType = SharePointDataTypes.MultiLookup;
                        }
                    }
                    else if (field is FieldChoice && !HelperClass.ChoiceValuesReference.ContainsKey(sharePointField.InternalName))
                    {
                        var choiceField = field as FieldChoice;
                        sharePointField.Choices = choiceField.Choices;

                        HelperClass.ChoiceValuesReference.Add(sharePointField.InternalName, sharePointField.Choices);

                        TraceFile.WriteLine("\t\t\t\t\tAdding Choice Field {0}/{1} with choice values : {2}", sharePointField.InternalName, choiceField.InternalName,
                            string.Join(" | ", sharePointField.Choices));
                    }
                    else if (HelperClass.ChoiceValuesReference.ContainsKey(sharePointField.InternalName))
                    {
                        TraceFile.WriteLine("Choice field '{0}' was already added, reusing previously added values", sharePointField.InternalName);
                        sharePointField.Choices = HelperClass.ChoiceValuesReference[sharePointField.InternalName];
                    }
                    else
                    {
                        sharePointField.LookUpValues = null;
                    }
                    sharePointContentType.Fields.Add(sharePointField);
                }
                HelperClass.ContentTypes.Add(sharePointContentType);
            }
        }

        private static void ExtractLookupValues(SharePointField sharePointField, Field field, FieldLookup lookupField, ClientContext contextRoot, List lookupList)
        {
            var qry = new CamlQuery();
            qry.ViewXml = String.Format("<Query><OrderBy><FieldRef Name='{0}'/></OrderBy></Query>", lookupField.LookupField);
            TraceFile.WriteLine("LookupFieldName: {0}", lookupField.LookupField);
            var items = lookupList.GetItems(qry);
            LoadContext(contextRoot, items);
            bool keepLooping = true;
            foreach (ListItem lookupListItem in items)
            {
                contextRoot.Load(lookupListItem, l => l.Id);
                contextRoot.Load(lookupListItem, l => l.DisplayName);
                contextRoot.ExecuteQuery();
                //if (!string.IsNullOrWhiteSpace(lookupListItem.DisplayName))
                //{
                //    TraceFile.WriteLine("Display Name is not null: '{0}'", lookupListItem.DisplayName);
                //}

                if (lookupListItem.FieldValues == null || lookupListItem.FieldValues.Count <= 0)
                {
                    TraceFile.WriteLine("FieldValues empty/null for list '{0}'", field.Title);
                }
                else
                {
                    if (keepLooping)
                    {
                        foreach (var fieldValue in lookupListItem.FieldValues)
                        {
                            TraceFile.WriteLine("\t\tFieldValue: {0} / {1}", fieldValue.Key, fieldValue.Value != null ? fieldValue.Value.ToString() : "NULL_VALUE");
                            keepLooping = false;
                        }
                    }


                    //string lookupTitleField = string.Format("{0}{1}", lookupField.InternalName, DataLoader.Default.SharepointLookUpValueTitleAppend);
                    string lookupTitleField = lookupField.LookupField;
                    //string lookupTitleField = HelperClass.LookUpFieldValueTitleMapping[lookupField.InternalName];
                    if (lookupListItem.FieldValues.ContainsKey(lookupTitleField) && lookupListItem.FieldValues[lookupTitleField] != null)
                    {
                        string valueFieldAsString = null;
                        if (lookupListItem.FieldValues[lookupTitleField] is string)
                        {
                            TraceFile.WriteLine("Field '{0}' Is string", lookupTitleField);
                            if (Constants.SharepointATAFieldsInternalNames.Contains(sharePointField.InternalName,
                                StringComparer.OrdinalIgnoreCase))
                            {
                                valueFieldAsString = HandleAtaLookups(lookupListItem, lookupTitleField,
                                  sharePointField.InternalName.Equals(Constants.SharepointSubATAFieldInternalName, StringComparison.OrdinalIgnoreCase));
                            }
                            else
                            {
                                valueFieldAsString = lookupListItem.FieldValues[lookupTitleField].ToString().Trim();
                            }
                        }
                        else if (lookupListItem.FieldValues[lookupTitleField] is Microsoft.SharePoint.Client.FieldLookupValue)
                        {
                            TraceFile.WriteLine("Field '{0}' Is FieldLookupValue", lookupTitleField);
                        }
                        else if (lookupListItem.FieldValues[lookupTitleField] is Microsoft.SharePoint.Client.FieldLookupValue[])
                        {
                            TraceFile.WriteLine("Field '{0}' Is FieldLookupValue[]", lookupTitleField);
                        }
                        sharePointField.LookUpValues.Add(lookupListItem.Id, valueFieldAsString);
                        TraceFile.WriteLine("\t\t\t\t\tAdding lookUp value: {0}-{1}", lookupListItem.Id, valueFieldAsString);
                    }
                    else
                    {
                        TraceFile.WriteLine("ERROR Processing Lookup List '{0}' - Field '{1}' was not found", lookupField.InternalName, lookupTitleField);
                    }
                }
            }
            HelperClass.LookUpValuesReference.Add(sharePointField.InternalName, sharePointField.LookUpValues);
        }

        private static string HandleAtaLookups(ListItem lookupListItem, string valueField, bool isSubAta)
        {
            string valueFieldAsString;
            string appendValue = null;

            if (!isSubAta && lookupListItem.FieldValues.ContainsKey(DataLoader.Default.SharepointInternalFamilyField) &&
                lookupListItem.FieldValues[DataLoader.Default.SharepointInternalFamilyField] != null &&
                (lookupListItem.FieldValues[DataLoader.Default.SharepointInternalFamilyField] is
                Microsoft.SharePoint.Client.FieldLookupValue || lookupListItem.FieldValues[DataLoader.Default.SharepointInternalFamilyField] is
                Microsoft.SharePoint.Client.FieldLookupValue[]))
            {
                FieldLookupValue fieldLookupValue = GetFieldLookupValue(lookupListItem.FieldValues[DataLoader.Default.SharepointInternalFamilyField]);
                appendValue = fieldLookupValue.LookupValue.Trim();
                HelperClass.MainAtaFamilyMapping.Add(lookupListItem.Id, appendValue);
                TraceFile.WriteLine("MainAtaFamilyMapping - Adding id '{0}' for main ata '{1}'", lookupListItem.Id, valueField);
            }
            else if (isSubAta && lookupListItem.FieldValues.ContainsKey(DataLoader.Default.SharepointInternalMainAtaField) &&
                lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] != null &&
                (lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] is
                Microsoft.SharePoint.Client.FieldLookupValue || lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] is
                Microsoft.SharePoint.Client.FieldLookupValue[]))
            {
                FieldLookupValue fieldLookupValue = GetFieldLookupValue(lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField]);
                if (HelperClass.MainAtaFamilyMapping.ContainsKey(fieldLookupValue.LookupId))
                {
                    appendValue = HelperClass.MainAtaFamilyMapping[fieldLookupValue.LookupId];
                    TraceFile.WriteLine("MainAtaFamilyMapping contains id '{0}' for main ata '{1}'", fieldLookupValue.LookupId, fieldLookupValue.LookupValue);
                }
                else
                {
                    TraceFile.WriteLine("MainAtaFamilyMapping does not contain id '{0}' for main ata '{1}'", fieldLookupValue.LookupId, fieldLookupValue.LookupValue);
                }
            }

                valueFieldAsString = string.Format("[{0}]{1}", appendValue, lookupListItem.FieldValues[valueField].ToString().Trim());
            return valueFieldAsString;
        }

        private static FieldLookupValue GetFieldLookupValue(object fieldValueObject)
        {
            if (fieldValueObject is Microsoft.SharePoint.Client.FieldLookupValue)
            {
                return fieldValueObject as Microsoft.SharePoint.Client.FieldLookupValue;
            }
            else if (fieldValueObject is Microsoft.SharePoint.Client.FieldLookupValue[])
            {
                var fieldLookupValues = fieldValueObject as Microsoft.SharePoint.Client.FieldLookupValue[];
                if (fieldLookupValues.Length > 0)
                {
                    if (fieldLookupValues.Length > 1)
                    {
                        TraceFile.WriteLine("GetFieldLookupValue - Warning - fieldLookupValues has size {0}", fieldLookupValues.Length);
                    }
                    return fieldLookupValues[0];
                }
            }
            return null;
        }

        //public static void CreateDocumentSet(ClientContext context, List list, String contentTypeID, String documentSetName)
        //public static void CreateDocumentSet(ClientContext context, List list, ContentTypeId contentTypeID, String documentSetName)
        //public static void CreateDocumentSet(ClientContext context, List list, string contentTypeID, String documentSetName)
        //{
        //    //ContentType ct = context.Web.ContentTypes.GetById(contentTypeID);
        //    //context.Load(ct);
        //    //context.ExecuteQuery();

        //    //Microsoft.SharePoint.Client.DocumentSet.DocumentSet.Create(context, list.RootFolder, documentSetName, ct.Id);
        //    // to optimize, build this list of all contentTypeID dynamically based on contentTYpeID as string from object
        //    ContentTypeId cti = context.Web.AvailableContentTypes.GetById(contentTypeID).Id;
        //    Microsoft.SharePoint.Client.DocumentSet.DocumentSet.Create(context, list.RootFolder, documentSetName, cti);
        //    context.ExecuteQuery();
        //}
        //public static void LoadDocumentSetIntoSharepoint(DocSet docSet, string filePath)
        //{
        //    using (ClientContext context = new ClientContext(DataLoader.Default.SharepointUrl))
        //    {
        //        Web web = context.Web;
        //        context.Load(web);

        //        var results = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.File>>();
        //        var resultsFolder = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.Folder>>();
        //        var fileProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        //        var folderProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        //        var lists = context.LoadQuery(web.Lists.Where(l => l.BaseType == BaseType.DocumentLibrary));
        //        var documentSetExists = false;
        //        context.ExecuteQuery();

        //        List list = lists.SingleOrDefault(l => l.Title.Trim().Equals(docSet.GetDocumentGroupTitle(), StringComparison.OrdinalIgnoreCase));
        //        if (list != null)
        //        {
        //            TraceFile.WriteLine("==================================== List Not Null");
        //            var items = list.GetItems(SharePointHelper.CreateAllFoldersQuery());

        //            context.Load(items);
        //            context.ExecuteQuery();
        //            //string subFolder = docSet.GetSubFolder();
        //            //var folderFirst = context.LoadQuery(items.Where(i => (string)i.Folder.Properties[DataLoader.Default.SharePointFolderNameProperty]==subFolder));
        //            //context.ExecuteQuery();
        //            //var folder = folderFirst.SingleOrDefault().Folder;

        //            string documentSetUrl = null;
        //            foreach (var listItem in items)
        //            {
        //                Folder folder = listItem.Folder;
        //                //SharePointHelper.LoadContext(context, ctTemp, folder);
        //                //context.Load(ctTemp, c => c.Name);
        //                context.Load(folder, f => f.Name);
        //                context.Load(folder, f => f.Properties);
        //                context.Load(folder, f => f.ServerRelativeUrl);
        //                context.Load(folder, f => f.ListItemAllFields);
        //                context.ExecuteQuery();
        //                if ((folder.IsObjectPropertyInstantiated("Name") && folder.Name.Equals(docSet.SubFolder, StringComparison.OrdinalIgnoreCase)) ||
        //                    (folder.Properties.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameProperty) &&
        //                    folder.Properties[DataLoader.Default.SharePointFolderNameProperty].Equals(docSet.SubFolder)) ||
        //                    (folder.ListItemAllFields.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameField) &&
        //                    folder.ListItemAllFields.FieldValues[DataLoader.Default.SharePointFolderNameField].Equals(docSet.SubFolder)) ||
        //                    (folder.ListItemAllFields.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameField2) &&
        //                    folder.ListItemAllFields.FieldValues[DataLoader.Default.SharePointFolderNameField2].Equals(docSet.SubFolder)))
        //                {
        //                    //if (folder.IsObjectPropertyInstantiated("Name"))
        //                    //{
        //                    //    TraceFile.WriteLine("==================================== Folder Name: '{0}'", folder.Name);
        //                    //}
        //                    //if (folder.Properties.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameProperty))
        //                    //{
        //                    //    TraceFile.WriteLine("==================================== Folder vti_tile: '{0}'", folder.Properties[DataLoader.Default.SharePointFolderNameProperty]);
        //                    //}

        //                    TraceFile.WriteLine("==================================== Loaded Folder");
        //                    TraceFile.WriteLine("==================================== SubFolder: {0}", docSet.SubFolder);
        //                    TraceFile.WriteLine("==================================== Folder Relative URL: {0}", folder.ServerRelativeUrl);
        //                    Folder dummyFolder;
        //                    if (!web.TryGetFolderByServerRelativeUrl(string.Format("{0}/{1}", folder.ServerRelativeUrl, docSet.Name), out dummyFolder))
        //                    {
        //                        documentSetUrl = CreateDocumentSet(context, folder, docSet.GetDocumentSetContentTypeId(), docSet.Name);
        //                    }
        //                    else
        //                    {
        //                        TraceFile.WriteLine("Folder '{0}' already exists", dummyFolder.ServerRelativeUrl);
        //                        documentSetExists = true;
        //                        documentSetUrl = DataLoader.Default.SharepointUrlBase + dummyFolder.ServerRelativeUrl;
        //                    }

        //                    break;
        //                }
        //                //else
        //                //{
        //                //    TraceFile.WriteLine("------------------------------------No Match");
        //                //    TraceFile.WriteLine("==================================== SubFolder: {0}", docSet.GetSubFolder());
        //                //    if (folder.IsObjectPropertyInstantiated("Name"))
        //                //    {
        //                //        TraceFile.WriteLine("==================================== Folder Name: '{0}'", folder.Name);
        //                //    }
        //                //    if (folder.Properties.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameProperty))
        //                //    {
        //                //        TraceFile.WriteLine("==================================== Folder vti_tile: '{0}'", folder.Properties[DataLoader.Default.SharePointFolderNameProperty]);
        //                //    }
        //                //    //TraceFile.WriteLine("Folder Attributes: ", folder.);
        //                //    if (folder.IsObjectPropertyInstantiated("Properties"))
        //                //    {
        //                //         foreach (var item in folder.Properties.FieldValues)
        //                //         {
        //                //            TraceFile.WriteLine("\tProperty: {0} - Name: {1}", item.Key, item.Value.ToString());
        //                //          }
        //                //     }
        //                //    foreach (var item in folder.ListItemAllFields.FieldValues)
        //                //    {
        //                //        TraceFile.WriteLine("\t\tListItem: {0}", item.Key);
        //                //    }
        //                //    TraceFile.WriteLine("\tTitle: {0}", folder.ListItemAllFields.FieldValues["Title"]);
        //                //}
        //            }
        //            if (!string.IsNullOrWhiteSpace(documentSetUrl))
        //            {
        //                TraceFile.WriteLine("==================================== Document Group Creation Result: {0}", documentSetUrl);
        //                string documentSetServerRelativeUrl = documentSetUrl.Trim().Remove(0, DataLoader.Default.SharepointUrlBase.Length);
        //                Folder docSetFolder = web.GetFolderByServerRelativeUrl(documentSetServerRelativeUrl);
        //                if (!documentSetExists)
        //                {
        //                    SetDocumentSetProperties(context, docSet, docSetFolder);
        //                }

        //                TraceFile.WriteLine("Starting File Upload");
        //                foreach (var attachment in docSet.Attachments)
        //                {
        //                    string attachmentName = string.IsNullOrWhiteSpace(attachment.Value) ? attachment.Key : attachment.Value;
        //                    string fullFilepath = string.Format("{0}\\{1}\\{2}", filePath, docSet.Uid, attachmentName);
        //                    TraceFile.WriteLine("Loading '{0}'", fullFilepath);
        //                    Microsoft.SharePoint.Client.File dummyFile;
        //                    if (!web.TryGetFileByServerRelativeUrl(string.Format("{0}/{1}", documentSetServerRelativeUrl, attachmentName), out dummyFile))
        //                    {
        //                        UploadFile(context, docSetFolder, fullFilepath);
        //                        fileProperties.Clear();
        //                        fileProperties.Add("ContentTypeId", docSet.GetFileContentTypeId());
        //                        UpdateFileProperties(context, string.Format("{0}/{1}", documentSetServerRelativeUrl, attachmentName), fileProperties);
        //                    }
        //                    else
        //                    {
        //                        TraceFile.WriteLine("File '{0}' already exists", dummyFile.ServerRelativeUrl);
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}

        //public static void LoadDocumentSetsIntoSharepoint(DocSet docSet, string filePath)
        //{
        //    using (ClientContext context = new ClientContext(DataLoader.Default.SharepointUrl))
        //    {
        //        Web web = context.Web;
        //        context.Load(web);

        //        var results = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.File>>();
        //        var resultsFolder = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.Folder>>();
        //        var fileProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        //        var folderProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        //        var lists = context.LoadQuery(web.Lists.Where(l => l.BaseType == BaseType.DocumentLibrary));
        //        var documentSetExists = false;
        //        context.ExecuteQuery();

        //        List list = lists.SingleOrDefault(l => l.Title.Trim().Equals(docSet.GetDocumentLibrary(), StringComparison.OrdinalIgnoreCase));
        //        if (list != null)
        //        {
        //            TraceFile.WriteLine("==================================== List Not Null");
        //            var items = list.GetItems(SharePointHelper.CreateAllFoldersQuery());

        //            context.Load(items);
        //            context.ExecuteQuery();
        //            //string subFolder = docSet.GetSubFolder();
        //            //var folderFirst = context.LoadQuery(items.Where(i => (string)i.Folder.Properties[DataLoader.Default.SharePointFolderNameProperty]==subFolder));
        //            //context.ExecuteQuery();
        //            //var folder = folderFirst.SingleOrDefault().Folder;

        //            string documentSetUrl = null;
        //            TraceFile.WriteLine("Looking for Document Group Title '{0}'", docSet.GetDocumentGroupTitle());
        //            foreach (var listItem in items)
        //            {
        //                Folder folder = listItem.Folder;
        //                //SharePointHelper.LoadContext(context, ctTemp, folder);
        //                //context.Load(ctTemp, c => c.Name);
        //                context.Load(folder, f => f.Name);
        //                context.Load(folder, f => f.Properties);
        //                context.Load(folder, f => f.ServerRelativeUrl);
        //                context.Load(folder, f => f.ListItemAllFields);
        //                context.Load(folder, f => f.ListItemAllFields.FieldValuesAsText);
        //                context.ExecuteQuery();
        //                //if ((folder.IsObjectPropertyInstantiated("Name") && folder.Name.Equals(docSet.GetDocumentGroupTitle(), StringComparison.OrdinalIgnoreCase)) ||
        //                //    (folder.Properties.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameProperty) &&
        //                //    folder.Properties[DataLoader.Default.SharePointFolderNameProperty].Equals(docSet.GetDocumentGroupTitle())) ||
        //                //    (folder.ListItemAllFields.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameField) &&
        //                //    folder.ListItemAllFields.FieldValues[DataLoader.Default.SharePointFolderNameField].Equals(docSet.GetDocumentGroupTitle())) ||
        //                //    (folder.ListItemAllFields.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameField2) &&
        //                //    folder.ListItemAllFields.FieldValues[DataLoader.Default.SharePointFolderNameField2].Equals(docSet.GetDocumentGroupTitle())))
        //                if (docSet.GetDocumentGroupTitle().Equals(folder.Name, StringComparison.OrdinalIgnoreCase))
        //                //if (folder.ListItemAllFields.FieldValues.ContainsKey("Title")
        //                //    && folder.ListItemAllFields.FieldValuesAsText["Title"].Equals(docSet.GetDocumentGroupTitle(), StringComparison.OrdinalIgnoreCase))
        //                    {
        //                    //if (folder.IsObjectPropertyInstantiated("Name"))
        //                    //{
        //                    //    TraceFile.WriteLine("==================================== Folder Name: '{0}'", folder.Name);
        //                    //}
        //                    //if (folder.Properties.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameProperty))
        //                    //{
        //                    //    TraceFile.WriteLine("==================================== Folder vti_tile: '{0}'", folder.Properties[DataLoader.Default.SharePointFolderNameProperty]);
        //                    //}

        //                    TraceFile.WriteLine("==================================== Loaded Folder");
        //                    TraceFile.WriteLine("==================================== SubFolder: {0}", docSet.GetDocumentGroupTitle());
        //                    TraceFile.WriteLine("==================================== Folder Relative URL: {0}", folder.ServerRelativeUrl);
        //                    Folder dummyFolder;
        //                    if (!web.TryGetFolderByServerRelativeUrl(string.Format("{0}/{1}", folder.ServerRelativeUrl, docSet.Name), out dummyFolder))
        //                    {
        //                        documentSetUrl = CreateDocumentSet(context, folder, docSet.GetDocumentSetContentTypeId(), docSet.Name);
        //                    }
        //                    else
        //                    {
        //                        TraceFile.WriteLine("Folder '{0}' already exists", dummyFolder.ServerRelativeUrl);
        //                        documentSetExists = true;
        //                        documentSetUrl = DataLoader.Default.SharepointUrlBase + dummyFolder.ServerRelativeUrl;
        //                    }

        //                    break;
        //                }
        //                //else
        //                //{
        //                //    TraceFile.WriteLine("------------------------------------No Match");
        //                //    //TraceFile.WriteLine("==================================== SubFolder: {0}", docSet.GetSubFolder());
        //                //    if (folder.IsObjectPropertyInstantiated("Name") || folder.Name != null)
        //                //    {
        //                //        TraceFile.WriteLine("==================================== Folder Name: '{0}'", folder.Name);
        //                //    }
        //                //    //if (folder.Properties.FieldValues.ContainsKey(DataLoader.Default.SharePointFolderNameProperty))
        //                //    //{
        //                //    //    TraceFile.WriteLine("==================================== Folder vti_tile: '{0}'", folder.Properties[DataLoader.Default.SharePointFolderNameProperty]);
        //                //    //}
        //                //    //TraceFile.WriteLine("Folder Attributes: ", folder.);
        //                //    //if (folder.IsObjectPropertyInstantiated("Properties"))
        //                //    //{
        //                //    //    foreach (var item in folder.Properties.FieldValues)
        //                //    //    {
        //                //    //        TraceFile.WriteLine("\tProperty: {0} - Name: {1}", item.Key, item.Value.ToString());
        //                //    //    }
        //                //    //}
        //                //    foreach (var item in folder.ListItemAllFields.FieldValues)
        //                //    {
        //                //        TraceFile.WriteLine("\t\tListItem: {0} / {1}", item.Key, item.Value != null ? item.Value : "Was_Null");
        //                //    }
        //                //    //TraceFile.WriteLine("\tTitle: {0}", folder.ListItemAllFields.FieldValues["Title"]);
        //                //}
        //            }
        //            if (!string.IsNullOrWhiteSpace(documentSetUrl))
        //            {
        //                TraceFile.WriteLine("==================================== Document Group Creation Result: {0}", documentSetUrl);
        //                string documentSetServerRelativeUrl = documentSetUrl.Trim().Remove(0, DataLoader.Default.SharepointUrlBase.Length);
        //                Folder docSetFolder = web.GetFolderByServerRelativeUrl(documentSetServerRelativeUrl);
        //                if (!documentSetExists)
        //                {
        //                    SetDocumentSetProperties(context, docSet, docSetFolder);
        //                }

        //                TraceFile.WriteLine("Starting File Upload");
        //                foreach (var attachment in docSet.Attachments)
        //                {
        //                    string sharepointFileName = string.IsNullOrWhiteSpace(attachment.Value) ? attachment.Key : attachment.Value;
        //                    string fullFilepath = string.Format("{0}\\{1}\\{2}", filePath, docSet.Uid, attachment.Key);
        //                    TraceFile.WriteLine("Loading '{0}'", fullFilepath);
        //                    Microsoft.SharePoint.Client.File dummyFile;
        //                    if (!web.TryGetFileByServerRelativeUrl(string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), out dummyFile))
        //                    {
        //                        if (!string.IsNullOrWhiteSpace(attachment.Value))
        //                        {
        //                            TraceFile.WriteLine("Loading File '{0}' with cleansed Name '{1}'", attachment.Key, attachment.Value);
        //                        }
        //                        UploadFile(context, docSetFolder, fullFilepath, sharepointFileName);
        //                        fileProperties.Clear();
        //                        //fileProperties.Add("ContentTypeId", docSet.GetFileContentTypeId());
        //                        fileProperties.Add("TitleOfTheDocument", docSet.TextFields["TitleOfTheDocumentSet"]);
        //                        fileProperties.Add("Title", docSet.TextFields["TitleOfTheDocumentSet"]);
        //                        fileProperties.Add("DescriptionOfDocument", docSet.TextFields["DocumentSetDescription"]);
        //                        UpdateFileProperties(context, string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), fileProperties);
        //                    }
        //                    else
        //                    {
        //                        TraceFile.WriteLine("File '{0}' already exists", dummyFile.ServerRelativeUrl);
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}
        //public static void LoadDocumentSetsIntoSharepoint(DocSet docSet, string filePath, ClientContext context)
        //{

        //    Web web = context.Web;
        //    context.Load(web);

        //    var results = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.File>>();
        //    var resultsFolder = new Dictionary<string, IEnumerable<Microsoft.SharePoint.Client.Folder>>();
        //    var fileProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        //    var folderProperties = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        //    var lists = context.LoadQuery(web.Lists.Where(l => l.BaseType == BaseType.DocumentLibrary));
        //    var documentSetExists = false;
        //    context.ExecuteQuery();

        //    List list = lists.SingleOrDefault(l => l.Title.Trim().Equals(docSet.GetDocumentLibrary(), StringComparison.OrdinalIgnoreCase));
        //    if (list != null)
        //    {
        //        TraceFile.WriteLine("==================================== List Not Null");
        //        var items = list.GetItems(SharePointHelper.CreateAllFoldersQuery());

        //        context.Load(items);
        //        context.ExecuteQuery();
        //        //string subFolder = docSet.GetSubFolder();
        //        //var folderFirst = context.LoadQuery(items.Where(i => (string)i.Folder.Properties[DataLoader.Default.SharePointFolderNameProperty]==subFolder));
        //        //context.ExecuteQuery();
        //        //var folder = folderFirst.SingleOrDefault().Folder;

        //        string documentSetUrl = null;
        //        TraceFile.WriteLine("Looking for Document Group Title '{0}'", docSet.GetDocumentGroupTitle());
        //        foreach (var listItem in items)
        //        {
        //            Folder folder = listItem.Folder;
        //            //SharePointHelper.LoadContext(context, ctTemp, folder);
        //            //context.Load(ctTemp, c => c.Name);
        //            context.Load(folder, f => f.Name);
        //            context.Load(folder, f => f.Properties);
        //            context.Load(folder, f => f.ServerRelativeUrl);
        //            context.Load(folder, f => f.ListItemAllFields);
        //            context.Load(folder, f => f.ListItemAllFields.FieldValuesAsText);
        //            context.ExecuteQuery();
        //            if (docSet.GetDocumentGroupTitle().Equals(folder.Name, StringComparison.OrdinalIgnoreCase))
        //            {

        //                TraceFile.WriteLine("==================================== Loaded Folder");
        //                TraceFile.WriteLine("==================================== SubFolder: {0}", docSet.GetDocumentGroupTitle());
        //                TraceFile.WriteLine("==================================== Folder Relative URL: {0}", folder.ServerRelativeUrl);
        //                Folder dummyFolder;
        //                if (!web.TryGetFolderByServerRelativeUrl(string.Format("{0}/{1}", folder.ServerRelativeUrl, docSet.Name), out dummyFolder))
        //                {
        //                    documentSetUrl = CreateDocumentSet(context, folder, docSet.GetDocumentSetContentTypeId(), docSet.Name);
        //                }
        //                else
        //                {
        //                    TraceFile.WriteLine("Folder '{0}' already exists", dummyFolder.ServerRelativeUrl);
        //                    documentSetExists = true;
        //                    documentSetUrl = DataLoader.Default.SharepointUrlBase + dummyFolder.ServerRelativeUrl;
        //                }

        //                break;
        //            }
        //        }
        //        if (!string.IsNullOrWhiteSpace(documentSetUrl))
        //        {
        //            TraceFile.WriteLine("==================================== Document Group Creation Result: {0}", documentSetUrl);
        //            string documentSetServerRelativeUrl = documentSetUrl.Trim().Remove(0, DataLoader.Default.SharepointUrlBase.Length);
        //            Folder docSetFolder = web.GetFolderByServerRelativeUrl(documentSetServerRelativeUrl);
        //            if (!documentSetExists)
        //            {
        //                SetDocumentSetProperties(context, docSet, docSetFolder);
        //            }

        //            TraceFile.WriteLine("Starting File Upload");
        //            foreach (var attachment in docSet.Attachments)
        //            {
        //                string sharepointFileName = string.IsNullOrWhiteSpace(attachment.Value) ? attachment.Key : attachment.Value;
        //                string fullFilepath = string.Format("{0}\\{1}\\{2}", filePath, docSet.Uid, attachment.Key);
        //                TraceFile.WriteLine("Loading '{0}'", fullFilepath);
        //                Microsoft.SharePoint.Client.File dummyFile;
        //                if (!web.TryGetFileByServerRelativeUrl(string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), out dummyFile))
        //                {
        //                    if (!string.IsNullOrWhiteSpace(attachment.Value))
        //                    {
        //                        TraceFile.WriteLine("Loading File '{0}' with cleansed Name '{1}'", attachment.Key, attachment.Value);
        //                    }
        //                    UploadFile(context, docSetFolder, fullFilepath, sharepointFileName);
        //                    fileProperties.Clear();
        //                    //fileProperties.Add("ContentTypeId", docSet.GetFileContentTypeId());
        //                    fileProperties.Add("TitleOfTheDocument", docSet.TextFields["TitleOfTheDocumentSet"]);
        //                    fileProperties.Add("Title", docSet.TextFields["TitleOfTheDocumentSet"]);
        //                    fileProperties.Add("DescriptionOfDocument", docSet.TextFields["DocumentSetDescription"]);
        //                    UpdateFileProperties(context, string.Format("{0}/{1}", documentSetServerRelativeUrl, sharepointFileName), fileProperties);
        //                }
        //                else
        //                {
        //                    TraceFile.WriteLine("File '{0}' already exists", dummyFile.ServerRelativeUrl);
        //                }
        //            }
        //        }
        //    }            
        //}

        private static bool SetDocumentSetProperties(ClientContext context, DocSet docSet, Folder folder)
        {
            Stopwatch sw = Stopwatch.StartNew();
            bool result = true;
            ListItem updateFileListItem = folder.ListItemAllFields;
            //LoadContext(context, updateFileListItem);
            try
            {
                TraceFile.WriteLine("Setting Document Set Text Properties");
                foreach (var field in docSet.TextFields)
                {
                    TraceFile.WriteLine("\t\tSetting Text Property '{0}' with value '{1}'", field.Key, field.Value);
                    updateFileListItem[field.Key] = field.Value;
                }
                TraceFile.WriteLine("Setting Document Set Number Properties");
                foreach (var field in docSet.TextFields)
                {
                    TraceFile.WriteLine("\t\tSetting Number Property '{0}' with value '{1}'", field.Key, field.Value);
                    updateFileListItem[field.Key] = field.Value;
                }

                TraceFile.WriteLine("Setting Document Set Choice Properties");
                foreach (var field in docSet.ChoiceFields)
                {
                    TraceFile.WriteLine("\t\tSetting Choice Property '{0}' with value '{1}'", field.Key, field.Value);
                    updateFileListItem[field.Key] = field.Value;
                }

                TraceFile.WriteLine("Setting Document Set DateTime Properties");
                foreach (var field in docSet.DateTimeFields)
                {
                    TraceFile.WriteLine("\t\tSetting DateTime Property '{0}' with value '{1}'", field.Key, field.Value);
                    updateFileListItem[field.Key] = field.Value;
                }

                TraceFile.WriteLine("Setting Document Set Boolean Properties");
                foreach (var field in docSet.BooleanFields)
                {
                    TraceFile.WriteLine("\t\tSetting Boolean Property '{0}' with value '{1}'", field.Key, field.Value);
                    updateFileListItem[field.Key] = field.Value;
                }

                TraceFile.WriteLine("Setting Document Set Lookup Properties");
                foreach (var field in docSet.LookupFields)
                {
                    TraceFile.WriteLine("\t\tSetting Lookup Property '{0}' with value '{1}'", field.Key, field.Value);
                    updateFileListItem[field.Key] = field.Value;
                }

                TraceFile.WriteLine("Setting Document Set Multilookup Properties");

                foreach (var field in docSet.MultiLookupFields)
                {
                    FieldLookupValue[] lookupFieldCollection = new FieldLookupValue[field.Value.Length];
                    for (int i = 0; i < field.Value.Length; i++)
                    {
                        TraceFile.WriteLine("\t\tSetting Multi Lookup Property '{0}' with value '{1}'", field.Key, field.Value);
                        FieldLookupValue lookupField = new FieldLookupValue();
                        lookupField.LookupId = field.Value[i];
                        lookupFieldCollection.SetValue(lookupField, i);
                    }
                    updateFileListItem[field.Key] = lookupFieldCollection;
                }
                Stopwatch sw2 = Stopwatch.StartNew();
                updateFileListItem.Update();
                context.ExecuteQuery();
                sw2.Stop();
                TraceFile.WriteLine(true, "updateFileListItem.Update() duration: {0}", sw2.Elapsed.TotalMilliseconds);

            }
            catch (Exception e)
            {

                TraceFile.WriteLine("Error while setting properties for Document Set '{0}'", folder.ServerRelativeUrl);
                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                result = false;
            }

            TraceFile.WriteLine("Executed Query to update fields");
            sw.Stop();
            TraceFile.WriteLine(true, "Document set properties update duration: {0}", sw.Elapsed.TotalMilliseconds);
            return result;            
        }
        //private static string CreateDocumentSet(ClientContext context, Folder folder, ContentTypeId contentTypeID, string documentSetName)
        private static string CreateDocumentSet(ClientContext context, Folder folder, string contentTypeID, string documentSetName)
        {
            Stopwatch sw = Stopwatch.StartNew();
            TraceFile.WriteLine("==================================== About To Create Document Set");
            TraceFile.WriteLine("==================================== Name: {0}", documentSetName);
            // to optimize, build this list of all contentTypeID dynamically based on contentTYpeID as string from object
            // add counters
            // !!!!!!!!!!!! avoid querying that over and over and over again, cache it
            ContentTypeId cti;
            if (HelperClass.ContentTypeIds.ContainsKey(contentTypeID))
            {
                TraceFile.WriteLine("Content Type Id {0} found in cache", contentTypeID);
                cti = HelperClass.ContentTypeIds[contentTypeID];
            }
            else
            {
                ContentType ct = context.Web.AvailableContentTypes.GetById(contentTypeID);
                context.Load(ct, c => c.Id);
                context.ExecuteQuery();
                cti = ct.Id;
                HelperClass.ContentTypeIds.GetOrAdd(contentTypeID, cti);
            }
            var result = Microsoft.SharePoint.Client.DocumentSet.DocumentSet.Create(context, folder, documentSetName, cti);
            try
            {
                context.ExecuteQuery();
            }
            catch (Exception e)
            {
                TraceFile.WriteLine("Error while creating Document Set {0}/{1}", folder.ServerRelativeUrl, documentSetName);
                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                return null;
            }
            sw.Stop();
            TraceFile.WriteLine(true, "Document set creation duration: {0}", sw.Elapsed.TotalMilliseconds);
            return result.Value;
        }
        public static void ExportToSharepoint(ConcurrentQueue<DocSet> docSets, string attachmentFolder)
        {
            int counter = 0;
            int attachmentsCounter = 0;
            TraceFile.WriteLine("{0} items are ready for Sharepoint", docSets.Count(d => d.ReadyForSharePoint));
            Stopwatch sw = Stopwatch.StartNew();

            // Get the current settings.
            int minWorker, maxWorker, minIOC, maxIOC;
            ThreadPool.GetMinThreads(out minWorker, out minIOC);
            ThreadPool.GetMaxThreads(out maxWorker, out maxIOC);
            // Change the minimum number of worker threads to four, but
            // keep the old setting for minimum asynchronous I/O 
            // completion threads.
            if (ThreadPool.SetMinThreads(LaunchConfiguration.Default.MAX_SHAREPOINT_CONNECTIONS, minIOC))
            {
                TraceFile.WriteLine("Successfully changed Min Worker Threads");
            }

            AutoResetEvent threadEvent = new AutoResetEvent(false);
            int _numerOfThreadsNotYetCompleted = (LaunchConfiguration.Default.LOAD_LIMIT > 0 &&
                LaunchConfiguration.Default.LOAD_LIMIT < LaunchConfiguration.Default.MAX_SHAREPOINT_CONNECTIONS) ?
                LaunchConfiguration.Default.LOAD_LIMIT :
                LaunchConfiguration.Default.MAX_SHAREPOINT_CONNECTIONS;
            int i = 0;

            var splitDocSets = LaunchConfiguration.Default.LOAD_LIMIT <= 0 ? docSets.Where(d => d.ReadyForSharePoint).Split(LaunchConfiguration.Default.MAX_SHAREPOINT_CONNECTIONS) :
                docSets.Where(d => d.ReadyForSharePoint).Take(LaunchConfiguration.Default.LOAD_LIMIT).Split(LaunchConfiguration.Default.MAX_SHAREPOINT_CONNECTIONS);

            foreach (var docSetPartition in splitDocSets)
            {
                counter += docSetPartition.Count();
                attachmentsCounter += docSetPartition.Sum(ds => ds.Attachments.Count);
                ThreadPool.QueueUserWorkItem(delegate (object o)
                {
                    TraceFile.WriteLine(true, "Starting thread number: {0}", (int)o);

                    //TraceFile.WriteLine("Processing '{0}'", docSet.Uid);
                    try
                    {
                        SharePointHelper.LoadDocumentSetsIntoSharepoint(docSetPartition, attachmentFolder);
                    }
                    catch (Exception e)
                    {

                        TraceFile.WriteLine("Unhandled Error while loading docset partition into sharepoint --- skipping this partition");
                        TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
                    }

                    TraceFile.WriteLine(true, "Finished thread number: {0}", (int)o);

                    if (Interlocked.Decrement(ref _numerOfThreadsNotYetCompleted) == 0)
                    {
                        threadEvent.Set();
                    }
                }, i);
                i++;
            }
            threadEvent.WaitOne();
            sw.Stop();
            TraceFile.WriteLine(true, "Elapsed time for Upload of {0} document sets and {1} attachments: {2} - Migration rate: {3} attachments/minute", counter, attachmentsCounter,
                sw.Elapsed.ToString(@"dd\.hh\:mm\:ss\.ff"), HelperClass.GetMigrationRate(sw.Elapsed.TotalMilliseconds, attachmentsCounter));

            var migratedDocsets = splitDocSets.SelectMany(sd => sd).SelectMany(ds => HelperClass.ToAttachmentPath(attachmentFolder, ds.Uid, ds.Attachments)).ToArray();
            long attachmentsize = HelperClass.GetTotalAttachmentSize(migratedDocsets);
            string sizeString = HelperClass.GetBytesReadable(attachmentsize);

            TraceFile.WriteLine(true, "Total size uploaded: {0} ({1} bytes) - Migration rate: {2} mb/second", sizeString, attachmentsize,
                HelperClass.GetMigrationRateSeconds(sw.Elapsed.TotalMilliseconds, HelperClass.ConvertBytesToMegabytes(attachmentsize)));

            if (ThreadPool.SetMinThreads(minWorker, minIOC))
            {
                TraceFile.WriteLine("Successfully changed Min Worker Threads");
            }
        }
        //public static void SetContentTypesDetails(ClientContext context, Web web, params string[] contentTypes)
        //{
        //    ContentTypeCollection contentTypeCollection = web.AvailableContentTypes;
        //    context.Load(contentTypeCollection);
        //    context.ExecuteQuery();
        //    SharePointContentType sharePointContentType;
        //    SharePointField sharePointField;
        //    bool listedList = false;

        //    foreach (var contentType in contentTypeCollection.Where(ct => contentTypes.Contains(ct.Name)))
        //    //foreach (var contentType in contentTypeCollection)
        //    {
        //        TraceFile.WriteLine("Content Type List: " + contentType.Name + "---" + contentType.StringId);
        //        sharePointContentType = new SharePointContentType(contentType.Name, contentType.StringId, contentType.Id);
        //        FieldCollection fields = contentType.Fields;
        //        context.Load(fields);
        //        context.ExecuteQuery();
        //        foreach (var field in fields)
        //        {
        //            TraceFile.WriteLine("\t\t\t Property: " + field.Title + " --- " + field.Id + " --- " + field.TypeAsString + " --- " + field.InternalName);
        //            sharePointField = new SharePointField(field.Title, field.Id, field.TypeAsString, field.Required, field.InternalName);
        //            if (field is FieldLookup)
        //            {
        //                var lookupField = field as FieldLookup;

        //                Guid lookUpGuid;

        //                if (string.IsNullOrWhiteSpace(lookupField.LookupList) || !Guid.TryParse(lookupField.LookupList.Trim(), out lookUpGuid))
        //                {
        //                    TraceFile.WriteLine("\t\t\t\tIssue with lookupList: {0}", lookupField.LookupList);
        //                    continue;
        //                }

        //                TraceFile.WriteLine("LookupField Title|staticName|lookupList|LookupWebId: {0} | {1} | {2} | {3}", lookupField.Title, lookupField.StaticName, lookupField.LookupList, lookupField.LookupWebId);

        //                using (ClientContext contextRoot = new ClientContext(DataLoader.Default.SharepointUrlRoot))
        //                {
        //                    Web webRoot = contextRoot.Web;
        //                    contextRoot.Load(webRoot);

        //                    //if (!listedList)
        //                    //{
        //                    //    try
        //                    //    {
        //                    //        listedList = true;
        //                    //        TraceFile.WriteLine("***********************LISTING LISTS****************************");

        //                    //        LoadContext(contextRoot, webRoot.Lists);

        //                    //        foreach (var sharepointList in webRoot.Lists)
        //                    //        {
        //                    //            contextRoot.Load(sharepointList, l => l.Id);
        //                    //            TraceFile.WriteLine("*********************** {0} | {1} | {2}", sharepointList.Title, sharepointList.TitleResource, sharepointList.Id);
        //                    //        }
        //                    //    }
        //                    //    catch (Exception)
        //                    //    {


        //                    //    }

        //                    //}
        //                    TraceFile.WriteLine("LookUpGuid: '{0}'", lookUpGuid);
        //                    var lookupList = webRoot.Lists.GetById(lookUpGuid);
        //                    //var lookupList = webRoot.Lists.GetByTitle(field.Title);
        //                    //var lookupList = webRoot.Lists.GetByTitle(field.InternalName);
        //                    try
        //                    {
        //                        LoadContext(contextRoot, lookupList);
        //                    }
        //                    catch (Exception)
        //                    {
        //                        TraceFile.WriteLine("\t\t\t\tCouldn't load list");
        //                        continue;
        //                    }
        //                    if (lookupField.AllowMultipleValues)
        //                    {
        //                        sharePointField.AllowMultipleValues = lookupField.AllowMultipleValues;
        //                        sharePointField.SharePointDataType = SharePointDataTypes.MultiLookup;
        //                        TraceFile.WriteLine("\t\t\t\tMultiLookup Found!");
        //                    }
        //                    if (lookupList.ItemCount > 0)
        //                    {
        //                        var qry = new CamlQuery();
        //                        qry.ViewXml = String.Format("<Query><OrderBy><FieldRef Name='{0}'/></OrderBy></Query>", lookupField.LookupField);
        //                        var items = lookupList.GetItems(qry);
        //                        LoadContext(contextRoot, items);
        //                        foreach (ListItem lookupListItem in items)
        //                        {
        //                            contextRoot.Load(lookupListItem, l => l.Id);
        //                            //contextRoot.Load(lookupListItem, l => l.DisplayName);
        //                            //contextRoot.Load(lookupListItem, l => l.FieldValues);
        //                            contextRoot.ExecuteQuery();

        //                            //TraceFile.WriteLine("lookUp value DisplayName: {0}", lookupListItem.DisplayName);


        //                            if (lookupListItem.FieldValues == null || lookupListItem.FieldValues.Count <= 0)
        //                            {
        //                                TraceFile.WriteLine("FieldValues empty/null for list '{0}'", field.Title);
        //                            }
        //                            else
        //                            {
        //                                foreach (var valueField in HelperClass.LookUpListsValueFields)
        //                                {
        //                                    //lookupListItem.FieldValues.ContainsKey
        //                                    if (lookupListItem.FieldValues.ContainsKey(valueField) && lookupListItem.FieldValues[valueField] != null)
        //                                    {
        //                                        string valueFieldAsString = null;
        //                                        if (lookupListItem.FieldValues[valueField] is string)
        //                                        {
        //                                            TraceFile.WriteLine("Field '{0}' Is string", valueField);
        //                                            valueFieldAsString = lookupListItem.FieldValues[valueField].ToString().Trim();
        //                                        }
        //                                        else if (lookupListItem.FieldValues[valueField] is Microsoft.SharePoint.Client.FieldLookupValue)
        //                                        {
        //                                            var fieldLookupValue = lookupListItem.FieldValues[valueField] as Microsoft.SharePoint.Client.FieldLookupValue;
        //                                            valueFieldAsString = fieldLookupValue.LookupValue;
        //                                            TraceFile.WriteLine("Field '{0}' Is FieldLookupValue", valueField);
        //                                        }
        //                                        else if (lookupListItem.FieldValues[valueField] is Microsoft.SharePoint.Client.FieldLookupValue[])
        //                                        {
        //                                            //var fieldLookupValues = lookupListItem.FieldValues[valueField] as Microsoft.SharePoint.Client.FieldLookupValue[];
        //                                            TraceFile.WriteLine("Field '{0}' Is FieldLookupValue[]", valueField);
        //                                            //foreach (var fieldLookupValue in fieldLookupValues)
        //                                            //{
        //                                            //    TraceFile.WriteLine("{0} | {1}", fieldLookupValue.LookupId, fieldLookupValue.LookupValue);
        //                                            //}
        //                                        }
        //                                        sharePointField.LookUpValues.Add(lookupListItem.Id, valueFieldAsString);
        //                                        TraceFile.WriteLine("\t\t\t\t\tAdding lookUp value: {0}-{1}", lookupListItem.Id, valueFieldAsString);
        //                                        break;
        //                                    }
        //                                }
        //                            }
        //                            //else if (lookupListItem.FieldValues[DataLoader.Default.LookUpValueFieldName] == null)
        //                            //{
        //                            //    //TraceFile.WriteLine("Did not find field 'title' in FieldValues for '{0}', listing all values", field.Title);
        //                            //    //foreach (var item in lookupListItem.FieldValues)
        //                            //    //{
        //                            //    //    TraceFile.WriteLine("'{0}': '{1}'", item.Key, item.Value != null ? item.Value.ToString() : "WAS_NULL");
        //                            //    //}
        //                            //}
        //                            //else
        //                            //{
        //                            //    sharePointField.LookUpValues.Add(lookupListItem.Id, lookupListItem.FieldValues[DataLoader.Default.LookUpValueFieldName].ToString());
        //                            //    TraceFile.WriteLine("\t\t\t\t\tAdding lookUp value: {0}-{1}", lookupListItem.Id, lookupListItem.FieldValues[DataLoader.Default.LookUpValueFieldName].ToString());

        //                            //}
        //                        }
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                sharePointField.LookUpValues = null;
        //            }
        //            sharePointContentType.Fields.Add(sharePointField);
        //        }
        //        HelperClass.ContentTypes.Add(sharePointContentType);
        //    }
        //}

        //private static void ExtractLookupValues(SharePointField sharePointField, Field field, FieldLookup lookupField, ClientContext contextRoot, List lookupList)
        //{
        //    var qry = new CamlQuery();
        //    qry.ViewXml = String.Format("<Query><OrderBy><FieldRef Name='{0}'/></OrderBy></Query>", lookupField.LookupField);
        //    var items = lookupList.GetItems(qry);
        //    LoadContext(contextRoot, items);
        //    foreach (ListItem lookupListItem in items)
        //    {
        //        contextRoot.Load(lookupListItem, l => l.Id);
        //        contextRoot.Load(lookupListItem, l => l.DisplayName);
        //        contextRoot.ExecuteQuery();
        //        //if (!string.IsNullOrWhiteSpace(lookupListItem.DisplayName))
        //        //{
        //        //    TraceFile.WriteLine("Display Name is not null: '{0}'", lookupListItem.DisplayName);
        //        //}

        //        if (lookupListItem.FieldValues == null || lookupListItem.FieldValues.Count <= 0)
        //        {
        //            TraceFile.WriteLine("FieldValues empty/null for list '{0}'", field.Title);
        //        }
        //        else
        //        {
        //            foreach (var fieldValue in lookupListItem.FieldValues)
        //            {
        //                TraceFile.WriteLine("\t\tFieldValue: {0} / {1}", fieldValue.Key, fieldValue.Value != null ? fieldValue.Value.ToString() : "NULL_VALUE");
        //            }

        //            foreach (var valueField in HelperClass.LookUpListsValueFields)
        //            {
        //                if (lookupListItem.FieldValues.ContainsKey(valueField) && lookupListItem.FieldValues[valueField] != null)
        //                {
        //                    string valueFieldAsString = null;
        //                    if (lookupListItem.FieldValues[valueField] is string)
        //                    {
        //                        TraceFile.WriteLine("Field '{0}' Is string", valueField);
        //                        if (Constants.SharepointATAFieldsInternalNames.Contains(sharePointField.InternalName,
        //                            StringComparer.OrdinalIgnoreCase))
        //                        {
        //                            valueFieldAsString = HandleAtaLookups(lookupListItem, valueField, sharePointField.InternalName);
        //                        }
        //                        else
        //                        {
        //                            valueFieldAsString = lookupListItem.FieldValues[valueField].ToString().Trim();
        //                        }
        //                    }
        //                    else if (lookupListItem.FieldValues[valueField] is Microsoft.SharePoint.Client.FieldLookupValue)
        //                    {
        //                        TraceFile.WriteLine("Field '{0}' Is FieldLookupValue", valueField);
        //                    }
        //                    else if (lookupListItem.FieldValues[valueField] is Microsoft.SharePoint.Client.FieldLookupValue[])
        //                    {
        //                        TraceFile.WriteLine("Field '{0}' Is FieldLookupValue[]", valueField);
        //                    }
        //                    sharePointField.LookUpValues.Add(lookupListItem.Id, valueFieldAsString);
        //                    TraceFile.WriteLine("\t\t\t\t\tAdding lookUp value: {0}-{1}", lookupListItem.Id, valueFieldAsString);
        //                    break;
        //                }
        //            }
        //        }
        //    }
        //    HelperClass.LookUpValuesReference.Add(sharePointField.InternalName, sharePointField.LookUpValues);
        //}

        //private static string HandleAtaLookups(ListItem lookupListItem, string valueField, string internalName)
        //{
        //    string valueFieldAsString;
        //    string appendValue = null;

        //    if (internalName.Equals(Constants.SharepointMainATAFieldInternalName, StringComparison.OrdinalIgnoreCase) &&
        //        lookupListItem.FieldValues.ContainsKey(DataLoader.Default.SharepointInternalFamilyField) &&
        //        lookupListItem.FieldValues[DataLoader.Default.SharepointInternalFamilyField] != null &&
        //        lookupListItem.FieldValues[DataLoader.Default.SharepointInternalFamilyField] is
        //        Microsoft.SharePoint.Client.FieldLookupValue)
        //    {
        //        var fieldLookupValue = lookupListItem.FieldValues[DataLoader.Default.SharepointInternalFamilyField]
        //            as Microsoft.SharePoint.Client.FieldLookupValue;
        //        appendValue = fieldLookupValue.LookupValue.Trim();
        //        HelperClass.MainAtaFamilyMapping.Add(lookupListItem.Id, appendValue);
        //        TraceFile.WriteLine("MainAtaFamilyMapping - Adding id '{0}' for main ata '{1}'", lookupListItem.Id, valueField);
        //    }
        //    else if (internalName.Equals(Constants.SharepointSubATAFieldInternalName, StringComparison.OrdinalIgnoreCase) &&
        //        lookupListItem.FieldValues.ContainsKey(DataLoader.Default.SharepointInternalMainAtaField) &&
        //        lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] != null &&
        //        lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] is
        //        Microsoft.SharePoint.Client.FieldLookupValue)
        //    {
        //        if (LaunchConfiguration.Default.BYPASS_SUBATA_ISSUES && lookupListItem.Id >= LaunchConfiguration.Default.QSERIES_SUBATA_START_INDEX)
        //        {
        //            appendValue = DataLoader.Default.QSeriesFolder;
        //        }
        //        else
        //        {
        //            var fieldLookupValue = lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField]
        //                as Microsoft.SharePoint.Client.FieldLookupValue;
        //            if (HelperClass.MainAtaFamilyMapping.ContainsKey(fieldLookupValue.LookupId))
        //            {
        //                appendValue = HelperClass.MainAtaFamilyMapping[fieldLookupValue.LookupId];
        //                TraceFile.WriteLine("MainAtaFamilyMapping contains id '{0}' for main ata '{1}'", fieldLookupValue.LookupId, fieldLookupValue.LookupValue);
        //            }
        //            else
        //            {
        //                TraceFile.WriteLine("MainAtaFamilyMapping does not contain id '{0}' for main ata '{1}'", fieldLookupValue.LookupId, fieldLookupValue.LookupValue);
        //            }

        //        }
        //    }

        //    else if (internalName.Equals(Constants.SharepointSubATAFieldInternalName, StringComparison.OrdinalIgnoreCase) &&
        //        (!lookupListItem.FieldValues.ContainsKey(DataLoader.Default.SharepointInternalMainAtaField) ||
        //        lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] == null ||
        //        !(lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] is
        //        Microsoft.SharePoint.Client.FieldLookupValue)))
        //    {
        //        if (LaunchConfiguration.Default.BYPASS_SUBATA_ISSUES && lookupListItem.Id >= LaunchConfiguration.Default.QSERIES_SUBATA_START_INDEX)
        //        {
        //            appendValue = DataLoader.Default.QSeriesFolder;
        //        }
        //        else
        //        {
        //            TraceFile.WriteLine("Issue with subATA {0}", valueField);

        //            if (!lookupListItem.FieldValues.ContainsKey(DataLoader.Default.SharepointInternalMainAtaField))
        //            {
        //                TraceFile.WriteLine("Does not contain MainAta");
        //            }
        //            else if (lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] == null)
        //            {
        //                TraceFile.WriteLine("MainAta is null");
        //            }
        //            else if (!(lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField] is
        //            Microsoft.SharePoint.Client.FieldLookupValue))
        //            {
        //                TraceFile.WriteLine("Main Ata is not FieldLookUpValue, type is '{0}' / '{1}'",
        //                    lookupListItem.FieldValues[DataLoader.Default.SharepointInternalMainAtaField].GetType());
        //            }
        //        }
        //    }

        //    valueFieldAsString = string.Format("[{0}]{1}", appendValue, lookupListItem.FieldValues[valueField].ToString().Trim());
        //    return valueFieldAsString;
        //}
        //private static bool SetDocumentSetProperties(ClientContext context, DocSet docSet, Folder folder)
        //{
        //    Stopwatch sw = Stopwatch.StartNew();
        //    bool result = true;
        //    ListItem updateFileListItem = folder.ListItemAllFields;
        //    //LoadContext(context, updateFileListItem);
        //    //updateFileListItem["Name"] = "TestDisplayVsInternal";
        //    //updateFileListItem["FileLeafRef"] = "InternalNameTest";
        //    try
        //    {
        //        TraceFile.WriteLine("Setting Document Set Text Properties");
        //        foreach (var field in docSet.TextFields)
        //        {
        //            try
        //            {
        //                TraceFile.WriteLine("\t\tSetting Text Property '{0}' with value '{1}'", field.Key, field.Value);
        //                updateFileListItem[field.Key] = field.Value;
        //                //if (field.Key.Equals("DocumentTypeTitle", StringComparison.OrdinalIgnoreCase))
        //                //{
        //                //    TraceFile.WriteLine("\t\tSetting Text Property '{0}' with value '{1}'", field.Key, HelperClass.GetDocumentSetContentType(field.Value));
        //                //    updateFileListItem[field.Key] = HelperClass.GetDocumentSetContentType(field.Value);
        //                //}
        //                //else
        //                //{
        //                //    TraceFile.WriteLine("\t\tSetting Text Property '{0}' with value '{1}'", field.Key, field.Value);
        //                //    updateFileListItem[field.Key] = field.Value;
        //                //}                                    
        //            }
        //            catch (Exception e)
        //            {

        //                TraceFile.WriteLine("failed to set property '{0}' to value '{1}'", field.Key, field.Value);
        //                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //            }
        //        }
        //        TraceFile.WriteLine("Setting Document Set Number Properties");
        //        foreach (var field in docSet.TextFields)
        //        {
        //            try
        //            {
        //                TraceFile.WriteLine("\t\tSetting Number Property '{0}' with value '{1}'", field.Key, field.Value);
        //                updateFileListItem[field.Key] = field.Value;
        //            }
        //            catch (Exception e)
        //            {

        //                TraceFile.WriteLine("failed to set property '{0}' to value '{1}'", field.Key, field.Value);
        //                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //            }
        //        }

        //        TraceFile.WriteLine("Setting Document Set Choice Properties");
        //        foreach (var field in docSet.ChoiceFields)
        //        {
        //            try
        //            {
        //                TraceFile.WriteLine("\t\tSetting Choice Property '{0}' with value '{1}'", field.Key, field.Value);
        //                updateFileListItem[field.Key] = field.Value;
        //            }
        //            catch (Exception e)
        //            {

        //                TraceFile.WriteLine("failed to set property '{0}' to value '{1}'", field.Key, field.Value);
        //                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //            }
        //        }

        //        TraceFile.WriteLine("Setting Document Set DateTime Properties");
        //        foreach (var field in docSet.DateTimeFields)
        //        {
        //            try
        //            {
        //                TraceFile.WriteLine("\t\tSetting DateTime Property '{0}' with value '{1}'", field.Key, field.Value);
        //                updateFileListItem[field.Key] = field.Value;
        //            }
        //            catch (Exception e)
        //            {
        //                TraceFile.WriteLine("failed to set property '{0}' to value '{1}'", field.Key, field.Value);
        //                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //            }
        //        }

        //        TraceFile.WriteLine("Setting Document Set Boolean Properties");
        //        foreach (var field in docSet.BooleanFields)
        //        {
        //            try
        //            {
        //                TraceFile.WriteLine("\t\tSetting Boolean Property '{0}' with value '{1}'", field.Key, field.Value);
        //                updateFileListItem[field.Key] = field.Value;
        //            }
        //            catch (Exception e)
        //            {

        //                TraceFile.WriteLine("failed to set property '{0}' to value '{1}'", field.Key, field.Value);
        //                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //            }
        //        }

        //        TraceFile.WriteLine("Setting Document Set Lookup Properties");
        //        foreach (var field in docSet.LookupFields)
        //        {
        //            try
        //            {
        //                TraceFile.WriteLine("\t\tSetting Lookup Property '{0}' with value '{1}'", field.Key, field.Value);
        //                updateFileListItem[field.Key] = field.Value;
        //            }
        //            catch (Exception e)
        //            {

        //                TraceFile.WriteLine("failed to set property '{0}' to value '{1}'", field.Key, field.Value);
        //                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //            }
        //        }

        //        TraceFile.WriteLine("Setting Document Set Multilookup Properties");

        //        foreach (var field in docSet.MultiLookupFields)
        //        {
        //            FieldLookupValue[] lookupFieldCollection = new FieldLookupValue[field.Value.Length];
        //            for (int i = 0; i < field.Value.Length; i++)
        //            {
        //                TraceFile.WriteLine("\t\tSetting Multi Lookup Property '{0}' with value '{1}'", field.Key, field.Value);
        //                FieldLookupValue lookupField = new FieldLookupValue();
        //                lookupField.LookupId = field.Value[i];
        //                lookupFieldCollection.SetValue(lookupField, i);
        //            }

        //            try
        //            {
        //                updateFileListItem[field.Key] = lookupFieldCollection;
        //            }
        //            catch (Exception e)
        //            {

        //                TraceFile.WriteLine("failed to set property '{0}' to value '{1}'", field.Key, lookupFieldCollection.ToString());
        //                TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //            }
        //        }

        //        updateFileListItem.Update();
        //        context.ExecuteQuery();

        //    }
        //    catch (Exception e)
        //    {

        //        TraceFile.WriteLine("Error while setting properties for Document Set '{0}'", folder.ServerRelativeUrl);
        //        TraceFile.WriteLine(e.Message + " - " + e.StackTrace);
        //        result = false;
        //    }

        //    //foreach (var fileListItem in updateFileListItem.FieldValues)
        //    //{
        //    //    TraceFile.WriteLine("fileListItem : '{0}'", fileListItem.Key);
        //    //}
        //    TraceFile.WriteLine("Executed Query to update fields");
        //    sw.Stop();
        //    TraceFile.WriteLine(true, "Document set properties update duration: {0}", sw.Elapsed.TotalMilliseconds);
        //    return result;
        //}
    }
}
