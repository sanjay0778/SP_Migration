﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCA.DocumentMigration.SpDataLoader.Utils
{
    public class TraceFile
    {
       private static bool active = LaunchConfiguration.Default.TRACE_TO_FILE;

        public static void WriteLine(string trace, bool skipValidation = false)
        {
            if (active || skipValidation)
            {
                Console.WriteLine("[{0:yyyy-MM-dd HH:mm:ss}] {1}", DateTime.Now, trace);
            }            
        }
        public static void WriteLine(string trace, params object[] args)
        {
            if (active)
            {
                Console.WriteLine(String.Format("[{0:yyyy-MM-dd HH:mm:ss}] {1}", DateTime.Now, trace), args);
            }            
        }

        public static void WriteLine(bool skipValidation, string trace, params object[] args)
        {
            if (active || skipValidation)
            {
                Console.WriteLine(String.Format("[{0:yyyy-MM-dd HH:mm:ss}] {1}", DateTime.Now, trace), args);
            }
        }
    }
}
