﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using System.Collections;
namespace FieldValueUpdate
{
    class Program
    {
        static void Main(string[] args)
        {
            string siteUrl = "https://iflydoc-dev.ca.aero.bombardier.net";

            ClientContext clientContext = new ClientContext(siteUrl);
            List oList = clientContext.Web.Lists.GetByTitle("CRJ Series");
            CamlQuery camlQuery = new CamlQuery();
            //camlQuery.ViewXml = "<View><Query><FieldRef Name='SubATASNS'/>" +
            //    "<Value Type='Lookup'><Contains><![CDATA['CRJ Series - 57-21 (CRJ700 CRJ705 CRJ900 CRJ1000) Outer-Wing Primary Structure']]></Contains></Value></Query><RowLimit>1000</RowLimit></View>";

            camlQuery.ViewXml = "<View><Query> <Eq><FieldRef Name='SubATASNS' LookupId='TRUE' /><Value Type='Lookup'>1671</Value></Eq></Query><RowLimit>1000</RowLimit></View>";
           //camlQuery.ViewXml = "<View Scope='RecursiveAll'><Query><OrderBy><FieldRef Name='ID' Ascending='TRUE'></FieldRef></OrderBy><Where><And><Eq><FieldRef Name='FSObjType'></FieldRef><Value Type='Text'>1</Value></Eq><Eq><FieldRef Name='SubATASNS' LookupId='TRUE' /><Value Type='Lookup'>1671</Value></Eq></And></Where></Query><ViewFields><FieldRef Name='Title' /><FieldRef Name='Modified' /></ViewFields></View>";

            ListItemCollection collListItem = oList.GetItems(camlQuery);
           // clientContext.Load(collListItem, items => items.Include (item => item["Emp"]));
            clientContext.Load(collListItem);

            clientContext.ExecuteQuery();
            foreach (ListItem oListItem in collListItem)
            {

                FieldLookupValue lv = oListItem["SubATASNS"] as FieldLookupValue;
                if (lv == null) lv = new FieldLookupValue();
                lv.LookupId = 2923;
                oListItem["SubATASNS"] = lv;
                oListItem.Update();
                clientContext.ExecuteQuery();
                Console.WriteLine("ID: {0} \nTitle: {1}", oListItem.Id, oListItem["SubATASNS"]);
            }
                Console.Write("Data updated");
                Console.ReadLine();
            }
        }
    }


/*

 * 
//            CamlQuery camlQuery = new CamlQuery();
//            camlQuery.ViewXml = "<View><Query><Where><Eq><FieldRef Name='SubATASNS' LookupId='True'/>" +
//                "<Value Type='Text'>1</Value></Eq></Where></Query><RowLimit>100</RowLimit></View>";

//            camlQuery.ViewXml =
//camlQuery.ViewXml =
//"<Query><Where><FieldRef Name='SubATASNS' /></Where></Query><ViewFields><Value Type='Lookup'>CRJ Series - 57-21 (CRJ700 CRJ705 CRJ900 CRJ1000) Outer-Wing Primary Structure</Value></ViewFields><QueryOptions />";
            

  string siteURL = "https://iflydoc-dev.ca.aero.bombardier.net";

            ClientContext context = new ClientContext(siteURL);


            ListItem item = context.Web.Lists.GetByTitle("test2").GetItems(new CamlQuery()).GetById(1);
           
            context.Load(item);
            context.ExecuteQuery();

            FieldLookupValue lv = item["Emp"] as FieldLookupValue;
            if (lv == null) lv = new FieldLookupValue();
            lv.LookupId = 2;
            
            item["Emp"] = lv;
            item.Update();
            context.ExecuteQuery();



            Console.WriteLine("success");
            Console.ReadLine(); 
            
            ClientContext clientContext = new ClientContext("https://iflydoc-dev.ca.aero.bombardier.net");
            List list = clientContext.Web.Lists.GetByTitle("CRJ Series");
            FieldCollection fields = list.Fields;
            CamlQuery camlQueryForItem = new CamlQuery();
            camlQueryForItem.ViewXml = @"<View>
                                    <Query>
                                        <Where>
                                            <Eq>
                                                <FieldRef Name='SubATASNS'/>
                                                <Value Type='Lookup'>CRJ Series - 53-61 (CRJ700 CRJ705 CRJ900 CRJ1000) Primary Structure, FS977.00 to FS1162.00</Value>
                                            </Eq>
                                        </Where>
                                    </Query>
                                </View>";
            ListItemCollection listItems = list.GetItems(camlQueryForItem);
            clientContext.Load(listItems, items => items.Include
                                            (item => item["SubATASNS"]));
            clientContext.ExecuteQuery();
            var result = new List<ListItem>();
            for (int i = 0, len = listItems.Count; i < len; i++)
            {
                result.Add(listItems[i]);


            }
            Console.WriteLine(result);
            foreach (ListItem item in listItems)
            {
            FieldLookupValue lookup = item["SubATASNS"] as FieldLookupValue;
            lookup.LookupId = 2;
            item["SubATASNS"] = lookup;
            item.Update();
            clientContext.ExecuteQuery();
            }
            //ListItem itemToUpdate = listItems[0];
            //FieldLookupValue lv = itemToUpdate["SubATASNS"] as FieldLookupValue;
            //lv.LookupId = 16;
            //itemToUpdate["SubATASNS"] = lv;
            //itemToUpdate.Update();
            //clientContext.Load(itemToUpdate);
            //clientContext.ExecuteQuery();
            //Console.WriteLine("success");
            Console.ReadLine();
        }
    }
}

//Console.ReadLine();
//    ClientContext context = new ClientContext("https://iflydoc-dev.ca.aero.bombardier.net");
//    Web web = context.Web;
//    context.Load(web.Lists,
//        lists => lists.Include(list => list.Title,
//            list => list.Id));
//    context.ExecuteQuery();
//    foreach (List list in web.Lists)
//    {
//        Console.WriteLine("List title is: " + list.Title);
//    } */